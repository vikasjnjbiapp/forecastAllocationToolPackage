-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 07, 2019 at 03:17 PM
-- Server version: 10.3.15-MariaDB
-- PHP Version: 7.1.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `jnjbiapplication`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `fetchActualSalesRecordsByDateTime` (IN `year` INT(4), IN `customerWWID` INT(10))  NO SQL
    COMMENT 'To fetch the actual sales'
SELECT * FROM jnj_actualsalesvalue WHERE customerWWID = customerWWID AND year = year AND id in (SELECT id FROM jnj_actualsalesvalue WHERE createdDate=(SELECT MAX(createdDate) FROM jnj_actualsalesvalue WHERE year = year))$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `jnj_actualsalesvalue`
--

CREATE TABLE `jnj_actualsalesvalue` (
  `id` int(7) NOT NULL,
  `customerWWID` int(7) NOT NULL,
  `countryId` int(5) NOT NULL,
  `type` varchar(11) NOT NULL,
  `busSelector` varchar(11) NOT NULL,
  `category` varchar(45) NOT NULL,
  `itemId` int(7) NOT NULL,
  `brandId` int(7) NOT NULL,
  `unit` varchar(25) NOT NULL,
  `jan_fcast` int(11) DEFAULT NULL,
  `feb_fcast` int(11) DEFAULT NULL,
  `mar_fcast` int(11) DEFAULT NULL,
  `apr_fcast` int(11) DEFAULT NULL,
  `may_fcast` int(11) DEFAULT NULL,
  `jun_fcast` int(11) DEFAULT NULL,
  `jul_fcast` int(11) DEFAULT NULL,
  `aug_fcast` int(11) DEFAULT NULL,
  `sep_fcast` int(11) DEFAULT NULL,
  `oct_fcast` int(11) DEFAULT NULL,
  `nov_fcast` int(11) DEFAULT NULL,
  `dec_fcast` int(11) DEFAULT NULL,
  `sales` int(10) NOT NULL,
  `unitPrice` int(10) NOT NULL,
  `year` int(4) NOT NULL,
  `status` int(2) NOT NULL,
  `sapCode` int(10) NOT NULL,
  `divested` int(2) NOT NULL,
  `createdDate` datetime NOT NULL,
  `modifiedDate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jnj_actualsalesvalue`
--

INSERT INTO `jnj_actualsalesvalue` (`id`, `customerWWID`, `countryId`, `type`, `busSelector`, `category`, `itemId`, `brandId`, `unit`, `jan_fcast`, `feb_fcast`, `mar_fcast`, `apr_fcast`, `may_fcast`, `jun_fcast`, `jul_fcast`, `aug_fcast`, `sep_fcast`, `oct_fcast`, `nov_fcast`, `dec_fcast`, `sales`, `unitPrice`, `year`, `status`, `sapCode`, `divested`, `createdDate`, `modifiedDate`) VALUES
(1, 54806, 5, 'Private', 'DPO', 'Hosp.', 2, 1, 'MB & RP', 0, 10, 0, 1, 14, 4, 70, 105, 0, NULL, NULL, NULL, 0, 512, 2019, 0, 418612, 0, '0000-00-00 00:00:00', '0000-00-00'),
(2, 54806, 5, 'Private', 'DPO', 'Hosp.', 7, 4, 'MB & RP', 55, 100, 82, 100, 100, 50, 121, 190, 0, NULL, NULL, NULL, 0, 3, 2019, 0, 418612, 0, '0000-00-00 00:00:00', '0000-00-00'),
(3, 54847, 1, 'Private', 'DPO', 'Hosp.', 85, 33, 'CNS', 3792, 3603, 3792, 1896, 379, 8532, 100, 0, 0, NULL, NULL, NULL, 20, 190, 2019, 0, 416567, 0, '0000-00-00 00:00:00', '0000-00-00'),
(4, 54847, 1, 'MOH', 'TND', 'Ministry Of Health ?', 50, 19, 'CNS', 5679, 35866, 0, 35866, 17036, 313824, 200, 0, 0, NULL, NULL, NULL, 30, 299, 2019, 0, 414738, 0, '0000-00-00 00:00:00', '0000-00-00'),
(5, 54847, 1, 'Private', 'DPO', 'Pharmacy', 85, 33, 'CNS', 1896, 3792, 948, 948, 569, 5688, 300, 0, 0, NULL, NULL, NULL, 1050, 190, 2019, 0, 416567, 0, '0000-00-00 00:00:00', '0000-00-00'),
(6, 54847, 1, 'Private', 'DPO', 'Pharmacy', 50, 19, 'CNS', 0, 2989, 897, 1494, 14944, 897, 400, 0, 0, NULL, NULL, NULL, 1000, 299, 2019, 0, 414738, 0, '0000-00-00 00:00:00', '0000-00-00'),
(7, 54847, 1, 'MOH', 'TND', 'Ministry Of Health ?', 51, 19, 'CNS', 54247, -75112, 75112, 54247, 41729, 0, 500, 0, 0, NULL, NULL, NULL, 1500, 348, 2019, 0, 414739, 0, '0000-00-00 00:00:00', '0000-00-00'),
(8, 54847, 1, 'Private', 'DPO', 'Pharmacy', 52, 19, 'CNS', 0, -1121, 0, 374, 561, -561, 600, 0, 0, NULL, NULL, NULL, 700, 187, 2019, 0, 414736, 0, '0000-00-00 00:00:00', '0000-00-00'),
(9, 54847, 1, 'Private', 'DPO', 'Hosp.', 52, 19, 'CNS', 934, 1869, 0, 0, 1869, 0, 700, 0, 0, NULL, NULL, NULL, 10, 187, 2019, 0, 414736, 0, '0000-00-00 00:00:00', '0000-00-00'),
(10, 54847, 1, 'Private', 'DPO', 'Hosp.', 54, 20, 'MB & RP', 335, 1341, 335, 168, 335, 503, 800, 0, 0, NULL, NULL, NULL, 100, 34, 2019, 0, 414921, 0, '0000-00-00 00:00:00', '0000-00-00'),
(11, 54847, 1, 'Private', 'DPO', 'Hosp.', 55, 20, 'MB & RP', 603, -603, 168, 0, 168, 168, 1000, 0, 0, NULL, NULL, NULL, 100, 34, 2019, 0, 414922, 0, '0000-00-00 00:00:00', '0000-00-00'),
(12, 59051, 1, 'Institution', 'TND', 'Other Institution', 2, 1, 'MB & RP', 299, 0, 210, 30, 141, 114, 5, 35, 99, NULL, NULL, NULL, 210, 563, 2019, 0, 414434, 0, '0000-00-00 00:00:00', '0000-00-00'),
(13, 59051, 1, 'Institution', 'TND', 'Other Institution', 3, 2, 'MB & RP', 17, 813, 412, 546, 217, 96, 1744, 634, 50, NULL, NULL, NULL, 360, 24, 2019, 0, 377568, 0, '0000-00-00 00:00:00', '0000-00-00'),
(14, 59051, 1, 'Institution', 'DPO', 'Other Institution', 5, 2, 'MB & RP', 1548, 907, 170, 0, 196, 0, 1106, 120, 721, NULL, NULL, NULL, 800, 33, 2019, 0, 377567, 0, '0000-00-00 00:00:00', '0000-00-00'),
(15, 59051, 1, 'Private', 'DPO', 'Other Institution', 7, 4, 'MB & RP', 19583, 49742, 44322, 37280, 34740, 30480, 35552, 13131, 52858, NULL, NULL, NULL, 4000, 3, 2019, 0, 32230, 0, '0000-00-00 00:00:00', '0000-00-00'),
(17, 54817, 1, 'Institution', 'DPO', 'Other Institution', 7, 4, 'MB & RP', 628, 707, 583, 475, 775, 620, 669, 461, 776, NULL, NULL, NULL, 0, 3, 2019, 0, 418610, 0, '0000-00-00 00:00:00', '0000-00-00'),
(18, 54824, 1, 'MOH', 'TND', 'Ministry Of Health ?', 51, 19, 'CNS', 0, 0, 574448, 0, 0, 0, 900, 1000, 0, NULL, NULL, NULL, 892, 644, 2019, 0, 418657, 0, '0000-00-00 00:00:00', '0000-00-00'),
(19, 54824, 1, 'Private', 'DPO', 'Hosp.', 54, 20, 'MB & RP', 0, 0, 990, 495, 297, 495, 200, 800, 0, NULL, NULL, NULL, 1350, 50, 2019, 0, 414907, 0, '0000-00-00 00:00:00', '0000-00-00'),
(20, 54824, 1, 'Private', 'DPO', 'Hosp.', 55, 20, 'MB & RP', 0, 0, 1089, 495, 148, 1485, 1520, 450, 0, NULL, NULL, NULL, 300, 50, 2019, 0, 414908, 0, '0000-00-00 00:00:00', '0000-00-00'),
(21, 54806, 5, 'Private', 'DPO', 'Hosp.', 8, 5, 'MB & RP', 10, 200, 200, 100, 200, 100, 101, 101, 0, NULL, NULL, NULL, 0, 2, 2019, 0, 418606, 0, '0000-00-00 00:00:00', '0000-00-00'),
(22, 54806, 5, 'Private', 'DPO', 'Hosp.', 9, 6, 'MB & RP', 100, 50, 50, 50, 100, 50, 60, 60, 0, NULL, NULL, NULL, 0, 3, 2019, 0, 418611, 0, '0000-00-00 00:00:00', '0000-00-00'),
(23, 54817, 1, 'Private', 'DPO', 'Hosp.', 8, 5, 'MB & RP', 598, 849, 421, 687, 766, 792, 683, 480, 536, NULL, NULL, NULL, 0, 2, 2019, 0, 418606, 0, '0000-00-00 00:00:00', '0000-00-00'),
(24, 54817, 1, 'Private', 'DPO', 'Hosp.', 9, 6, 'MB & RP', 1198, 939, 1215, 1605, 399, 7, 3, 0, 2171, NULL, NULL, NULL, 0, 3, 2019, 0, 418611, 0, '0000-00-00 00:00:00', '0000-00-00'),
(25, 54824, 2, 'Private', 'DPO', 'Hosp.', 60, 22, 'MB & RP', 430, 100, 100, 100, 125, 100, 100, 400, 0, NULL, NULL, NULL, 320, 3, 2019, 0, 418515, 0, '0000-00-00 00:00:00', '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `jnj_brand`
--

CREATE TABLE `jnj_brand` (
  `id` int(5) NOT NULL,
  `brandName` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jnj_brand`
--

INSERT INTO `jnj_brand` (`id`, `brandName`) VALUES
(1, 'Apalutamide'),
(2, 'Caelyx'),
(3, 'Concerta ??'),
(4, 'Dak.O.Gel ?'),
(5, 'Daktacort'),
(6, 'Daktarin'),
(7, 'Darzalex'),
(8, 'Durogesic'),
(9, 'Eprex'),
(10, 'Evra'),
(11, 'Fentanyl'),
(12, 'Guselkumab'),
(13, 'Gyno Pevaryl'),
(14, 'Gyno.Daktarin'),
(15, 'Haldol ????????'),
(16, 'Imbruvica'),
(17, 'Intelence'),
(18, 'Invega'),
(19, 'Invega Sustenna'),
(20, 'Invokana'),
(21, 'Jurnista'),
(22, 'Leustatin ??????'),
(23, 'Motilium'),
(24, 'Nizoral'),
(25, 'Pariet'),
(26, 'Pevaryl'),
(27, 'Pevisone'),
(28, 'Prezista'),
(29, 'Remicade'),
(30, 'Resolor'),
(31, 'Rezolsta'),
(32, 'Risperdal Oral'),
(33, 'Risperdal Consta'),
(34, 'Simponi'),
(35, 'Sporanox'),
(36, 'Stelara'),
(37, 'Stugeron'),
(38, 'Sufenta'),
(39, 'Symtuza'),
(40, 'Topamax Oral'),
(41, 'Trevicta'),
(42, 'Velcade'),
(43, 'Vermox'),
(44, 'Yondelis'),
(45, 'Zytiga');

-- --------------------------------------------------------

--
-- Table structure for table `jnj_country`
--

CREATE TABLE `jnj_country` (
  `id` int(4) NOT NULL,
  `countryName` varchar(25) NOT NULL,
  `countryCode` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jnj_country`
--

INSERT INTO `jnj_country` (`id`, `countryName`, `countryCode`) VALUES
(1, 'Saudi Arabia', 'SA'),
(2, 'Kuwait', 'KW'),
(3, 'Bahrain', 'BH'),
(4, 'Qatar', 'QA'),
(5, 'United Arab Emirates', 'UAE'),
(6, 'Oman', 'OM');

-- --------------------------------------------------------

--
-- Table structure for table `jnj_customer`
--

CREATE TABLE `jnj_customer` (
  `id` int(4) NOT NULL,
  `customerWWID` int(6) NOT NULL,
  `customerName` varchar(60) NOT NULL,
  `countryCode` varchar(6) NOT NULL,
  `status` int(2) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jnj_customer`
--

INSERT INTO `jnj_customer` (`id`, `customerWWID`, `customerName`, `countryCode`, `status`) VALUES
(1, 54806, 'CITY PHARMACY CO.', 'AE', 1),
(2, 54808, 'MODERN PHARMACEUTICAL CO.', 'AE', 1),
(3, 54817, 'WAEL PHARMACY CO. LLC', 'BH', 1),
(4, 54819, 'AL HAMER TRADING EST.', 'BH', 1),
(5, 54824, 'AL MOJIL DRUG CO', 'KW', 1),
(6, 54825, 'WARBA MEDICAL SUPPLIES CO.', 'KW', 1),
(7, 54827, 'WALEED PHARMACY', 'OM', 1),
(8, 54829, 'MUSCAT PHARMACY', 'OM', 1),
(9, 54831, 'Ebn Sina Medical', 'QA', 1),
(10, 54835, 'Unipharm Trading LLC', 'QA', 1),
(11, 54843, 'Al Haya Medical Company (PVT)', 'SA', 1),
(12, 54845, 'ABDUL REHMAN AL GOSAIBI GTB', 'SA', 1),
(13, 54847, 'FAROUK MAAMOUN TAMER & CO', 'SA', 1),
(14, 59051, 'Cigalah Trading Establishment', 'SA', 1),
(15, 59630, 'ALGHANIM HEALTHCARE GENERAL TRAD. C', 'KW', 1),
(16, 41957, 'HAMAD MEDICAL CORPORATION', 'QA', 1);

-- --------------------------------------------------------

--
-- Table structure for table `jnj_dataentry`
--

CREATE TABLE `jnj_dataentry` (
  `id` int(4) NOT NULL,
  `customerName` int(6) NOT NULL,
  `countryId` varchar(5) NOT NULL,
  `type` varchar(30) NOT NULL,
  `busSelector` varchar(7) NOT NULL,
  `itemId` int(4) NOT NULL,
  `brandId` int(4) NOT NULL,
  `fcast_jan` int(4) NOT NULL,
  `fcast_feb` int(4) NOT NULL,
  `fcast_mar` int(4) NOT NULL,
  `fcast_apr` int(4) NOT NULL,
  `fcast_may` int(4) NOT NULL,
  `fcast_jun` int(4) NOT NULL,
  `fcast_jul` int(4) NOT NULL,
  `fcast_aug` int(4) NOT NULL,
  `fcast_sep` int(4) NOT NULL,
  `fcast_oct` int(4) NOT NULL,
  `fcast_nov` int(4) NOT NULL,
  `fcast_dec` int(4) NOT NULL,
  `focs_jan` int(4) NOT NULL,
  `focs_feb` int(4) NOT NULL,
  `focs_mar` int(4) NOT NULL,
  `focs_apr` int(4) NOT NULL,
  `focs_may` int(4) NOT NULL,
  `focs_jun` int(4) NOT NULL,
  `focs_jul` int(4) NOT NULL,
  `focs_aug` int(4) NOT NULL,
  `focs_sep` int(4) NOT NULL,
  `focs_oct` int(4) NOT NULL,
  `focs_nov` int(4) NOT NULL,
  `focs_dec` int(4) NOT NULL,
  `year` int(4) NOT NULL,
  `createDate` date NOT NULL,
  `ModifiedDate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `jnj_dummy_actualsalesvalue`
--

CREATE TABLE `jnj_dummy_actualsalesvalue` (
  `id` int(7) NOT NULL,
  `customerWWID` int(7) NOT NULL,
  `countryId` int(5) NOT NULL,
  `type` varchar(11) NOT NULL,
  `busSelector` varchar(11) NOT NULL,
  `category` varchar(45) NOT NULL,
  `itemId` int(7) NOT NULL,
  `brandId` int(7) NOT NULL,
  `unit` varchar(25) NOT NULL,
  `jan_fcast` int(11) DEFAULT NULL,
  `feb_fcast` int(11) DEFAULT NULL,
  `mar_fcast` int(11) DEFAULT NULL,
  `apr_fcast` int(11) DEFAULT NULL,
  `may_fcast` int(11) DEFAULT NULL,
  `jun_fcast` int(11) DEFAULT NULL,
  `jul_fcast` int(11) DEFAULT NULL,
  `aug_fcast` int(11) DEFAULT NULL,
  `sep_fcast` int(11) DEFAULT NULL,
  `oct_fcast` int(11) DEFAULT NULL,
  `nov_fcast` int(11) DEFAULT NULL,
  `dec_fcast` int(11) DEFAULT NULL,
  `sales` int(10) NOT NULL,
  `unitPrice` int(10) NOT NULL,
  `year` int(4) NOT NULL,
  `status` int(2) NOT NULL,
  `sapCode` int(10) NOT NULL,
  `divested` int(2) NOT NULL,
  `createdDate` datetime NOT NULL,
  `modifiedDate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `jnj_fcast_focs_dataentry`
--

CREATE TABLE `jnj_fcast_focs_dataentry` (
  `talId` int(7) NOT NULL,
  `customerWWID` int(7) NOT NULL,
  `countryId` int(5) NOT NULL,
  `type` varchar(11) NOT NULL,
  `busSelector` varchar(11) NOT NULL,
  `category` varchar(45) NOT NULL,
  `itemId` int(7) NOT NULL,
  `brandId` int(7) NOT NULL,
  `unit` varchar(25) NOT NULL,
  `jan_fcast` int(11) NOT NULL,
  `feb_fcast` int(11) NOT NULL,
  `mar_fcast` int(11) NOT NULL,
  `apr_fcast` int(11) NOT NULL,
  `may_fcast` int(11) NOT NULL,
  `jun_fcast` int(11) NOT NULL,
  `jul_fcast` int(11) NOT NULL,
  `aug_fcast` int(11) NOT NULL,
  `sep_fcast` int(11) NOT NULL,
  `oct_fcast` int(11) NOT NULL,
  `nov_fcast` int(11) NOT NULL,
  `dec_fcast` int(11) NOT NULL,
  `year` int(4) NOT NULL,
  `status` int(2) NOT NULL,
  `sapCode` int(10) NOT NULL,
  `divested` int(2) NOT NULL,
  `createDate` datetime NOT NULL,
  `modifiedDate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jnj_fcast_focs_dataentry`
--

INSERT INTO `jnj_fcast_focs_dataentry` (`talId`, `customerWWID`, `countryId`, `type`, `busSelector`, `category`, `itemId`, `brandId`, `unit`, `jan_fcast`, `feb_fcast`, `mar_fcast`, `apr_fcast`, `may_fcast`, `jun_fcast`, `jul_fcast`, `aug_fcast`, `sep_fcast`, `oct_fcast`, `nov_fcast`, `dec_fcast`, `year`, `status`, `sapCode`, `divested`, `createDate`, `modifiedDate`) VALUES
(1, 54806, 5, 'Private', 'DPO', 'Hosp.', 2, 2, 'MB & RP', 0, 10, 0, 1, 14, 4, 70, 105, 0, 0, 0, 0, 2019, 0, 418612, 0, '0000-00-00 00:00:00', '0000-00-00'),
(2, 54806, 5, 'Private', 'DPO', 'Hosp.', 7, 4, 'MB & RP', 55, 100, 82, 100, 100, 50, 121, 190, 0, 0, 0, 0, 2019, 0, 418612, 0, '0000-00-00 00:00:00', '0000-00-00'),
(3, 54847, 1, 'Private', 'DPO', 'Hosp.', 85, 33, 'CNS', 3792, 3603, 3792, 1896, 379, 8532, 100, 0, 0, 0, 0, 0, 2019, 0, 416567, 0, '0000-00-00 00:00:00', '0000-00-00'),
(4, 54847, 1, 'MOH', 'TND', 'Ministry Of Health', 50, 19, 'CNS', 5679, 35866, 0, 35866, 17036, 313824, 200, 0, 0, 0, 0, 0, 2019, 0, 414738, 0, '0000-00-00 00:00:00', '0000-00-00'),
(5, 54847, 1, 'Private', 'DPO', 'Pharmacy', 85, 33, 'CNS', 1896, 3792, 948, 948, 569, 5688, 300, 0, 0, 0, 0, 0, 2019, 0, 416567, 0, '0000-00-00 00:00:00', '0000-00-00'),
(6, 54847, 1, 'Private', 'DPO', 'Pharmacy', 50, 19, 'CNS', 0, 2989, 897, 1494, 14944, 897, 400, 0, 0, 0, 0, 0, 2019, 0, 414738, 0, '0000-00-00 00:00:00', '0000-00-00'),
(7, 54847, 1, 'MOH', 'TND', 'Ministry Of Health', 51, 19, 'CNS', 54247, -75112, 75112, 54247, 41729, 0, 500, 0, 0, 0, 0, 0, 2019, 0, 414739, 0, '0000-00-00 00:00:00', '0000-00-00'),
(8, 54847, 1, 'Private', 'DPO', 'Pharmacy', 52, 19, 'CNS', 0, -1121, 0, 374, 561, -561, 600, 0, 0, 0, 0, 0, 2019, 0, 414736, 0, '0000-00-00 00:00:00', '0000-00-00'),
(9, 54847, 1, 'Private', 'DPO', 'Hosp.', 52, 19, 'CNS', 934, 1869, 0, 0, 1869, 0, 700, 0, 0, 0, 0, 0, 2019, 0, 414736, 0, '0000-00-00 00:00:00', '0000-00-00'),
(10, 54847, 1, 'Private', 'DPO', 'Hosp.', 54, 20, 'MB & RP', 335, 1341, 335, 168, 335, 503, 800, 0, 0, 0, 0, 0, 2019, 0, 414921, 0, '0000-00-00 00:00:00', '0000-00-00'),
(11, 54847, 1, 'Private', 'DPO', 'Hosp.', 55, 20, 'MB & RP', 603, -603, 168, 0, 168, 168, 1000, 0, 0, 0, 0, 0, 2019, 0, 414922, 0, '0000-00-00 00:00:00', '0000-00-00'),
(12, 59051, 1, 'Institution', 'TND', 'Other Institution', 2, 2, 'MB & RP', 210, 0, 10, 20, 96, 79, 500, 125, 0, 0, 0, 0, 2019, 0, 414434, 0, '0000-00-00 00:00:00', '0000-00-00'),
(13, 59051, 1, 'Institution', 'TND', 'Other Institution', 3, 2, 'MB & RP', 17, 360, 192, 96, 200, 96, 542, 152, 0, 0, 0, 0, 2019, 0, 377568, 0, '0000-00-00 00:00:00', '0000-00-00'),
(14, 59051, 1, 'Institution', 'DPO', 'Other Institution', 5, 2, 'MB & RP', 800, 240, 120, 0, 168, 0, 300, 155, 0, 0, 0, 0, 2019, 0, 377567, 0, '0000-00-00 00:00:00', '0000-00-00'),
(15, 59051, 1, 'Institution', 'DPO', 'Other Institution', 7, 4, 'MB & RP', 900, 0, 250, 1000, 600, 4000, 690, 8000, 0, 0, 0, 0, 2019, 0, 32230, 0, '0000-00-00 00:00:00', '0000-00-00'),
(16, 54817, 1, 'MOH', 'TND', 'Ministry Of Health ?', 2, 2, 'MB & RP', 0, 0, 0, 15360, 0, 0, 25, 12, 0, 0, 0, 0, 2019, 0, 418610, 0, '0000-00-00 00:00:00', '0000-00-00'),
(17, 54817, 1, 'Institution', 'DPO', 'Other Institution', 7, 4, 'MB & RP', 100, 20, 80, 25, 60, 10, 25, 90, 0, 0, 0, 0, 2019, 0, 418610, 0, '0000-00-00 00:00:00', '0000-00-00'),
(18, 54824, 1, 'MOH', 'TND', 'Ministry Of Health ?', 51, 19, 'CNS', 0, 0, 574448, 0, 0, 0, 900, 1000, 0, 0, 0, 0, 2019, 0, 418657, 0, '0000-00-00 00:00:00', '0000-00-00'),
(19, 54824, 1, 'Private', 'DPO', 'Hosp.', 54, 20, 'MB & RP', 0, 0, 990, 495, 297, 495, 200, 800, 0, 0, 0, 0, 2019, 0, 414907, 0, '0000-00-00 00:00:00', '0000-00-00'),
(20, 54824, 1, 'Private', 'DPO', 'Hosp.', 55, 20, 'MB & RP', 0, 0, 1089, 495, 148, 1485, 1520, 450, 0, 0, 0, 0, 2019, 0, 414908, 0, '0000-00-00 00:00:00', '0000-00-00'),
(21, 54806, 5, 'Private', 'DPO', 'Hosp.', 8, 5, 'MB & RP', 10, 200, 200, 100, 200, 100, 101, 101, 0, 0, 0, 0, 2019, 0, 418606, 0, '0000-00-00 00:00:00', '0000-00-00'),
(22, 54806, 5, 'Private', 'DPO', 'Hosp.', 9, 6, 'MB & RP', 100, 50, 50, 50, 100, 50, 60, 60, 0, 0, 0, 0, 2019, 0, 418611, 0, '0000-00-00 00:00:00', '0000-00-00'),
(23, 54817, 1, 'Private', 'DPO', 'Hosp.', 8, 5, 'MB & RP', 5, 3, 20, 20, 20, 60, 15, 15, 0, 0, 0, 0, 2019, 0, 418606, 0, '0000-00-00 00:00:00', '0000-00-00'),
(24, 54817, 1, 'Private', 'DPO', 'Hosp.', 9, 6, 'MB & RP', 315, 100, 400, 300, 110, 111, 118, 50, 0, 0, 0, 0, 2019, 0, 418611, 0, '0000-00-00 00:00:00', '0000-00-00'),
(25, 54824, 2, 'Private', 'DPO', 'Hosp.', 60, 22, 'MB & RP', 430, 100, 100, 100, 125, 100, 100, 400, 0, 0, 0, 0, 2019, 0, 418515, 0, '0000-00-00 00:00:00', '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `jnj_item`
--

CREATE TABLE `jnj_item` (
  `id` int(5) NOT NULL,
  `itemName` varchar(225) NOT NULL,
  `skuCode` int(10) NOT NULL,
  `countryId` int(4) NOT NULL,
  `brandId` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jnj_item`
--

INSERT INTO `jnj_item` (`id`, `itemName`, `skuCode`, `countryId`, `brandId`) VALUES
(1, 'Apalutamide', 0, 1, 1),
(2, 'Caelyx 20 mg', 0, 1, 2),
(3, 'Concerta 18 mg 30 Tab', 0, 1, 3),
(4, 'Concerta 27 mg 30 Tab', 0, 1, 3),
(5, 'Concerta 36 mg 30 Tab', 0, 1, 3),
(6, 'Concerta 54 mg 30 Tab', 0, 1, 3),
(7, 'Dak.O.Gel.', 0, 1, 4),
(8, 'Daktacort Cr.', 0, 1, 5),
(9, 'Daktarin Cr.', 0, 1, 6),
(10, 'Daktarin Cr. 15 mg.', 0, 1, 6),
(11, 'Daktarin Powder', 0, 0, 6),
(12, 'Daktarin Tincture', 0, 0, 6),
(13, 'Darzalex 100 mg.', 0, 0, 7),
(14, 'Darzalex 400 mg.', 0, 0, 7),
(15, 'Durogesic 100 mcg', 0, 0, 8),
(16, 'Durogesic 12 ?mcg', 0, 0, 8),
(17, 'Durogesic 25 ?mcg', 0, 0, 8),
(18, 'Durogesic 50 ?mcg', 0, 0, 8),
(19, 'Durogesic 75 ?mcg', 0, 0, 8),
(20, 'Eprex 1000 IU', 0, 0, 9),
(21, 'Eprex 10000 IU', 0, 0, 9),
(22, 'Eprex 2000 IU', 0, 0, 9),
(23, 'Eprex 3000 IU', 0, 0, 9),
(24, 'Eprex 4000 IU', 0, 0, 9),
(25, 'Eprex 40000 IU', 0, 0, 9),
(26, 'Evra', 0, 0, 10),
(27, 'Fentanyl 0.05 ml 50 * 10 ml Amp.', 0, 0, 11),
(28, 'Fentanyl 0.05 ml 50 * 2 ml Amp.', 0, 0, 11),
(29, 'Guselkumab', 0, 0, 12),
(30, 'Gyno Pevaryl Cr.', 0, 0, 13),
(31, 'Gyno Pevaryl Dep Ov.', 0, 0, 13),
(32, 'Gyno Pevaryl Supp.', 0, 0, 13),
(33, 'Gyno. Dak. Cr.', 0, 0, 14),
(34, 'Gyno. Dak. Ov. 1200 mg.', 0, 0, 14),
(35, 'Gyno. Dak. Ov. 200 mg.', 0, 0, 14),
(36, 'Gyno. Dak. Ov. 400 mg.', 0, 0, 14),
(37, 'Haldol 10 mg 20 Tab.', 0, 0, 15),
(38, 'Haldol 5 mg. / 5 Amp.', 0, 0, 15),
(39, 'Haldol 5 mg. 1000 Tab.', 0, 0, 15),
(40, 'Haldol 5 mg. 25 Tab.', 0, 0, 15),
(41, 'Haldol Decanoace 100 mg. 1 Amp.', 0, 0, 15),
(42, 'Haldol Decanoace 50 mg.1 Amp.', 0, 0, 15),
(43, 'Haldol Decanoace 50 mg.5 Amp.', 0, 0, 15),
(44, 'Haldol Oral Drops 2 mg/ml,30 ml', 0, 0, 15),
(45, 'Imbruvica', 0, 0, 16),
(46, 'Intelence 100 mg.', 0, 0, 17),
(47, 'Invega 3 mg.', 0, 0, 18),
(48, 'Invega 6 mg.', 0, 0, 18),
(49, 'Invega 9 mg.', 0, 0, 18),
(50, 'Invega Sustenna 100 mg', 0, 0, 19),
(51, 'Invega Sustenna 150 mg', 0, 0, 19),
(52, 'Invega Sustenna 50 mg', 0, 0, 19),
(53, 'Invega Sustenna 75 mg', 0, 0, 19),
(54, 'Invokana 100 mg 30 Tab', 0, 0, 20),
(55, 'Invokana 300 mg 30 Tab', 0, 0, 20),
(56, 'Jurnista 16 mg', 0, 0, 21),
(57, 'Jurnista 32 mg', 0, 0, 21),
(58, 'Jurnista 8 mg', 0, 0, 21),
(59, 'Leustatin', 0, 0, 22),
(60, 'Motilium Susp.', 0, 0, 23),
(61, 'Motilium Susp. 100 ml', 0, 0, 23),
(62, 'Motilium Tab.', 0, 0, 23),
(63, 'Motilium Tab. 100\'s', 0, 0, 23),
(64, 'Nizoral Cr.', 0, 0, 24),
(65, 'Pariet 20 mg. ?', 0, 0, 25),
(66, 'Pariet 20 mg. 28\'S', 0, 0, 25),
(67, 'Pevaryl Cr.', 0, 0, 26),
(68, 'Pevisone Cr.', 0, 0, 27),
(69, 'Prezista 400 mg.', 0, 0, 28),
(70, 'Prezista 600 mg.', 0, 0, 28),
(71, 'Remicade', 0, 0, 29),
(72, 'Resolor 1 mg tab 28\'s', 0, 0, 30),
(73, 'Resolor 2 mg tab 28\'s', 0, 0, 30),
(74, 'Rezolsta', 0, 0, 30),
(75, 'Risperdal 1 mg.', 0, 0, 31),
(76, 'Risperdal 1 mg. 20 Tab', 0, 0, 31),
(77, 'Risperdal 1mg/ml ?Soul. Oral 100 ml', 0, 0, 31),
(78, 'Risperdal 2 mg.', 0, 0, 31),
(79, 'Risperdal 2 mg. 20 Tab.', 0, 0, 31),
(80, 'Risperdal 3 mg. 20 Tab.', 0, 0, 31),
(81, 'Risperdal 4 mg.', 0, 0, 31),
(82, 'Risperdal 4 mg. 20 Tab', 0, 0, 31),
(83, 'Risperdal Consta 25 mg.', 0, 0, 31),
(84, 'Risperdal Consta 37.5 mg.', 0, 0, 31),
(85, 'Risperdal Consta 50 mg.', 0, 0, 31),
(86, 'Simponi', 0, 0, 32),
(87, 'Simponi 100 mg', 0, 0, 32),
(88, 'Sporanox 1% 150ML. Oral Sol.', 0, 0, 33),
(89, 'Sporanox 15 Cap.', 0, 0, 33),
(90, 'Sporanox 4 Cap.', 0, 0, 33),
(91, 'Sporanox Inj', 0, 0, 33),
(92, 'Stelara 130 mg.', 0, 0, 34),
(93, 'Stelara 45 mg.', 0, 0, 34),
(94, 'Stelara 90 mg.', 0, 0, 34),
(95, 'Stugeron 25 mg', 0, 0, 35),
(96, 'Sufenta 50 mg./ 1ml. 5 ml', 0, 0, 36),
(97, 'Symtuza', 0, 0, 37),
(98, 'Topamax 100 mg 60Tab.', 0, 0, 38),
(99, 'Topamax 15 mg Sprinkle', 0, 0, 38),
(100, 'Topamax 200 mg 60Tab.', 0, 0, 38),
(101, 'Topamax 25 mg 60 Tab.', 0, 0, 38),
(102, 'Topamax 50 mg Sprinkle', 0, 0, 38),
(103, 'Topamax 50 mg Tab.', 0, 0, 38),
(104, 'Trevicta 175 mg.', 0, 0, 39),
(105, 'Trevicta 263 mg.', 0, 0, 39),
(106, 'Trevicta 350 mg.', 0, 0, 39),
(107, 'Trevicta 525 mg.', 0, 0, 39),
(108, 'Velcade', 0, 0, 40),
(109, 'Vermox Susp.', 0, 0, 41),
(110, 'Vermox Tab.', 0, 0, 41),
(111, 'Vermox Tab.500 mg.', 0, 0, 41),
(112, 'Yondelis', 0, 0, 42),
(113, 'Zytiga', 0, 0, 43);

-- --------------------------------------------------------

--
-- Table structure for table `jnj_pricing_dataentry`
--

CREATE TABLE `jnj_pricing_dataentry` (
  `id` int(5) NOT NULL,
  `material` int(7) NOT NULL,
  `SKU` varchar(50) NOT NULL,
  `countryCode` varchar(5) NOT NULL,
  `currency` varchar(5) NOT NULL,
  `cif_jan` float NOT NULL,
  `cif_feb` float NOT NULL,
  `cif_mar` float NOT NULL,
  `cif_apr` float NOT NULL,
  `cif_may` float NOT NULL,
  `cif_jun` float NOT NULL,
  `cif_jul` float NOT NULL,
  `cif_aug` float NOT NULL,
  `cif_sep` float NOT NULL,
  `cif_oct` float NOT NULL,
  `cif_nov` float NOT NULL,
  `cif_dec` float NOT NULL,
  `tnd_jan` float NOT NULL,
  `tnd_feb` float NOT NULL,
  `tnd_mar` float NOT NULL,
  `tnd_apr` float NOT NULL,
  `tnd_may` float NOT NULL,
  `tnd_jun` float NOT NULL,
  `tnd_jul` float NOT NULL,
  `tnd_aug` float NOT NULL,
  `tnd_sep` float NOT NULL,
  `tnd_oct` float NOT NULL,
  `tnd_nov` float NOT NULL,
  `tnd_dec` float NOT NULL,
  `discounts` varchar(20) NOT NULL,
  `focs` varchar(20) NOT NULL,
  `totalDiscount` varchar(20) NOT NULL,
  `month` int(5) NOT NULL,
  `year` int(4) NOT NULL,
  `createDate` datetime NOT NULL,
  `ModifiedDate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jnj_pricing_dataentry`
--

INSERT INTO `jnj_pricing_dataentry` (`id`, `material`, `SKU`, `countryCode`, `currency`, `cif_jan`, `cif_feb`, `cif_mar`, `cif_apr`, `cif_may`, `cif_jun`, `cif_jul`, `cif_aug`, `cif_sep`, `cif_oct`, `cif_nov`, `cif_dec`, `tnd_jan`, `tnd_feb`, `tnd_mar`, `tnd_apr`, `tnd_may`, `tnd_jun`, `tnd_jul`, `tnd_aug`, `tnd_sep`, `tnd_oct`, `tnd_nov`, `tnd_dec`, `discounts`, `focs`, `totalDiscount`, `month`, `year`, `createDate`, `ModifiedDate`) VALUES
(1, 140307, '\'Pevaryl Cream 1 % 15g\'', '\'BH\'', '\'USD\'', 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, '0.00%', '0.00%', '0.00%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(2, 414287, '\'Stelara 45mg/0.5ml \'', '\'BH\'', '\'USD\'', 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, '0.00%', '0.00%', '0.00%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(3, 414288, '\'Stelara 90mg/1ml\'', '\'BH\'', '\'USD\'', 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, '0.00%', '0.00%', '0.00%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(4, 414963, '\'Velcade Injection 3.5 mg\'', '\'BH\'', '\'USD\'', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 740, 740, 740, 740, 740, 740, 740, 740, 740, 740, 740, 740, '0.00%', '0.00%', '0.00%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(5, 416936, '\'Motilium 1 mg/ml Oral Suspension 200ml\'', '\'BH\'', '\'USD\'', 3.2, 3.2, 3.2, 3.2, 3.2, 3.2, 3.2, 3.2, 3.2, 3.2, 3.2, 3.2, 2.5, 2.5, 2.5, 2.5, 2.5, 2.5, 2.5, 2.5, 2.5, 2.5, 2.5, 2.5, '0.00%', '0.00%', '0.00%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(6, 376935, '\'Sporanox 100 mg Cap. 15s\'', '\'BH\'', '\'USD\'', 21.26, 21.26, 21.26, 21.26, 21.26, 21.26, 21.26, 21.26, 21.26, 21.26, 21.26, 21.26, 21.26, 21.26, 21.26, 21.26, 21.26, 21.26, 21.26, 21.26, 21.26, 21.26, 21.26, 21.26, '0.00%', '0.00%', '0.00%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(7, 96489, '\'Sporanox 100 mg Cap. 4s\'', '\'BH\'', '\'USD\'', 6.51, 6.51, 6.51, 6.51, 6.51, 6.51, 6.51, 6.51, 6.51, 6.51, 6.51, 6.51, 6.51, 6.51, 6.51, 6.51, 6.51, 6.51, 6.51, 6.51, 6.51, 6.51, 6.51, 6.51, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(8, 96048, '\'Vermox 500 mg Tab.\'', '\'BH\'', '\'USD\'', 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.35, 1.35, 1.35, 1.35, 1.35, 1.35, 1.35, 1.35, 1.35, 1.35, 1.35, 1.35, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(9, 96046, '\'Stugeron 25 mg Tab.\'', '\'BH\'', '\'USD\'', 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(10, 376855, '\'Risperdal 2mg Tab. 20s\'', '\'BH\'', '\'USD\'', 21.27, 21.27, 21.27, 21.27, 21.27, 21.27, 21.27, 21.27, 21.27, 21.27, 21.27, 21.27, 10.64, 10.64, 10.64, 10.64, 10.64, 10.64, 10.64, 10.64, 10.64, 10.64, 10.64, 10.64, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(11, 376856, '\'Risperdal 3mg Tab. 20s\'', '\'BH\'', '\'USD\'', 27.36, 27.36, 27.36, 27.36, 27.36, 27.36, 27.36, 27.36, 27.36, 27.36, 27.36, 27.36, 13.68, 13.68, 13.68, 13.68, 13.68, 13.68, 13.68, 13.68, 13.68, 13.68, 13.68, 13.68, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(12, 414900, '\'Remicade 100 mg \'', '\'BH\'', '\'USD\'', 468.97, 468.97, 468.97, 468.97, 468.97, 468.97, 468.97, 468.97, 468.97, 468.97, 468.97, 468.97, 260, 260, 260, 260, 260, 260, 260, 260, 260, 260, 260, 260, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(13, 141021, '\'Topamax 100 mg Tab.\'', '\'BH\'', '\'USD\'', 42.49, 42.49, 42.49, 42.49, 42.49, 42.49, 42.49, 42.49, 42.49, 42.49, 42.49, 42.49, 42.49, 42.49, 42.49, 42.49, 42.49, 42.49, 42.49, 42.49, 42.49, 42.49, 42.49, 42.49, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(14, 412301, '\'Topamax 15 mg Sprinkle Cap.\'', '\'BH\'', '\'USD\'', 11.78, 11.78, 11.78, 11.78, 11.78, 11.78, 11.78, 11.78, 11.78, 11.78, 11.78, 11.78, 11.78, 11.78, 11.78, 11.78, 11.78, 11.78, 11.78, 11.78, 11.78, 11.78, 11.78, 11.78, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(15, 141016, '\'Topamax 25 mg Tab.\'', '\'BH\'', '\'USD\'', 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(16, 141019, '\'Topamax 50 mg Tab.\'', '\'BH\'', '\'USD\'', 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(17, 414448, '\'Zytiga 250 mg Tabs\'', '\'BH\'', '\'USD\'', 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(18, 96065, '\'Vermox 100 mg Tab. 240\'s\'', '\'BH\'', '\'USD\'', 47.6, 47.6, 47.6, 47.6, 47.6, 47.6, 47.6, 47.6, 47.6, 47.6, 47.6, 47.6, 47.6, 47.6, 47.6, 47.6, 47.6, 47.6, 47.6, 47.6, 47.6, 47.6, 47.6, 47.6, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(19, 96063, '\'Vermox 100 mg Tab. 6s\'', '\'BH\'', '\'USD\'', 1.56, 1.56, 1.56, 1.56, 1.56, 1.56, 1.56, 1.56, 1.56, 1.56, 1.56, 1.56, 1.2, 1.2, 1.2, 1.2, 1.2, 1.2, 1.2, 1.2, 1.2, 1.2, 1.2, 1.2, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(20, 418514, '\'Motilium 10 mg Tab. 30s\'', '\'BH\'', '\'USD\'', 3.3, 3.3, 3.3, 3.3, 3.3, 3.3, 3.3, 3.3, 3.3, 3.3, 3.3, 3.3, 3.3, 3.3, 3.3, 3.3, 3.3, 3.3, 3.3, 3.3, 3.3, 3.3, 3.3, 3.3, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(21, 412323, '\'Pevisone Cream \'', '\'BH\'', '\'USD\'', 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(22, 414050, '\'Resolor 1 mg Film-Coated Tabs.\'', '\'BH\'', '\'USD\'', 32.51, 32.51, 26.33, 26.33, 32.51, 32.51, 26.33, 26.33, 32.51, 32.51, 26.33, 26.33, 32.51, 32.51, 26.33, 26.33, 32.51, 32.51, 26.33, 26.33, 32.51, 32.51, 26.33, 26.33, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(23, 414053, '\'Resolor 2 mg Film-Coated Tabs.\'', '\'BH\'', '\'USD\'', 53.46, 53.46, 43.29, 43.29, 53.46, 53.46, 43.29, 43.29, 53.46, 53.46, 43.29, 43.29, 53.46, 53.46, 43.29, 43.29, 53.46, 53.46, 43.29, 43.29, 53.46, 53.46, 43.29, 43.29, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(24, 385589, '\'Yondelis 1 mg Injection \'', '\'BH\'', '\'USD\'', 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(25, 412675, '\'Simponi 50 mg/ 0.5 ml Injection (PFP)\'', '\'BH\'', '\'USD\'', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 900, 900, 900, 900, 900, 900, 900, 900, 900, 900, 900, 900, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(26, 387104, '\'Prezista 400 mg Tablets\'', '\'BH\'', '\'USD\'', 402.77, 402.77, 402.77, 402.77, 402.77, 402.77, 402.77, 402.77, 402.77, 402.77, 402.77, 402.77, 402.77, 402.77, 402.77, 402.77, 402.77, 402.77, 402.77, 402.77, 402.77, 402.77, 402.77, 402.77, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(27, 387107, '\'Prezista 600 mg Tablets\'', '\'BH\'', '\'USD\'', 615.22, 615.22, 615.22, 615.22, 615.22, 615.22, 615.22, 615.22, 615.22, 615.22, 615.22, 615.22, 615.22, 615.22, 615.22, 615.22, 615.22, 615.22, 615.22, 615.22, 615.22, 615.22, 615.22, 615.22, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(28, 87518, '\'Risperdal 1 mg/ml Oral Solution\'', '\'BH\'', '\'USD\'', 52.03, 52.03, 52.03, 52.03, 52.03, 52.03, 52.03, 52.03, 52.03, 52.03, 52.03, 52.03, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(29, 376595, '\'Risperdal Consta 25 mg Inj.  \'', '\'BH\'', '\'USD\'', 116.79, 116.79, 73.96, 73.96, 116.79, 116.79, 73.96, 73.96, 116.79, 116.79, 73.96, 73.96, 73.96, 73.96, 73.96, 73.96, 73.96, 73.96, 73.96, 73.96, 73.96, 73.96, 73.96, 73.96, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(30, 376596, '\'Risperdal Consta 37.5 mg Inj. \'', '\'BH\'', '\'USD\'', 154.05, 154.05, 102.95, 102.95, 154.05, 154.05, 102.95, 102.95, 154.05, 154.05, 102.95, 102.95, 102.95, 102.95, 102.95, 102.95, 102.95, 102.95, 102.95, 102.95, 102.95, 102.95, 102.95, 102.95, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(31, 414696, '\'Nizoral Cream 2 %\'', '\'BH\'', '\'USD\'', 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(32, 376597, '\'Risperdal Consta 50 mg Inj.  \'', '\'BH\'', '\'USD\'', 189.61, 189.61, 122.95, 122.95, 189.61, 189.61, 122.95, 122.95, 189.61, 189.61, 122.95, 122.95, 122.95, 122.95, 122.95, 122.95, 122.95, 122.95, 122.95, 122.95, 122.95, 122.95, 122.95, 122.95, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(33, 140309, '\'Pevaryl Cream 1 % 30g\'', '\'BH\'', '\'USD\'', 3.75, 3.75, 3.75, 3.75, 3.75, 3.75, 3.75, 3.75, 3.75, 3.75, 3.75, 3.75, 2.63, 2.63, 2.63, 2.63, 2.63, 2.63, 2.63, 2.63, 2.63, 2.63, 2.63, 2.63, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(34, 32461, '\'Vermox 20 mg/ml Oral Susp.\'', '\'BH\'', '\'USD\'', 1.66, 1.66, 1.66, 1.66, 1.66, 1.66, 1.66, 1.66, 1.66, 1.66, 1.66, 1.66, 1.66, 1.66, 1.66, 1.66, 1.66, 1.66, 1.66, 1.66, 1.66, 1.66, 1.66, 1.66, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(35, 414434, '\'Caelyx 2 mg/ml\'', '\'BH\'', '\'USD\'', 512, 512, 512, 512, 512, 512, 512, 512, 512, 512, 512, 512, 512, 512, 512, 512, 512, 512, 512, 512, 512, 512, 512, 512, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(36, 387691, '\'Concerta 18mg  Extended Release Tab.\'', '\'BH\'', '\'USD\'', 33.57, 33.57, 33.57, 33.57, 33.57, 33.57, 33.57, 33.57, 33.57, 33.57, 33.57, 33.57, 23.54, 23.54, 23.54, 23.54, 23.54, 23.54, 23.54, 23.54, 23.54, 23.54, 23.54, 23.54, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(37, 387693, '\'Concerta 36mg Extended Release Tab.\'', '\'BH\'', '\'USD\'', 45.7, 45.7, 32.69, 32.69, 45.7, 45.7, 32.69, 32.69, 45.7, 45.7, 32.69, 32.69, 32.69, 32.69, 32.69, 32.69, 32.69, 32.69, 32.69, 32.69, 32.69, 32.69, 32.69, 32.69, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(38, 32442, '\'Daktacort Cream                 \'', '\'BH\'', '\'USD\'', 2.31, 2.31, 2.31, 2.31, 2.31, 2.31, 2.31, 2.31, 2.31, 2.31, 2.31, 2.31, 2.31, 2.31, 2.31, 2.31, 2.31, 2.31, 2.31, 2.31, 2.31, 2.31, 2.31, 2.31, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(39, 88877, '\'Daktarin Cream 2% 30g\'', '\'BH\'', '\'USD\'', 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(40, 32441, '\'Daktarin Oral Gel 2%\'', '\'BH\'', '\'USD\'', 3.19, 3.19, 3.19, 3.19, 3.19, 3.19, 3.19, 3.19, 3.19, 3.19, 3.19, 3.19, 3.19, 3.19, 3.19, 3.19, 3.19, 3.19, 3.19, 3.19, 3.19, 3.19, 3.19, 3.19, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(41, 377017, '\'Daktarin Powder 2%\'', '\'BH\'', '\'USD\'', 2.19, 2.19, 2.19, 2.19, 2.19, 2.19, 2.19, 2.19, 2.19, 2.19, 2.19, 2.19, 2.19, 2.19, 2.19, 2.19, 2.19, 2.19, 2.19, 2.19, 2.19, 2.19, 2.19, 2.19, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(42, 387397, '\'Durogesic Transdermal Patches 100 mcg/h\'', '\'BH\'', '\'USD\'', 98.73, 98.73, 98.73, 98.73, 98.73, 98.73, 98.73, 98.73, 98.73, 98.73, 98.73, 98.73, 98.73, 98.73, 98.73, 98.73, 98.73, 98.73, 98.73, 98.73, 98.73, 98.73, 98.73, 98.73, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(43, 387398, '\'Durogesic Transdermal Patches 12 mcg/h\'', '\'BH\'', '\'USD\'', 17.62, 17.62, 17.62, 17.62, 17.62, 17.62, 17.62, 17.62, 17.62, 17.62, 17.62, 17.62, 17.62, 17.62, 17.62, 17.62, 17.62, 17.62, 17.62, 17.62, 17.62, 17.62, 17.62, 17.62, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(44, 387399, '\'Durogesic Transdermal Patches 25 mcg/h\'', '\'BH\'', '\'USD\'', 31.12, 31.12, 31.12, 31.12, 31.12, 31.12, 31.12, 31.12, 31.12, 31.12, 31.12, 31.12, 31.12, 31.12, 7.11, 7.11, 31.12, 31.12, 7.11, 7.11, 31.12, 31.12, 7.11, 7.11, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(45, 387400, '\'Durogesic Transdermal Patches 50 mcg/h\'', '\'BH\'', '\'USD\'', 52.29, 52.29, 52.29, 52.29, 52.29, 52.29, 52.29, 52.29, 52.29, 52.29, 52.29, 52.29, 52.29, 52.29, 13.07, 13.07, 52.29, 52.29, 13.07, 13.07, 52.29, 52.29, 13.07, 13.07, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(46, 414064, '\'Eprex 1,000 U Pre-Filled Syringes \'', '\'BH\'', '\'USD\'', 65.19, 65.19, 65.19, 65.19, 65.19, 65.19, 65.19, 65.19, 65.19, 65.19, 65.19, 65.19, 28.54, 28.54, 28.54, 28.54, 28.54, 28.54, 28.54, 28.54, 28.54, 28.54, 28.54, 28.54, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(47, 414063, '\'Eprex 10,000 U Pre-Filled Syringes \'', '\'BH\'', '\'USD\'', 651.88, 651.88, 651.88, 651.88, 651.88, 651.88, 651.88, 651.88, 651.88, 651.88, 651.88, 651.88, 205.08, 205.08, 205.08, 205.08, 205.08, 205.08, 205.08, 205.08, 205.08, 205.08, 205.08, 205.08, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(48, 414065, '\'Eprex 2,000 U Pre-Filled Syringes \'', '\'BH\'', '\'USD\'', 130.38, 130.38, 130.38, 130.38, 130.38, 130.38, 130.38, 130.38, 130.38, 130.38, 130.38, 130.38, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(49, 414066, '\'Eprex 3,000 U Pre-Filled Syringes \'', '\'BH\'', '\'USD\'', 91.5, 91.5, 91.5, 91.5, 91.5, 91.5, 91.5, 91.5, 91.5, 91.5, 91.5, 91.5, 91.5, 91.5, 91.5, 91.5, 91.5, 91.5, 91.5, 91.5, 91.5, 91.5, 91.5, 91.5, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(50, 0, '\'Cilest Tab. 21tab\'', '\'BH\'', '\'USD\'', 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(51, 0, '\'Cilest Tab. 36tab\'', '\'BH\'', '\'USD\'', 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(52, 377907, '\'Dacogen 5 mg Injection \'', '\'BH\'', '\'USD\'', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(53, 88836, '\'Daktarin Cream 2% 15g\'', '\'BH\'', '\'USD\'', 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(54, 0, '\'Daktarin Lotion 2% \'', '\'BH\'', '\'USD\'', 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(55, 415168, '\'Darzalex 100mg\'', '\'BH\'', '\'USD\'', 449.75, 449.75, 449.75, 449.75, 449.75, 449.75, 449.75, 449.75, 449.75, 449.75, 449.75, 449.75, 449.75, 449.75, 449.75, 449.75, 449.75, 449.75, 449.75, 449.75, 449.75, 449.75, 449.75, 449.75, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(56, 415169, '\'Darzalex 400mg\'', '\'BH\'', '\'USD\'', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(57, 0, '\'Doribax 500 mg Injection \'', '\'BH\'', '\'USD\'', 179.21, 179.21, 179.21, 179.21, 179.21, 179.21, 179.21, 179.21, 179.21, 179.21, 179.21, 179.21, 179.21, 179.21, 179.21, 179.21, 179.21, 179.21, 179.21, 179.21, 179.21, 179.21, 179.21, 179.21, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(58, 387401, '\'Durogesic Transdermal Patches 75 mcg/h\'', '\'BH\'', '\'USD\'', 80.1, 80.1, 80.1, 80.1, 80.1, 80.1, 80.1, 80.1, 80.1, 80.1, 80.1, 80.1, 80.1, 80.1, 80.1, 80.1, 80.1, 80.1, 80.1, 80.1, 80.1, 80.1, 80.1, 80.1, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(59, 414068, '\'Eprex 4,000 U Pre-Filled Syringes \'', '\'BH\'', '\'USD\'', 260.75, 260.75, 260.75, 260.75, 260.75, 260.75, 260.75, 260.75, 260.75, 260.75, 260.75, 260.75, 67.2, 67.2, 67.2, 67.2, 67.2, 67.2, 67.2, 67.2, 67.2, 67.2, 67.2, 67.2, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(60, 414067, '\'Eprex 40,000 U Pre-Filled Syringe \'', '\'BH\'', '\'USD\'', 326.56, 326.56, 326.56, 326.56, 326.56, 326.56, 326.56, 326.56, 326.56, 326.56, 326.56, 326.56, 183.54, 183.54, 183.54, 183.54, 183.54, 183.54, 183.54, 183.54, 183.54, 183.54, 183.54, 183.54, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(61, 0, '\'Eprex 5,000 U Pre-Filled Syringes \'', '\'BH\'', '\'USD\'', 325.94, 325.94, 325.94, 325.94, 325.94, 325.94, 325.94, 325.94, 325.94, 325.94, 325.94, 325.94, 78.67, 78.67, 78.67, 78.67, 78.67, 78.67, 78.67, 78.67, 78.67, 78.67, 78.67, 78.67, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(62, 414069, '\'Eprex 6,000 U Pre-Filled Syringes \'', '\'BH\'', '\'USD\'', 391.12, 391.12, 391.12, 391.12, 391.12, 391.12, 391.12, 391.12, 391.12, 391.12, 391.12, 391.12, 116, 116, 116, 116, 116, 116, 116, 116, 116, 116, 116, 116, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(63, 0, '\'Eprex 8,000 U Pre-Filled Syringes \'', '\'BH\'', '\'USD\'', 521.5, 521.5, 521.5, 521.5, 521.5, 521.5, 521.5, 521.5, 521.5, 521.5, 521.5, 521.5, 245.71, 245.71, 245.71, 245.71, 245.71, 245.71, 245.71, 245.71, 245.71, 245.71, 245.71, 245.71, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(64, 140788, '\'Evra Transdermal Patches \'', '\'BH\'', '\'USD\'', 8.17, 8.17, 8.17, 8.17, 8.17, 8.17, 8.17, 8.17, 8.17, 8.17, 8.17, 8.17, 8.17, 8.17, 8.17, 8.17, 8.17, 8.17, 8.17, 8.17, 8.17, 8.17, 8.17, 8.17, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(65, 377424, '\'Gyno Daktarin 1200 mg V. Capsule\'', '\'BH\'', '\'USD\'', 3.1, 3.1, 3.1, 3.1, 3.1, 3.1, 3.1, 3.1, 3.1, 3.1, 3.1, 3.1, 3.1, 3.1, 3.1, 3.1, 3.1, 3.1, 3.1, 3.1, 3.1, 3.1, 3.1, 3.1, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(66, 414691, '\'Gyno Daktarin 200 mg V. Capsules\'', '\'BH\'', '\'USD\'', 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(67, 414690, '\'Gyno Daktarin 400 mg V. Capsules\'', '\'BH\'', '\'USD\'', 3.94, 3.94, 3.94, 3.94, 3.94, 3.94, 3.94, 3.94, 3.94, 3.94, 3.94, 3.94, 3.94, 3.94, 3.94, 3.94, 3.94, 3.94, 3.94, 3.94, 3.94, 3.94, 3.94, 3.94, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(68, 418570, '\'Gyno-Daktarin V. Cream \'', '\'BH\'', '\'USD\'', 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(69, 140311, '\'Gyno-Pevaryl V. Cream \'', '\'BH\'', '\'USD\'', 7.77, 7.77, 7.77, 7.77, 7.77, 7.77, 7.77, 7.77, 7.77, 7.77, 7.77, 7.77, 7.77, 7.77, 7.77, 7.77, 7.77, 7.77, 7.77, 7.77, 7.77, 7.77, 7.77, 7.77, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(70, 414778, '\'Imbruvica 140mg Capsule \'', '\'BH\'', '\'USD\'', 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(71, 378218, '\'Intelence 100 mg Tab. \'', '\'BH\'', '\'USD\'', 508.5, 508.5, 508.5, 508.5, 508.5, 508.5, 508.5, 508.5, 508.5, 508.5, 508.5, 508.5, 508.5, 508.5, 508.5, 508.5, 508.5, 508.5, 508.5, 508.5, 508.5, 508.5, 508.5, 508.5, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(72, 416819, '\'Invega 3 mg Extended Release Tab. \'', '\'BH\'', '\'USD\'', 88.12, 88.12, 88.12, 88.12, 88.12, 88.12, 88.12, 88.12, 88.12, 88.12, 88.12, 88.12, 88.12, 88.12, 41.39, 41.39, 88.12, 88.12, 41.39, 41.39, 88.12, 88.12, 41.39, 41.39, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(73, 416821, '\'Invega 6 mg Extended Release Tab. \'', '\'BH\'', '\'USD\'', 88.12, 88.12, 88.12, 88.12, 88.12, 88.12, 88.12, 88.12, 88.12, 88.12, 88.12, 88.12, 88.12, 88.12, 48.8, 48.8, 88.12, 88.12, 48.8, 48.8, 88.12, 88.12, 48.8, 48.8, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(74, 416823, '\'Invega 9 mg Extended Release Tab. \'', '\'BH\'', '\'USD\'', 95.51, 95.51, 95.51, 95.51, 95.51, 95.51, 95.51, 95.51, 95.51, 95.51, 95.51, 95.51, 95.51, 95.51, 95.51, 95.51, 95.51, 95.51, 95.51, 95.51, 95.51, 95.51, 95.51, 95.51, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(75, 387760, '\'Invega Sustenna 100 mg/ 1 ml \'', '\'BH\'', '\'USD\'', 298.88, 298.88, 298.88, 298.88, 298.88, 298.88, 298.88, 298.88, 298.88, 298.88, 298.88, 298.88, 298.89, 298.89, 298.89, 298.89, 298.89, 298.89, 298.89, 298.89, 298.89, 298.89, 298.89, 298.89, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(76, 387761, '\'Invega Sustenna 150 mg/ 1.5 ml \'', '\'BH\'', '\'USD\'', 347.74, 347.74, 347.74, 347.74, 347.74, 347.74, 347.74, 347.74, 347.74, 347.74, 347.74, 347.74, 347.78, 347.78, 347.78, 347.78, 347.78, 347.78, 347.78, 347.78, 347.78, 347.78, 347.78, 347.78, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(77, 387758, '\'Invega Sustenna 50 mg/ 0.5 ml \'', '\'BH\'', '\'USD\'', 186.86, 186.86, 186.86, 186.86, 186.86, 186.86, 186.86, 186.86, 186.86, 186.86, 186.86, 186.86, 186.86, 186.86, 186.86, 186.86, 186.86, 186.86, 186.86, 186.86, 186.86, 186.86, 186.86, 186.86, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(78, 387759, '\'Invega Sustenna 75 mg/ 0.75 ml \'', '\'BH\'', '\'USD\'', 243.86, 243.86, 243.86, 243.86, 243.86, 243.86, 243.86, 243.86, 243.86, 243.86, 243.86, 243.86, 243.86, 243.86, 243.86, 243.86, 243.86, 243.86, 243.86, 243.86, 243.86, 243.86, 243.86, 243.86, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(79, 414907, '\'Invokana 100mg \'', '\'BH\'', '\'USD\'', 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(80, 414908, '\'Invokana 300mg\'', '\'BH\'', '\'USD\'', 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(81, 414089, '\'EPREX PROTECS 30000U 1X0.75ML\'', '\'BH\'', '\'USD\'', 103.86, 103.86, 103.86, 103.86, 103.86, 103.86, 103.86, 103.86, 103.86, 103.86, 103.86, 103.86, 103.86, 103.86, 103.86, 103.86, 103.86, 103.86, 103.86, 103.86, 103.86, 103.86, 103.86, 103.86, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(82, 32444, '\'Fentanyl 0.05 mg/ml Inj. 10ml x 50 amps\'', '\'BH\'', '\'USD\'', 101.9, 101.9, 101.9, 101.9, 101.9, 101.9, 101.9, 101.9, 101.9, 101.9, 101.9, 101.9, 101.9, 101.9, 101.9, 101.9, 101.9, 101.9, 101.9, 101.9, 101.9, 101.9, 101.9, 101.9, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(83, 412117, '\'Fentanyl 0.05 mg/ml Inj. 2ml x 50 amps\'', '\'BH\'', '\'USD\'', 19.73, 19.73, 19.73, 19.73, 19.73, 19.73, 19.73, 19.73, 19.73, 19.73, 19.73, 19.73, 19.73, 19.73, 19.73, 19.73, 19.73, 19.73, 19.73, 19.73, 19.73, 19.73, 19.73, 19.73, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(84, 0, '\'Guselkumab\'', '\'BH\'', '\'USD\'', 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(85, 387445, '\'Gyno Pevaryl 150 mg V. Suppositories\'', '\'BH\'', '\'USD\'', 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(86, 387447, '\'Gyno-Pevaryl Depot 150 mg V. Ovules\'', '\'BH\'', '\'USD\'', 4.89, 4.89, 4.89, 4.89, 4.89, 4.89, 4.89, 4.89, 4.89, 4.89, 4.89, 4.89, 4.89, 4.89, 4.89, 4.89, 4.89, 4.89, 4.89, 4.89, 4.89, 4.89, 4.89, 4.89, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(87, 96041, '\'Haldol 10mg 20 Tab\'', '\'BH\'', '\'USD\'', 2.68, 2.68, 2.68, 2.68, 2.68, 2.68, 2.68, 2.68, 2.68, 2.68, 2.68, 2.68, 2.68, 2.68, 2.68, 2.68, 2.68, 2.68, 2.68, 2.68, 2.68, 2.68, 2.68, 2.68, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(88, 0, '\'HALDOL 5MG 1000 TABL. QUELUZ ST.EXP.\'', '\'BH\'', '\'USD\'', 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(89, 96874, '\'Haldol 5mg tab\'', '\'BH\'', '\'USD\'', 6.9, 6.9, 6.9, 6.9, 6.9, 6.9, 6.9, 6.9, 6.9, 6.9, 6.9, 6.9, 6.9, 6.9, 6.9, 6.9, 6.9, 6.9, 6.9, 6.9, 6.9, 6.9, 6.9, 6.9, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(90, 412129, '\'Haldol Amp. 5mg/ml\'', '\'BH\'', '\'USD\'', 4.47, 4.47, 4.47, 4.47, 4.47, 4.47, 4.47, 4.47, 4.47, 4.47, 4.47, 4.47, 4.47, 4.47, 4.47, 4.47, 4.47, 4.47, 4.47, 4.47, 4.47, 4.47, 4.47, 4.47, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(91, 0, '\'HALDOL DEC 50MG/ML 5X1ML AMP. GSK-ST.EXP\'', '\'BH\'', '\'USD\'', 4.85, 4.85, 4.85, 4.85, 4.85, 4.85, 4.85, 4.85, 4.85, 4.85, 4.85, 4.85, 4.85, 4.85, 4.85, 4.85, 4.85, 4.85, 4.85, 4.85, 4.85, 4.85, 4.85, 4.85, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(92, 0, '\'Imbruvica Tab 140mg\'', '\'BH\'', '\'USD\'', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(93, 0, '\'Imbruvica Tab 280mg\'', '\'BH\'', '\'USD\'', 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(94, 0, '\'Imbruvica Tab 420mg\'', '\'BH\'', '\'USD\'', 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(95, 0, '\'Imbruvica Tab 560mg\'', '\'BH\'', '\'USD\'', 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(96, 412414, '\'Incivo 375 mg Film-Coated Tabs.\'', '\'BH\'', '\'USD\'', 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(97, 387907, '\'Jurnista 8mg Tablet \'', '\'BH\'', '\'USD\'', 36.01, 36.01, 36.01, 36.01, 36.01, 36.01, 36.01, 36.01, 36.01, 36.01, 36.01, 36.01, 36.01, 36.01, 36.01, 36.01, 36.01, 36.01, 36.01, 36.01, 36.01, 36.01, 36.01, 36.01, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(98, 387984, '\'Motilium supp. 30 mg for Child.\'', '\'BH\'', '\'USD\'', 2.81, 2.81, 2.81, 2.81, 2.81, 2.81, 2.81, 2.81, 2.81, 2.81, 2.81, 2.81, 2.81, 2.81, 2.81, 2.81, 2.81, 2.81, 2.81, 2.81, 2.81, 2.81, 2.81, 2.81, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(99, 416306, '\'Olysio 150 mg capsules\'', '\'BH\'', '\'USD\'', 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 500, 500, 500, 500, 500, 500, 500, 500, 500, 500, 500, 500, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(100, 0, '\'Opsumit 10mg\'', '\'BH\'', '\'USD\'', 2, 2, 2, 1, 2, 2, 2, 1, 2, 2, 2, 1, 2, 2, 2, 1, 2, 2, 2, 1, 2, 2, 2, 1, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(101, 416006, '\'Pariet 10 mg Tab. 14s\'', '\'BH\'', '\'USD\'', 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(102, 416007, '\'Pariet 10 mg Tab. 28s\'', '\'BH\'', '\'USD\'', 16.73, 16.73, 16.73, 16.73, 16.73, 16.73, 16.73, 16.73, 16.73, 16.73, 16.73, 16.73, 16.73, 16.73, 16.73, 16.73, 16.73, 16.73, 16.73, 16.73, 16.73, 16.73, 16.73, 16.73, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(103, 96394, '\'Reminyl 4 mg Tab.\'', '\'BH\'', '\'USD\'', 13.41, 13.41, 13.41, 13.41, 13.41, 13.41, 13.41, 13.41, 13.41, 13.41, 13.41, 13.41, 13.41, 13.41, 13.41, 13.41, 13.41, 13.41, 13.41, 13.41, 13.41, 13.41, 13.41, 13.41, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(104, 90839, '\'Reminyl 4 mg/ml Oral Solution  \'', '\'BH\'', '\'USD\'', 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(105, 90474, '\'Reminyl 8 mg Tab.\'', '\'BH\'', '\'USD\'', 69.66, 69.66, 69.66, 69.66, 69.66, 69.66, 69.66, 69.66, 69.66, 69.66, 69.66, 69.66, 69.66, 69.66, 69.66, 69.66, 69.66, 69.66, 69.66, 69.66, 69.66, 69.66, 69.66, 69.66, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(106, 377057, '\'Reminyl PR 16 mg 28 Capsule\'', '\'BH\'', '\'USD\'', 98, 98, 98, 98, 98, 98, 98, 98, 98, 98, 98, 98, 98, 98, 98, 98, 98, 98, 98, 98, 98, 98, 98, 98, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(107, 377058, '\'Reminyl PR 24 mg 28 Capsule\'', '\'BH\'', '\'USD\'', 120, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(108, 90474, '\'Reminyl PR 8 mg 28 Capsule\'', '\'BH\'', '\'USD\'', 76, 76, 76, 76, 76, 76, 76, 76, 76, 76, 76, 76, 76, 76, 76, 76, 76, 76, 76, 76, 76, 76, 76, 76, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(109, 415065, '\'Rezolsta\'', '\'BH\'', '\'USD\'', 463, 463, 463, 463, 463, 463, 463, 463, 463, 463, 463, 463, 463, 463, 463, 463, 463, 463, 463, 463, 463, 463, 463, 463, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(110, 0, '\'Apalutamide\'', '\'BH\'', '\'USD\'', 3, 3, 2, 2, 3, 3, 2, 2, 3, 3, 2, 2, 3, 3, 2, 2, 3, 3, 2, 2, 3, 3, 2, 2, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(111, 376853, '\'Risperdal 1mg Tab. 6s\'', '\'BH\'', '\'USD\'', 4.58, 4.58, 4.58, 4.58, 4.58, 4.58, 4.58, 4.58, 4.58, 4.58, 4.58, 4.58, 2.29, 2.29, 2.29, 2.29, 2.29, 2.29, 2.29, 2.29, 2.29, 2.29, 2.29, 2.29, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(112, 88082, '\'Risperdal 2mg Tab. 60s\'', '\'BH\'', '\'USD\'', 60.12, 60.12, 60.12, 60.12, 60.12, 60.12, 60.12, 60.12, 60.12, 60.12, 60.12, 60.12, 29.27, 29.27, 29.27, 29.27, 29.27, 29.27, 29.27, 29.27, 29.27, 29.27, 29.27, 29.27, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(113, 96327, '\'Risperdal 4mg Tab. 20s\'', '\'BH\'', '\'USD\'', 34.89, 34.89, 34.89, 34.89, 34.89, 34.89, 34.89, 34.89, 34.89, 34.89, 34.89, 34.89, 17.45, 17.45, 17.45, 17.45, 17.45, 17.45, 17.45, 17.45, 17.45, 17.45, 17.45, 17.45, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(114, 96569, '\'Risperdal 4mg Tab. 60s\'', '\'BH\'', '\'USD\'', 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(115, 0, '\'Simponi 100mg PFP\'', '\'BH\'', '\'USD\'', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 900, 900, 900, 900, 900, 900, 900, 900, 900, 900, 900, 900, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(116, 414549, '\'SIRTURO 100MG 188 Tablets\'', '\'BH\'', '\'USD\'', 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(117, 414097, '\'SPORANOX 1% 1X150ML OPLOS\'', '\'BH\'', '\'USD\'', 70.3, 70.3, 70.3, 70.3, 70.3, 70.3, 70.3, 70.3, 70.3, 70.3, 70.3, 70.3, 70.3, 70.3, 70.3, 70.3, 70.3, 70.3, 70.3, 70.3, 70.3, 70.3, 70.3, 70.3, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(118, 416009, '\'Pariet 20 mg Tab. 14s\'', '\'BH\'', '\'USD\'', 12.06, 3.81, 3.81, 3.81, 12.06, 3.81, 3.81, 3.81, 12.06, 3.81, 3.81, 3.81, 11.2, 3.81, 3.81, 3.81, 11.2, 3.81, 3.81, 3.81, 11.2, 3.81, 3.81, 3.81, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(119, 416010, '\'Pariet 20 mg Tab. 28s\'', '\'BH\'', '\'USD\'', 26.01, 26.01, 26.01, 26.01, 26.01, 26.01, 26.01, 26.01, 26.01, 26.01, 26.01, 26.01, 26.01, 26.01, 26.01, 26.01, 26.01, 26.01, 26.01, 26.01, 26.01, 26.01, 26.01, 26.01, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(120, 0, '\'Spravato 2x28mg\'', '\'BH\'', '\'USD\'', 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(121, 0, '\'Spravato 3x28mg\'', '\'BH\'', '\'USD\'', 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(122, 0, '\'Stelara 130mg\'', '\'BH\'', '\'USD\'', 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(123, 0, '\'Symtuza\'', '\'BH\'', '\'USD\'', 869, 869, 869, 869, 869, 869, 869, 869, 869, 869, 869, 869, 869, 869, 869, 869, 869, 869, 869, 869, 869, 869, 869, 869, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(124, 141023, '\'Topamax 200 mg Tab.\'', '\'BH\'', '\'USD\'', 69.68, 69.68, 69.68, 69.68, 69.68, 69.68, 69.68, 69.68, 69.68, 69.68, 69.68, 69.68, 69.68, 69.68, 69.68, 69.68, 69.68, 69.68, 69.68, 69.68, 69.68, 69.68, 69.68, 69.68, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(125, 412303, '\'Topamax 25 mg Sprinkle Cap.\'', '\'BH\'', '\'USD\'', 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(126, 412305, '\'Topamax 50 mg Sprinkle Cap.\'', '\'BH\'', '\'USD\'', 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(127, 418626, '\'Trevicta 175mg (50mg eq.)\'', '\'BH\'', '\'USD\'', 507.18, 507.18, 507.18, 507.18, 507.18, 507.18, 507.18, 507.18, 507.18, 507.18, 507.18, 507.18, 507.18, 507.18, 507.18, 507.18, 507.18, 507.18, 507.18, 507.18, 507.18, 507.18, 507.18, 507.18, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(128, 418624, '\'Trevicta 263mg (75mg eq.) \'', '\'BH\'', '\'USD\'', 693.81, 693.81, 693.81, 693.81, 693.81, 693.81, 693.81, 693.81, 693.81, 693.81, 693.81, 693.81, 693.81, 693.81, 693.81, 693.81, 693.81, 693.81, 693.81, 693.81, 693.81, 693.81, 693.81, 693.81, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(129, 418623, '\'Trevicta 360mg (100mg eq.) \'', '\'BH\'', '\'USD\'', 872.34, 872.34, 872.34, 872.34, 872.34, 872.34, 872.34, 872.34, 872.34, 872.34, 872.34, 872.34, 872.34, 872.34, 872.34, 872.34, 872.34, 872.34, 872.34, 872.34, 872.34, 872.34, 872.34, 872.34, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(130, 418621, '\'Trevicta 525mg (150mg eq.) \'', '\'BH\'', '\'USD\'', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(131, 0, '\'Uptravi\'', '\'BH\'', '\'USD\'', 4, 4, 4, 2, 4, 4, 4, 2, 4, 4, 4, 2, 4, 4, 4, 2, 4, 4, 4, 2, 4, 4, 4, 2, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(132, 0, '\'VERMOX 500MG 1 TABL. MEWA \'', '\'BH\'', '\'USD\'', 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(133, 0, '\'Zavesca 84 cap 100mg \'', '\'BH\'', '\'USD\'', 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(134, 0, '\'Zytiga 500 mg Tabs\'', '\'BH\'', '\'USD\'', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(135, 414287, '\'Stelara 45mg/0.5ml \'', '\'KW\'', '\'USD\'', 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(136, 414288, '\'Stelara 90mg/1ml \'', '\'KW\'', '\'USD\'', 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(137, 387104, '\'Prezista 400 mg Tablets\'', '\'KW\'', '\'USD\'', 402.77, 402.77, 402.77, 402.77, 402.77, 402.77, 402.77, 402.77, 402.77, 402.77, 402.77, 402.77, 402.77, 402.77, 402.77, 402.77, 402.77, 402.77, 402.77, 402.77, 402.77, 402.77, 402.77, 402.77, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(138, 0, '\'Stelara 130mg\'', '\'KW\'', '\'USD\'', 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(139, 387107, '\'Prezista 600 mg Tablets\'', '\'KW\'', '\'USD\'', 615.22, 615.22, 615.22, 615.22, 615.22, 615.22, 615.22, 615.22, 615.22, 615.22, 615.22, 615.22, 615.22, 615.22, 615.22, 615.22, 615.22, 615.22, 615.22, 615.22, 615.22, 615.22, 615.22, 615.22, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(140, 414900, '\'Remicade 100 mg \'', '\'KW\'', '\'USD\'', 363.63, 363.63, 363.63, 363.63, 363.63, 363.63, 363.63, 363.63, 363.63, 363.63, 363.63, 363.63, 260, 260, 260, 260, 260, 260, 260, 260, 260, 260, 260, 260, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(141, 412675, '\'Simponi 50 mg/ 0.5 ml Injection (PFP)\'', '\'KW\'', '\'USD\'', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(142, 414434, '\'Caelyx 2 mg/ml\'', '\'KW\'', '\'USD\'', 512, 512, 512, 512, 512, 512, 512, 512, 512, 512, 512, 512, 512, 512, 512, 512, 512, 512, 512, 512, 512, 512, 512, 512, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(143, 415168, '\'Darzalex 100mg\'', '\'KW\'', '\'USD\'', 449.75, 449.75, 449.75, 449.75, 449.75, 449.75, 449.75, 449.75, 449.75, 449.75, 449.75, 449.75, 449.75, 449.75, 449.75, 449.75, 449.75, 449.75, 449.75, 449.75, 449.75, 449.75, 449.75, 449.75, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(144, 415169, '\'Darzalex 400mg\'', '\'KW\'', '\'USD\'', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(145, 387397, '\'Durogesic Transdermal Patches 100 mcg/h\'', '\'KW\'', '\'USD\'', 98.73, 98.73, 98.73, 98.73, 98.73, 98.73, 98.73, 98.73, 98.73, 98.73, 98.73, 98.73, 98.73, 98.73, 98.73, 98.73, 98.73, 98.73, 98.73, 98.73, 98.73, 98.73, 98.73, 98.73, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(146, 387398, '\'Durogesic Transdermal Patches 12 mcg/h\'', '\'KW\'', '\'USD\'', 17.62, 17.62, 17.62, 17.62, 17.62, 17.62, 17.62, 17.62, 17.62, 17.62, 17.62, 17.62, 17.62, 17.62, 17.62, 17.62, 17.62, 17.62, 17.62, 17.62, 17.62, 17.62, 17.62, 17.62, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(147, 0, '\'Cilest Tab. 21tab\'', '\'KW\'', '\'USD\'', 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(148, 387399, '\'Durogesic Transdermal Patches 25 mcg/h\'', '\'KW\'', '\'USD\'', 31.12, 31.12, 7.11, 7.11, 31.12, 31.12, 7.11, 7.11, 31.12, 31.12, 7.11, 7.11, 31.12, 31.12, 7.11, 7.11, 31.12, 31.12, 7.11, 7.11, 31.12, 31.12, 7.11, 7.11, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(149, 387400, '\'Durogesic Transdermal Patches 50 mcg/h\'', '\'KW\'', '\'USD\'', 52.29, 52.29, 13.07, 13.07, 52.29, 52.29, 13.07, 13.07, 52.29, 52.29, 13.07, 13.07, 52.29, 52.29, 13.07, 13.07, 52.29, 52.29, 13.07, 13.07, 52.29, 52.29, 13.07, 13.07, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(150, 387401, '\'Durogesic Transdermal Patches 75 mcg/h\'', '\'KW\'', '\'USD\'', 80.1, 80.1, 80.1, 80.1, 80.1, 80.1, 80.1, 80.1, 80.1, 80.1, 80.1, 80.1, 80.1, 80.1, 80.1, 80.1, 80.1, 80.1, 80.1, 80.1, 80.1, 80.1, 80.1, 80.1, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(151, 0, '\'Cilest Tab. 36tab\'', '\'KW\'', '\'USD\'', 7.39, 7.39, 7.39, 7.39, 7.39, 7.39, 7.39, 7.39, 7.39, 7.39, 7.39, 7.39, 7.39, 7.39, 7.39, 7.39, 7.39, 7.39, 7.39, 7.39, 7.39, 7.39, 7.39, 7.39, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(152, 32442, '\'Daktacort Cream                 \'', '\'KW\'', '\'USD\'', 2.31, 2.31, 2.31, 2.31, 2.31, 2.31, 2.31, 2.31, 2.31, 2.31, 2.31, 2.31, 1.06, 1.06, 1.06, 1.06, 1.06, 1.06, 1.06, 1.06, 1.06, 1.06, 1.06, 1.06, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(153, 88877, '\'Daktarin Cream 2% 30g\'', '\'KW\'', '\'USD\'', 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(154, 0, '\'Daktarin Lotion 2% \'', '\'KW\'', '\'USD\'', 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(155, 414064, '\'Eprex 1,000 U Pre-Filled Syringes \'', '\'KW\'', '\'USD\'', 28.56, 28.56, 28.56, 28.56, 28.56, 28.56, 28.56, 28.56, 28.56, 28.56, 28.56, 28.56, 28.56, 28.56, 28.56, 28.56, 28.56, 28.56, 28.56, 28.56, 28.56, 28.56, 28.56, 28.56, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(156, 414063, '\'Eprex 10,000 U Pre-Filled Syringes \'', '\'KW\'', '\'USD\'', 298.4, 298.4, 298.4, 298.4, 298.4, 298.4, 298.4, 298.4, 298.4, 298.4, 298.4, 298.4, 205.08, 205.08, 205.08, 205.08, 205.08, 205.08, 205.08, 205.08, 205.08, 205.08, 205.08, 205.08, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(157, 414065, '\'Eprex 2,000 U Pre-Filled Syringes \'', '\'KW\'', '\'USD\'', 59.68, 59.68, 59.68, 59.68, 59.68, 59.68, 59.68, 59.68, 59.68, 59.68, 59.68, 59.68, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(158, 414066, '\'Eprex 3,000 U Pre-Filled Syringes \'', '\'KW\'', '\'USD\'', 91.5, 91.5, 91.5, 91.5, 91.5, 91.5, 91.5, 91.5, 91.5, 91.5, 91.5, 91.5, 91.5, 91.5, 91.5, 91.5, 91.5, 91.5, 91.5, 91.5, 91.5, 91.5, 91.5, 91.5, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(159, 414068, '\'Eprex 4,000 U Pre-Filled Syringes \'', '\'KW\'', '\'USD\'', 119.36, 119.36, 119.36, 119.36, 119.36, 119.36, 119.36, 119.36, 119.36, 119.36, 119.36, 119.36, 67.2, 67.2, 67.2, 67.2, 67.2, 67.2, 67.2, 67.2, 67.2, 67.2, 67.2, 67.2, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(160, 414067, '\'Eprex 40,000 U Pre-Filled Syringe \'', '\'KW\'', '\'USD\'', 183.54, 183.54, 183.54, 183.54, 183.54, 183.54, 183.54, 183.54, 183.54, 183.54, 183.54, 183.54, 183.54, 183.54, 183.54, 183.54, 183.54, 183.54, 183.54, 183.54, 183.54, 183.54, 183.54, 183.54, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(161, 0, '\'Eprex 5,000 U Pre-Filled Syringes \'', '\'KW\'', '\'USD\'', 203.37, 203.37, 203.37, 203.37, 203.37, 203.37, 203.37, 203.37, 203.37, 203.37, 203.37, 203.37, 110, 110, 110, 110, 110, 110, 110, 110, 110, 110, 110, 110, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(162, 414069, '\'Eprex 6,000 U Pre-Filled Syringes \'', '\'KW\'', '\'USD\'', 203.37, 203.37, 203.37, 203.37, 203.37, 203.37, 203.37, 203.37, 203.37, 203.37, 203.37, 203.37, 116, 116, 116, 116, 116, 116, 116, 116, 116, 116, 116, 116, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(163, 0, '\'Eprex 8,000 U Pre-Filled Syringes \'', '\'KW\'', '\'USD\'', 245.71, 245.71, 245.71, 245.71, 245.71, 245.71, 245.71, 245.71, 245.71, 245.71, 245.71, 245.71, 245.71, 245.71, 245.71, 245.71, 245.71, 245.71, 245.71, 245.71, 245.71, 245.71, 245.71, 245.71, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(164, 32444, '\'Fentanyl 0.05 mg/ml Inj. 10ml x 50 amps\'', '\'KW\'', '\'USD\'', 102, 102, 102, 40.53, 102, 102, 102, 40.53, 102, 102, 102, 40.53, 102, 102, 102, 40.53, 102, 102, 102, 40.53, 102, 102, 102, 40.53, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(165, 412117, '\'Fentanyl 0.05 mg/ml Inj. 2ml x 50 amps\'', '\'KW\'', '\'USD\'', 19.73, 19.73, 19.73, 9.62, 19.73, 19.73, 19.73, 9.62, 19.73, 19.73, 19.73, 9.62, 19.73, 19.73, 19.73, 9.62, 19.73, 19.73, 19.73, 9.62, 19.73, 19.73, 19.73, 9.62, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(166, 0, '\'Guselkumab\'', '\'KW\'', '\'USD\'', 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(167, 414778, '\'Imbruvica 140mg Capsule \'', '\'KW\'', '\'USD\'', 9, 8, 8, 8, 9, 8, 8, 8, 9, 8, 8, 8, 9, 8, 8, 8, 9, 8, 8, 8, 9, 8, 8, 8, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(168, 378218, '\'Intelence 100 mg Tab. \'', '\'KW\'', '\'USD\'', 491.87, 491.87, 491.87, 491.87, 491.87, 491.87, 491.87, 491.87, 491.87, 491.87, 491.87, 491.87, 491.87, 491.87, 491.87, 491.87, 491.87, 491.87, 491.87, 491.87, 491.87, 491.87, 491.87, 491.87, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(169, 387760, '\'Invega Sustenna 100 mg/ 1 ml \'', '\'KW\'', '\'USD\'', 298.88, 298.88, 298.88, 298.88, 298.88, 298.88, 298.88, 298.88, 298.88, 298.88, 298.88, 298.88, 298.88, 298.88, 298.88, 298.88, 298.88, 298.88, 298.88, 298.88, 298.88, 298.88, 298.88, 298.88, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(170, 387761, '\'Invega Sustenna 150 mg/ 1.5 ml \'', '\'KW\'', '\'USD\'', 347.74, 347.74, 347.74, 347.74, 347.74, 347.74, 347.74, 347.74, 347.74, 347.74, 347.74, 347.74, 347.74, 347.74, 347.74, 347.74, 347.74, 347.74, 347.74, 347.74, 347.74, 347.74, 347.74, 347.74, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(171, 387758, '\'Invega Sustenna 50 mg/ 0.5 ml \'', '\'KW\'', '\'USD\'', 186.86, 186.86, 186.86, 186.86, 186.86, 186.86, 186.86, 186.86, 186.86, 186.86, 186.86, 186.86, 186.86, 186.86, 186.86, 186.86, 186.86, 186.86, 186.86, 186.86, 186.86, 186.86, 186.86, 186.86, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(172, 387759, '\'Invega Sustenna 75 mg/ 0.75 ml \'', '\'KW\'', '\'USD\'', 243.86, 243.86, 243.86, 243.86, 243.86, 243.86, 243.86, 243.86, 243.86, 243.86, 243.86, 243.86, 243.86, 243.86, 243.86, 243.86, 243.86, 243.86, 243.86, 243.86, 243.86, 243.86, 243.86, 243.86, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(173, 377017, '\'Daktarin Powder 2%\'', '\'KW\'', '\'USD\'', 2.19, 2.19, 2.19, 2.19, 2.19, 2.19, 2.19, 2.19, 2.19, 2.19, 2.19, 2.19, 2.19, 2.19, 2.19, 2.19, 2.19, 2.19, 2.19, 2.19, 2.19, 2.19, 2.19, 2.19, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(174, 0, '\'Doribax 500 mg Injection \'', '\'KW\'', '\'USD\'', 213.4, 213.4, 213.4, 213.4, 213.4, 213.4, 213.4, 213.4, 213.4, 213.4, 213.4, 213.4, 213.4, 213.4, 213.4, 213.4, 213.4, 213.4, 213.4, 213.4, 213.4, 213.4, 213.4, 213.4, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(175, 0, '\'Edurant\'', '\'KW\'', '\'USD\'', 264.9, 264.9, 264.9, 264.9, 264.9, 264.9, 264.9, 264.9, 264.9, 264.9, 264.9, 264.9, 264.9, 264.9, 264.9, 264.9, 264.9, 264.9, 264.9, 264.9, 264.9, 264.9, 264.9, 264.9, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00');
INSERT INTO `jnj_pricing_dataentry` (`id`, `material`, `SKU`, `countryCode`, `currency`, `cif_jan`, `cif_feb`, `cif_mar`, `cif_apr`, `cif_may`, `cif_jun`, `cif_jul`, `cif_aug`, `cif_sep`, `cif_oct`, `cif_nov`, `cif_dec`, `tnd_jan`, `tnd_feb`, `tnd_mar`, `tnd_apr`, `tnd_may`, `tnd_jun`, `tnd_jul`, `tnd_aug`, `tnd_sep`, `tnd_oct`, `tnd_nov`, `tnd_dec`, `discounts`, `focs`, `totalDiscount`, `month`, `year`, `createDate`, `ModifiedDate`) VALUES
(176, 0, '\'HALDOL 5MG/ML 5X1ML AMP. GSK-ST.EXP\'', '\'KW\'', '\'USD\'', 5.14, 5.14, 5.14, 5.14, 5.14, 5.14, 5.14, 5.14, 5.14, 5.14, 5.14, 5.14, 5.14, 5.14, 5.14, 5.14, 5.14, 5.14, 5.14, 5.14, 5.14, 5.14, 5.14, 5.14, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(177, 0, '\'HALDOL DEC 50MG/ML 5X1ML AMP. GSK-ST.EXP\'', '\'KW\'', '\'USD\'', 4.85, 4.85, 4.85, 4.85, 4.85, 4.85, 4.85, 4.85, 4.85, 4.85, 4.85, 4.85, 4.85, 4.85, 4.85, 4.85, 4.85, 4.85, 4.85, 4.85, 4.85, 4.85, 4.85, 4.85, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(178, 0, '\'Imbruvica Tab 140mg\'', '\'KW\'', '\'USD\'', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(179, 0, '\'Imbruvica Tab 280mg\'', '\'KW\'', '\'USD\'', 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(180, 0, '\'Imbruvica Tab 420mg\'', '\'KW\'', '\'USD\'', 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(181, 0, '\'Imbruvica Tab 560mg\'', '\'KW\'', '\'USD\'', 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(182, 412414, '\'Incivo 375 mg Film-Coated Tabs.\'', '\'KW\'', '\'USD\'', 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(183, 412855, '\'LEUSTATIN 1MG/ML 7X10ML VIAL\'', '\'KW\'', '\'USD\'', 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(184, 416306, '\'Olysio 150 mg capsules\'', '\'KW\'', '\'USD\'', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 500, 500, 500, 500, 500, 500, 500, 500, 500, 500, 500, 500, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(185, 416006, '\'Pariet 10 mg Tab. 14s\'', '\'KW\'', '\'USD\'', 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(186, 416007, '\'Pariet 10 mg Tab. 28s\'', '\'KW\'', '\'USD\'', 16.73, 16.73, 16.73, 16.73, 16.73, 16.73, 16.73, 16.73, 16.73, 16.73, 16.73, 16.73, 16.73, 16.73, 16.73, 16.73, 16.73, 16.73, 16.73, 16.73, 16.73, 16.73, 16.73, 16.73, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(187, 0, '\'Apalutamide\'', '\'KW\'', '\'USD\'', 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(188, 412126, '\'Rapifen Amp 500mcg/ml 10ml x 5 Amp\'', '\'KW\'', '\'USD\'', 19.24, 19.24, 19.24, 19.24, 19.24, 19.24, 19.24, 19.24, 19.24, 19.24, 19.24, 19.24, 19.24, 19.24, 19.24, 19.24, 19.24, 19.24, 19.24, 19.24, 19.24, 19.24, 19.24, 19.24, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(189, 96394, '\'Reminyl 4 mg Tab.\'', '\'KW\'', '\'USD\'', 13.41, 13.41, 13.41, 13.41, 13.41, 13.41, 13.41, 13.41, 13.41, 13.41, 13.41, 13.41, 13.41, 13.41, 13.41, 13.41, 13.41, 13.41, 13.41, 13.41, 13.41, 13.41, 13.41, 13.41, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(190, 90839, '\'Reminyl 4 mg/ml Oral Solution  \'', '\'KW\'', '\'USD\'', 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(191, 90474, '\'Reminyl 8 mg Tab.\'', '\'KW\'', '\'USD\'', 69.65, 69.65, 69.65, 69.65, 69.65, 69.65, 69.65, 69.65, 69.65, 69.65, 69.65, 69.65, 69.66, 69.66, 69.66, 69.66, 69.66, 69.66, 69.66, 69.66, 69.66, 69.66, 69.66, 69.66, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(192, 387691, '\'Concerta 18mg  Extended Release Tab.\'', '\'KW\'', '\'USD\'', 39.49, 39.49, 39.49, 39.49, 39.49, 39.49, 39.49, 39.49, 39.49, 39.49, 39.49, 39.49, 23.54, 23.54, 23.54, 23.54, 23.54, 23.54, 23.54, 23.54, 23.54, 23.54, 23.54, 23.54, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(193, 387693, '\'Concerta 36mg Extended Release Tab.\'', '\'KW\'', '\'USD\'', 51.43, 51.43, 51.43, 51.43, 51.43, 51.43, 51.43, 51.43, 51.43, 51.43, 51.43, 51.43, 32.69, 32.69, 32.69, 32.69, 32.69, 32.69, 32.69, 32.69, 32.69, 32.69, 32.69, 32.69, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(194, 415065, '\'Rezolsta\'', '\'KW\'', '\'USD\'', 463, 463, 463, 463, 463, 463, 463, 463, 463, 463, 463, 463, 463, 463, 463, 463, 463, 463, 463, 463, 463, 463, 463, 463, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(195, 32441, '\'Daktarin Oral Gel 2%\'', '\'KW\'', '\'USD\'', 3.19, 3.19, 3.19, 3.19, 3.19, 3.19, 3.19, 3.19, 3.19, 3.19, 3.19, 3.19, 3.19, 3.19, 3.19, 3.19, 3.19, 3.19, 3.19, 3.19, 3.19, 3.19, 3.19, 3.19, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(196, 140788, '\'Evra Transdermal Patches \'', '\'KW\'', '\'USD\'', 8.17, 8.17, 8.17, 8.17, 8.17, 8.17, 8.17, 8.17, 8.17, 8.17, 8.17, 8.17, 8.17, 8.17, 8.17, 8.17, 8.17, 8.17, 8.17, 8.17, 8.17, 8.17, 8.17, 8.17, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(197, 377424, '\'Gyno Daktarin 1200 mg V. Capsule\'', '\'KW\'', '\'USD\'', 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(198, 414690, '\'Gyno Daktarin 400 mg V. Capsules\'', '\'KW\'', '\'USD\'', 3.94, 3.94, 3.94, 3.94, 3.94, 3.94, 3.94, 3.94, 3.94, 3.94, 3.94, 3.94, 3.94, 3.94, 3.94, 3.94, 3.94, 3.94, 3.94, 3.94, 3.94, 3.94, 3.94, 3.94, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(199, 387445, '\'Gyno Pevaryl 150 mg V. Suppositories\'', '\'KW\'', '\'USD\'', 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(200, 88878, '\'Gyno-Daktarin V. Cream \'', '\'KW\'', '\'USD\'', 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(201, 387447, '\'Gyno-Pevaryl Depot 150 mg V. Ovules\'', '\'KW\'', '\'USD\'', 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(202, 140311, '\'Gyno-Pevaryl V. Cream \'', '\'KW\'', '\'USD\'', 7.77, 7.77, 7.77, 7.77, 7.77, 7.77, 7.77, 7.77, 7.77, 7.77, 7.77, 7.77, 7.77, 7.77, 7.77, 7.77, 7.77, 7.77, 7.77, 7.77, 7.77, 7.77, 7.77, 7.77, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(203, 416819, '\'Invega 3 mg Extended Release Tab. \'', '\'KW\'', '\'USD\'', 88.12, 88.12, 88.12, 88.12, 88.12, 88.12, 88.12, 88.12, 88.12, 88.12, 88.12, 88.12, 88.12, 88.12, 41.39, 41.39, 88.12, 88.12, 41.39, 41.39, 88.12, 88.12, 41.39, 41.39, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(204, 416821, '\'Invega 6 mg Extended Release Tab. \'', '\'KW\'', '\'USD\'', 88.12, 88.12, 88.12, 88.12, 88.12, 88.12, 88.12, 88.12, 88.12, 88.12, 88.12, 88.12, 88.12, 88.12, 48.8, 48.8, 88.12, 88.12, 48.8, 48.8, 88.12, 88.12, 48.8, 48.8, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(205, 416823, '\'Invega 9 mg Extended Release Tab. \'', '\'KW\'', '\'USD\'', 95.51, 95.51, 95.51, 95.51, 95.51, 95.51, 95.51, 95.51, 95.51, 95.51, 95.51, 95.51, 95.51, 95.51, 95.51, 95.51, 95.51, 95.51, 95.51, 95.51, 95.51, 95.51, 95.51, 95.51, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(206, 414907, '\'Invokana 100mg \'', '\'KW\'', '\'USD\'', 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(207, 87518, '\'Risperdal 1 mg/ml Oral Solution\'', '\'KW\'', '\'USD\'', 46.52, 46.52, 46.52, 46.52, 46.52, 46.52, 46.52, 46.52, 46.52, 46.52, 46.52, 46.52, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(208, 414908, '\'Invokana 300mg\'', '\'KW\'', '\'USD\'', 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(209, 418515, '\'Motilium 1 mg/ml Oral Suspension 100ml\'', '\'KW\'', '\'USD\'', 1.6, 1.6, 1.6, 1.6, 1.6, 1.6, 1.6, 1.6, 1.6, 1.6, 1.6, 1.6, 1.6, 1.6, 1.6, 1.6, 1.6, 1.6, 1.6, 1.6, 1.6, 1.6, 1.6, 1.6, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(210, 32451, '\'Motilium 1 mg/ml Oral Suspension 200ml\'', '\'KW\'', '\'USD\'', 3.2, 3.2, 3.2, 3.2, 3.2, 3.2, 3.2, 3.2, 3.2, 3.2, 3.2, 3.2, 3.2, 3.2, 3.2, 3.2, 3.2, 3.2, 3.2, 3.2, 3.2, 3.2, 3.2, 3.2, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(211, 418514, '\'Motilium 10 mg Tab. 30s\'', '\'KW\'', '\'USD\'', 3.3, 3.3, 3.3, 3.3, 3.3, 3.3, 3.3, 3.3, 3.3, 3.3, 3.3, 3.3, 3.3, 3.3, 3.3, 3.3, 3.3, 3.3, 3.3, 3.3, 3.3, 3.3, 3.3, 3.3, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(212, 414696, '\'Nizoral Cream 2 %\'', '\'KW\'', '\'USD\'', 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(213, 377413, '\'Sibelium caps 5mg\'', '\'KW\'', '\'USD\'', 2.92, 2.92, 2.92, 2.92, 2.92, 2.92, 2.92, 2.92, 2.92, 2.92, 2.92, 2.92, 2.92, 2.92, 2.92, 2.92, 2.92, 2.92, 2.92, 2.92, 2.92, 2.92, 2.92, 2.92, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(214, 0, '\'Opsumit 10mg\'', '\'KW\'', '\'USD\'', 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(215, 416009, '\'Pariet 20 mg Tab. 14s\'', '\'KW\'', '\'USD\'', 13.01, 13.01, 13.01, 13.01, 13.01, 13.01, 13.01, 13.01, 13.01, 13.01, 13.01, 13.01, 11.2, 11.2, 11.2, 11.2, 11.2, 11.2, 11.2, 11.2, 11.2, 11.2, 11.2, 11.2, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(216, 416010, '\'Pariet 20 mg Tab. 28s\'', '\'KW\'', '\'USD\'', 26.01, 26.01, 26.01, 26.01, 26.01, 26.01, 26.01, 26.01, 26.01, 26.01, 26.01, 26.01, 26.01, 26.01, 26.01, 26.01, 26.01, 26.01, 26.01, 26.01, 26.01, 26.01, 26.01, 26.01, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(217, 140307, '\'Pevaryl Cream 1 % 15g\'', '\'KW\'', '\'USD\'', 1.97, 1.97, 1.97, 1.97, 1.97, 1.97, 1.97, 1.97, 1.97, 1.97, 1.97, 1.97, 1.97, 1.97, 1.97, 1.97, 1.97, 1.97, 1.97, 1.97, 1.97, 1.97, 1.97, 1.97, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(218, 140309, '\'Pevaryl Cream 1 % 30g\'', '\'KW\'', '\'USD\'', 3.64, 3.64, 3.64, 3.64, 3.64, 3.64, 3.64, 3.64, 3.64, 3.64, 3.64, 3.64, 2.6, 2.6, 2.6, 2.6, 2.6, 2.6, 2.6, 2.6, 2.6, 2.6, 2.6, 2.6, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(219, 412323, '\'Pevisone Cream \'', '\'KW\'', '\'USD\'', 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(220, 414050, '\'Resolor 1 mg Film-Coated Tabs.\'', '\'KW\'', '\'USD\'', 26.33, 26.33, 26.33, 26.33, 26.33, 26.33, 26.33, 26.33, 26.33, 26.33, 26.33, 26.33, 26.33, 26.33, 26.33, 26.33, 26.33, 26.33, 26.33, 26.33, 26.33, 26.33, 26.33, 26.33, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(221, 414053, '\'Resolor 2 mg Film-Coated Tabs.\'', '\'KW\'', '\'USD\'', 43.29, 43.29, 43.29, 43.29, 43.29, 43.29, 43.29, 43.29, 43.29, 43.29, 43.29, 43.29, 40.88, 40.88, 40.88, 40.88, 40.88, 40.88, 40.88, 40.88, 40.88, 40.88, 40.88, 40.88, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(222, 0, '\'SPORANOX 1% 1X150ML ORSOL. ST.EXP. (2)  \'', '\'KW\'', '\'USD\'', 49.05, 49.05, 49.05, 49.05, 49.05, 49.05, 49.05, 49.05, 49.05, 49.05, 49.05, 49.05, 49.05, 49.05, 49.05, 49.05, 49.05, 49.05, 49.05, 49.05, 49.05, 49.05, 49.05, 49.05, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(223, 376854, '\'Risperdal 1mg Tab. 20s\'', '\'KW\'', '\'USD\'', 7.63, 7.63, 7.63, 7.63, 7.63, 7.63, 7.63, 7.63, 7.63, 7.63, 7.63, 7.63, 7.63, 7.63, 7.63, 7.63, 7.63, 7.63, 7.63, 7.63, 7.63, 7.63, 7.63, 7.63, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(224, 88081, '\'Risperdal 1mg Tab. 60s\'', '\'KW\'', '\'USD\'', 22.9, 22.9, 22.9, 22.9, 22.9, 22.9, 22.9, 22.9, 22.9, 22.9, 22.9, 22.9, 22.9, 22.9, 22.9, 22.9, 22.9, 22.9, 22.9, 22.9, 22.9, 22.9, 22.9, 22.9, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(225, 376853, '\'Risperdal 1mg Tab. 6s\'', '\'KW\'', '\'USD\'', 4.58, 4.58, 4.58, 4.58, 4.58, 4.58, 4.58, 4.58, 4.58, 4.58, 4.58, 4.58, 2.29, 2.29, 2.29, 2.29, 2.29, 2.29, 2.29, 2.29, 2.29, 2.29, 2.29, 2.29, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(226, 376855, '\'Risperdal 2mg Tab. 20s\'', '\'KW\'', '\'USD\'', 21.27, 21.27, 21.27, 21.27, 21.27, 21.27, 21.27, 21.27, 21.27, 21.27, 21.27, 21.27, 10.64, 10.64, 10.64, 10.64, 10.64, 10.64, 10.64, 10.64, 10.64, 10.64, 10.64, 10.64, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(227, 88082, '\'Risperdal 2mg Tab. 60s\'', '\'KW\'', '\'USD\'', 7.68, 7.68, 7.68, 7.68, 7.68, 7.68, 7.68, 7.68, 7.68, 7.68, 7.68, 7.68, 7.68, 7.68, 7.68, 7.68, 7.68, 7.68, 7.68, 7.68, 7.68, 7.68, 7.68, 7.68, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(228, 376856, '\'Risperdal 3mg Tab. 20s\'', '\'KW\'', '\'USD\'', 27.36, 27.36, 27.36, 27.36, 27.36, 27.36, 27.36, 27.36, 27.36, 27.36, 27.36, 27.36, 13.68, 13.68, 13.68, 13.68, 13.68, 13.68, 13.68, 13.68, 13.68, 13.68, 13.68, 13.68, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(229, 376595, '\'Risperdal Consta 25 mg Inj.  \'', '\'KW\'', '\'USD\'', 122.93, 122.93, 122.93, 122.93, 122.93, 122.93, 122.93, 122.93, 122.93, 122.93, 122.93, 122.93, 73.96, 73.96, 73.96, 73.96, 73.96, 73.96, 73.96, 73.96, 73.96, 73.96, 73.96, 73.96, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(230, 376596, '\'Risperdal Consta 37.5 mg Inj. \'', '\'KW\'', '\'USD\'', 162.16, 162.16, 162.16, 162.16, 162.16, 162.16, 162.16, 162.16, 162.16, 162.16, 162.16, 162.16, 102.95, 102.95, 102.95, 102.95, 102.95, 102.95, 102.95, 102.95, 102.95, 102.95, 102.95, 102.95, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(231, 376597, '\'Risperdal Consta 50 mg Inj.  \'', '\'KW\'', '\'USD\'', 199.59, 199.59, 199.59, 199.59, 199.59, 199.59, 199.59, 199.59, 199.59, 199.59, 199.59, 199.59, 122.95, 122.95, 122.95, 122.95, 122.95, 122.95, 122.95, 122.95, 122.95, 122.95, 122.95, 122.95, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(232, 96568, '\'Risperdal 3mg Tab. 60s\'', '\'KW\'', '\'USD\'', 11.23, 11.23, 11.23, 11.23, 11.23, 11.23, 11.23, 11.23, 11.23, 11.23, 11.23, 11.23, 11.23, 11.23, 11.23, 11.23, 11.23, 11.23, 11.23, 11.23, 11.23, 11.23, 11.23, 11.23, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(233, 376935, '\'Sporanox 100 mg Cap. 15s\'', '\'KW\'', '\'USD\'', 21.26, 21.26, 21.26, 21.26, 21.26, 21.26, 21.26, 21.26, 21.26, 21.26, 21.26, 21.26, 21.26, 21.26, 21.26, 21.26, 21.26, 21.26, 21.26, 21.26, 21.26, 21.26, 21.26, 21.26, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(234, 96327, '\'Risperdal 4mg Tab. 20s\'', '\'KW\'', '\'USD\'', 4.15, 4.15, 4.15, 4.15, 4.15, 4.15, 4.15, 4.15, 4.15, 4.15, 4.15, 4.15, 4.15, 4.15, 4.15, 4.15, 4.15, 4.15, 4.15, 4.15, 4.15, 4.15, 4.15, 4.15, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(235, 96569, '\'Risperdal 4mg Tab. 60s\'', '\'KW\'', '\'USD\'', 12.45, 12.45, 12.45, 12.45, 12.45, 12.45, 12.45, 12.45, 12.45, 12.45, 12.45, 12.45, 12.45, 12.45, 12.45, 12.45, 12.45, 12.45, 12.45, 12.45, 12.45, 12.45, 12.45, 12.45, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(236, 96489, '\'Sporanox 100 mg Cap. 4s\'', '\'KW\'', '\'USD\'', 6.51, 6.51, 6.51, 6.51, 6.51, 6.51, 6.51, 6.51, 6.51, 6.51, 6.51, 6.51, 6.51, 6.51, 6.51, 6.51, 6.51, 6.51, 6.51, 6.51, 6.51, 6.51, 6.51, 6.51, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(237, 0, '\'Spravato 2x28mg\'', '\'KW\'', '\'USD\'', 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(238, 0, '\'Spravato 3x28mg\'', '\'KW\'', '\'USD\'', 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(239, 0, '\'Simponi 100mg PFP\'', '\'KW\'', '\'USD\'', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(240, 0, '\'Symtuza\'', '\'KW\'', '\'USD\'', 869, 869, 869, 869, 869, 869, 869, 869, 869, 869, 869, 869, 869, 869, 869, 869, 869, 869, 869, 869, 869, 869, 869, 869, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(241, 96046, '\'Stugeron 25 mg Tab.\'', '\'KW\'', '\'USD\'', 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(242, 141021, '\'Topamax 100 mg Tab.\'', '\'KW\'', '\'USD\'', 42.49, 42.49, 42.49, 42.49, 42.49, 42.49, 42.49, 42.49, 42.49, 42.49, 42.49, 42.49, 42.49, 42.49, 42.49, 42.49, 42.49, 42.49, 42.49, 42.49, 42.49, 42.49, 42.49, 42.49, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(243, 412301, '\'Topamax 15 mg Sprinkle Cap.\'', '\'KW\'', '\'USD\'', 11.78, 11.78, 11.78, 11.78, 11.78, 11.78, 11.78, 11.78, 11.78, 11.78, 11.78, 11.78, 11.78, 11.78, 11.78, 11.78, 11.78, 11.78, 11.78, 11.78, 11.78, 11.78, 11.78, 11.78, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(244, 141023, '\'Topamax 200 mg Tab.\'', '\'KW\'', '\'USD\'', 69.68, 69.68, 69.68, 69.68, 69.68, 69.68, 69.68, 69.68, 69.68, 69.68, 69.68, 69.68, 69.68, 69.68, 69.68, 69.68, 69.68, 69.68, 69.68, 69.68, 69.68, 69.68, 69.68, 69.68, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(245, 412303, '\'Topamax 25 mg Sprinkle Cap.\'', '\'KW\'', '\'USD\'', 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(246, 141016, '\'Topamax 25 mg Tab.\'', '\'KW\'', '\'USD\'', 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(247, 412305, '\'Topamax 50 mg Sprinkle Cap.\'', '\'KW\'', '\'USD\'', 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(248, 141019, '\'Topamax 50 mg Tab.\'', '\'KW\'', '\'USD\'', 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(249, 0, '\'Tracleer 125mg\'', '\'KW\'', '\'USD\'', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(250, 0, '\'Tracleer 62.5mg\'', '\'KW\'', '\'USD\'', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(251, 418626, '\'Trevicta 175mg (50mg eq.)\'', '\'KW\'', '\'USD\'', 563.33, 563.33, 563.33, 563.33, 563.33, 563.33, 563.33, 563.33, 563.33, 563.33, 563.33, 563.33, 563.33, 563.33, 563.33, 563.33, 563.33, 563.33, 563.33, 563.33, 563.33, 563.33, 563.33, 563.33, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(252, 418624, '\'Trevicta 263mg (75mg eq.) \'', '\'KW\'', '\'USD\'', 746.93, 746.93, 746.93, 746.93, 746.93, 746.93, 746.93, 746.93, 746.93, 746.93, 746.93, 746.93, 746.93, 746.93, 746.93, 746.93, 746.93, 746.93, 746.93, 746.93, 746.93, 746.93, 746.93, 746.93, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(253, 418623, '\'Trevicta 360mg (100mg eq.) \'', '\'KW\'', '\'USD\'', 952.11, 952.11, 952.11, 952.11, 952.11, 952.11, 952.11, 952.11, 952.11, 952.11, 952.11, 952.11, 952.11, 952.11, 952.11, 952.11, 952.11, 952.11, 952.11, 952.11, 952.11, 952.11, 952.11, 952.11, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(254, 418621, '\'Trevicta 525mg (150mg eq.) \'', '\'KW\'', '\'USD\'', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(255, 0, '\'Uptravi\'', '\'KW\'', '\'USD\'', 4, 2, 2, 2, 4, 2, 2, 2, 4, 2, 2, 2, 4, 2, 2, 2, 4, 2, 2, 2, 4, 2, 2, 2, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(256, 414963, '\'Velcade Injection 3.5 mg\'', '\'KW\'', '\'USD\'', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 991, 991, 991, 991, 991, 991, 991, 991, 991, 991, 991, 991, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(257, 96063, '\'Vermox 100 mg Tab. 6s\'', '\'KW\'', '\'USD\'', 1.56, 1.56, 1.56, 1.56, 1.56, 1.56, 1.56, 1.56, 1.56, 1.56, 1.56, 1.56, 1.56, 1.56, 1.56, 1.56, 1.56, 1.56, 1.56, 1.56, 1.56, 1.56, 1.56, 1.56, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(258, 96065, '\'Vermox 100 mg Tab. 240\'s\'', '\'KW\'', '\'USD\'', 16.5, 16.5, 16.5, 16.5, 16.5, 16.5, 16.5, 16.5, 16.5, 16.5, 16.5, 16.5, 16.5, 16.5, 16.5, 16.5, 16.5, 16.5, 16.5, 16.5, 16.5, 16.5, 16.5, 16.5, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(259, 96048, '\'Vermox 500 mg Tab.\'', '\'KW\'', '\'USD\'', 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(260, 418302, '\'Vokanamet 150/1000mg Tablets\'', '\'KW\'', '\'USD\'', 36.2, 36.2, 36.2, 36.2, 36.2, 36.2, 36.2, 36.2, 36.2, 36.2, 36.2, 36.2, 36.2, 36.2, 36.2, 36.2, 36.2, 36.2, 36.2, 36.2, 36.2, 36.2, 36.2, 36.2, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(261, 418301, '\'Vokanamet 150/850mg Tablets\'', '\'KW\'', '\'USD\'', 34.98, 34.98, 34.98, 34.98, 34.98, 34.98, 34.98, 34.98, 34.98, 34.98, 34.98, 34.98, 34.98, 34.98, 34.98, 34.98, 34.98, 34.98, 34.98, 34.98, 34.98, 34.98, 34.98, 34.98, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(262, 418299, '\'Vokanamet 50/1000mg Tablets\'', '\'KW\'', '\'USD\'', 36.2, 36.2, 36.2, 36.2, 36.2, 36.2, 36.2, 36.2, 36.2, 36.2, 36.2, 36.2, 36.2, 36.2, 36.2, 36.2, 36.2, 36.2, 36.2, 36.2, 36.2, 36.2, 36.2, 36.2, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(263, 418298, '\'Vokanamet 50/850mg Tablets\'', '\'KW\'', '\'USD\'', 34.98, 34.98, 34.98, 34.98, 34.98, 34.98, 34.98, 34.98, 34.98, 34.98, 34.98, 34.98, 34.98, 34.98, 34.98, 34.98, 34.98, 34.98, 34.98, 34.98, 34.98, 34.98, 34.98, 34.98, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(264, 32461, '\'Vermox 20 mg/ml Oral Susp.\'', '\'KW\'', '\'USD\'', 1.66, 1.66, 1.66, 1.66, 1.66, 1.66, 1.66, 1.66, 1.66, 1.66, 1.66, 1.66, 1.66, 1.66, 1.66, 1.66, 1.66, 1.66, 1.66, 1.66, 1.66, 1.66, 1.66, 1.66, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(265, 385589, '\'Yondelis 1 mg Injection \'', '\'KW\'', '\'USD\'', 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(266, 0, '\'Zavesca 84 cap 100mg \'', '\'KW\'', '\'USD\'', 6, 2, 2, 2, 6, 2, 2, 2, 6, 2, 2, 2, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(267, 414448, '\'Zytiga 250 mg Tabs\'', '\'KW\'', '\'USD\'', 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(268, 0, '\'Zytiga 500 mg Tabs\'', '\'KW\'', '\'USD\'', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(269, 414287, '\'Stelara 45mg/0.5ml \'', '\'OM\'', '\'USD\'', 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(270, 414288, '\'Stelara 90mg/1ml \'', '\'OM\'', '\'USD\'', 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(271, 414050, '\'Resolor 1 mg Film-Coated Tabs.\'', '\'OM\'', '\'USD\'', 30.95, 30.95, 26.33, 26.33, 30.95, 30.95, 26.33, 26.33, 30.95, 30.95, 26.33, 26.33, 30.95, 30.95, 26.33, 26.33, 30.95, 30.95, 26.33, 26.33, 30.95, 30.95, 26.33, 26.33, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(272, 412041, '\'Resolor 2 mg Film-Coated Tabs.\'', '\'OM\'', '\'USD\'', 50.76, 50.76, 43.29, 43.29, 50.76, 50.76, 43.29, 43.29, 50.76, 50.76, 43.29, 43.29, 50.76, 50.76, 43.29, 43.29, 50.76, 50.76, 43.29, 43.29, 50.76, 50.76, 43.29, 43.29, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(273, 376595, '\'Risperdal Consta 25 mg Inj.  \'', '\'OM\'', '\'USD\'', 116.79, 116.79, 116.79, 116.79, 116.79, 116.79, 116.79, 116.79, 116.79, 116.79, 116.79, 116.79, 73.96, 73.96, 73.96, 73.96, 73.96, 73.96, 73.96, 73.96, 73.96, 73.96, 73.96, 73.96, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(274, 376597, '\'Risperdal Consta 50 mg Inj.  \'', '\'OM\'', '\'USD\'', 189.61, 189.61, 189.61, 189.61, 189.61, 189.61, 189.61, 189.61, 189.61, 189.61, 189.61, 189.61, 122.95, 122.95, 122.95, 122.95, 122.95, 122.95, 122.95, 122.95, 122.95, 122.95, 122.95, 122.95, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(275, 96063, '\'Vermox 100 mg Tab. 6s\'', '\'OM\'', '\'USD\'', 1.56, 1.56, 1.56, 1.56, 1.56, 1.56, 1.56, 1.56, 1.56, 1.56, 1.56, 1.56, 1.56, 1.56, 1.56, 1.56, 1.56, 1.56, 1.56, 1.56, 1.56, 1.56, 1.56, 1.56, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(276, 141021, '\'Topamax 100 mg Tab.\'', '\'OM\'', '\'USD\'', 42.49, 42.49, 42.49, 42.49, 42.49, 42.49, 42.49, 42.49, 42.49, 42.49, 42.49, 42.49, 39.09, 39.09, 39.09, 39.09, 39.09, 39.09, 39.09, 39.09, 39.09, 39.09, 39.09, 39.09, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(277, 141016, '\'Topamax 25 mg Tab.\'', '\'OM\'', '\'USD\'', 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 14.06, 14.06, 14.06, 14.06, 14.06, 14.06, 14.06, 14.06, 14.06, 14.06, 14.06, 14.06, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(278, 141019, '\'Topamax 50 mg Tab.\'', '\'OM\'', '\'USD\'', 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(279, 385589, '\'Yondelis 1 mg Injection \'', '\'OM\'', '\'USD\'', 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(280, 60345, '\'Motilium 1 mg/ml Oral Suspension 100ml\'', '\'OM\'', '\'USD\'', 1.6, 1.6, 1.6, 1.6, 1.6, 1.6, 1.6, 1.6, 1.6, 1.6, 1.6, 1.6, 1.6, 1.6, 1.6, 1.6, 1.6, 1.6, 1.6, 1.6, 1.6, 1.6, 1.6, 1.6, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(281, 32451, '\'Motilium 1 mg/ml Oral Suspension 200ml\'', '\'OM\'', '\'USD\'', 3.2, 3.2, 3.2, 3.2, 3.2, 3.2, 3.2, 3.2, 3.2, 3.2, 3.2, 3.2, 2.9, 2.9, 2.9, 2.9, 2.9, 2.9, 2.9, 2.9, 2.9, 2.9, 2.9, 2.9, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(282, 418513, '\'Motilium 10 mg Tab. 100s\'', '\'OM\'', '\'USD\'', 9.1, 9.1, 9.1, 9.1, 9.1, 9.1, 9.1, 9.1, 9.1, 9.1, 9.1, 9.1, 7.03, 7.03, 7.03, 7.03, 7.03, 7.03, 7.03, 7.03, 7.03, 7.03, 7.03, 7.03, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(283, 96056, '\'Motilium 10 mg Tab. 30s\'', '\'OM\'', '\'USD\'', 3.3, 3.3, 3.3, 3.3, 3.3, 3.3, 3.3, 3.3, 3.3, 3.3, 3.3, 3.3, 3.3, 3.3, 3.3, 3.3, 3.3, 3.3, 3.3, 3.3, 3.3, 3.3, 3.3, 3.3, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(284, 414696, '\'Nizoral Cream 2 %\'', '\'OM\'', '\'USD\'', 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(285, 376854, '\'Risperdal 1mg Tab. 20s\'', '\'OM\'', '\'USD\'', 15.27, 15.27, 15.27, 15.27, 15.27, 15.27, 15.27, 15.27, 15.27, 15.27, 15.27, 15.27, 7.63, 7.63, 7.63, 7.63, 7.63, 7.63, 7.63, 7.63, 7.63, 7.63, 7.63, 7.63, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(286, 376855, '\'Risperdal 2mg Tab. 20s\'', '\'OM\'', '\'USD\'', 21.27, 21.27, 21.27, 21.27, 21.27, 21.27, 21.27, 21.27, 21.27, 21.27, 21.27, 21.27, 10.64, 10.64, 10.64, 10.64, 10.64, 10.64, 10.64, 10.64, 10.64, 10.64, 10.64, 10.64, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(287, 96552, '\'Risperdal 2mg Tab. 60s\'', '\'OM\'', '\'USD\'', 30.6, 30.6, 30.6, 30.6, 30.6, 30.6, 30.6, 30.6, 30.6, 30.6, 30.6, 30.6, 29.27, 29.27, 29.27, 29.27, 29.27, 29.27, 29.27, 29.27, 29.27, 29.27, 29.27, 29.27, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(288, 376856, '\'Risperdal 3mg Tab. 20s\'', '\'OM\'', '\'USD\'', 27.36, 27.36, 27.36, 27.36, 27.36, 27.36, 27.36, 27.36, 27.36, 27.36, 27.36, 27.36, 13.68, 13.68, 13.68, 13.68, 13.68, 13.68, 13.68, 13.68, 13.68, 13.68, 13.68, 13.68, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(289, 96327, '\'Risperdal 4mg Tab. 20s\'', '\'OM\'', '\'USD\'', 34.89, 34.89, 34.89, 34.89, 34.89, 34.89, 34.89, 34.89, 34.89, 34.89, 34.89, 34.89, 17.45, 17.45, 17.45, 17.45, 17.45, 17.45, 17.45, 17.45, 17.45, 17.45, 17.45, 17.45, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(290, 96569, '\'Risperdal 4mg Tab. 60s\'', '\'OM\'', '\'USD\'', 45.8, 45.8, 45.8, 45.8, 45.8, 45.8, 45.8, 45.8, 45.8, 45.8, 45.8, 45.8, 45.8, 45.8, 45.8, 45.8, 45.8, 45.8, 45.8, 45.8, 45.8, 45.8, 45.8, 45.8, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(291, 376596, '\'Risperdal Consta 37.5 mg Inj. \'', '\'OM\'', '\'USD\'', 154.05, 154.05, 154.05, 154.05, 154.05, 154.05, 154.05, 154.05, 154.05, 154.05, 154.05, 154.05, 102.95, 102.95, 102.95, 102.95, 102.95, 102.95, 102.95, 102.95, 102.95, 102.95, 102.95, 102.95, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(292, 376935, '\'Sporanox 100 mg Cap. 15s\'', '\'OM\'', '\'USD\'', 21.24, 21.24, 21.24, 21.24, 21.24, 21.24, 21.24, 21.24, 21.24, 21.24, 21.24, 21.24, 20.45, 20.45, 20.45, 20.45, 20.45, 20.45, 20.45, 20.45, 20.45, 20.45, 20.45, 20.45, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(293, 96489, '\'Sporanox 100 mg Cap. 4s\'', '\'OM\'', '\'USD\'', 6.51, 6.51, 6.51, 6.51, 6.51, 6.51, 6.51, 6.51, 6.51, 6.51, 6.51, 6.51, 6.51, 6.51, 6.51, 6.51, 6.51, 6.51, 6.51, 6.51, 6.51, 6.51, 6.51, 6.51, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(294, 96046, '\'Stugeron 25 mg Tab.\'', '\'OM\'', '\'USD\'', 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(295, 32461, '\'Vermox 20 mg/ml Oral Susp.\'', '\'OM\'', '\'USD\'', 1.73, 1.73, 1.73, 1.73, 1.73, 1.73, 1.73, 1.73, 1.73, 1.73, 1.73, 1.73, 1.2, 1.2, 1.2, 1.2, 1.2, 1.2, 1.2, 1.2, 1.2, 1.2, 1.2, 1.2, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(296, 415168, '\'Darzalex 100mg\'', '\'OM\'', '\'USD\'', 449.75, 449.75, 449.75, 449.75, 449.75, 449.75, 449.75, 449.75, 449.75, 449.75, 449.75, 449.75, 449.75, 449.75, 449.75, 449.75, 449.75, 449.75, 449.75, 449.75, 449.75, 449.75, 449.75, 449.75, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(297, 415169, '\'Darzalex 400mg\'', '\'OM\'', '\'USD\'', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(298, 418626, '\'Trevicta 175mg (50mg eq.)\'', '\'OM\'', '\'USD\'', 662.75, 662.75, 662.75, 662.75, 662.75, 662.75, 662.75, 662.75, 662.75, 662.75, 662.75, 662.75, 563.33, 563.33, 563.33, 563.33, 563.33, 563.33, 563.33, 563.33, 563.33, 563.33, 563.33, 563.33, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(299, 418624, '\'Trevicta 263mg (75mg eq.) \'', '\'OM\'', '\'USD\'', 878.75, 878.75, 878.75, 878.75, 878.75, 878.75, 878.75, 878.75, 878.75, 878.75, 878.75, 878.75, 746.93, 746.93, 746.93, 746.93, 746.93, 746.93, 746.93, 746.93, 746.93, 746.93, 746.93, 746.93, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(300, 418623, '\'Trevicta 360mg (100mg eq.) \'', '\'OM\'', '\'USD\'', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 952.11, 952.11, 952.11, 952.11, 952.11, 952.11, 952.11, 952.11, 952.11, 952.11, 952.11, 952.11, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(301, 418621, '\'Trevicta 525mg (150mg eq.) \'', '\'OM\'', '\'USD\'', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(302, 416009, '\'Pariet 20 mg Tab. 14s\'', '\'OM\'', '\'USD\'', 13.01, 13.01, 13.01, 13.01, 13.01, 13.01, 13.01, 13.01, 13.01, 13.01, 13.01, 13.01, 11.2, 11.2, 11.2, 11.2, 11.2, 11.2, 11.2, 11.2, 11.2, 11.2, 11.2, 11.2, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(303, 416010, '\'Pariet 20 mg Tab. 28s\'', '\'OM\'', '\'USD\'', 26.01, 26.01, 26.01, 26.01, 26.01, 26.01, 26.01, 26.01, 26.01, 26.01, 26.01, 26.01, 26.01, 26.01, 26.01, 26.01, 26.01, 26.01, 26.01, 26.01, 26.01, 26.01, 26.01, 26.01, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(304, 0, '\'Stelara 130mg\'', '\'OM\'', '\'USD\'', 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(305, 412301, '\'Topamax 15 mg Sprinkle Cap.\'', '\'OM\'', '\'USD\'', 11.78, 11.78, 11.78, 11.78, 11.78, 11.78, 11.78, 11.78, 11.78, 11.78, 11.78, 11.78, 11.78, 11.78, 11.78, 11.78, 11.78, 11.78, 11.78, 11.78, 11.78, 11.78, 11.78, 11.78, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(306, 414448, '\'Zytiga 250 mg Tabs\'', '\'OM\'', '\'USD\'', 3, 3, 3, 1, 3, 3, 3, 1, 3, 3, 3, 1, 3, 3, 3, 1, 3, 3, 3, 1, 3, 3, 3, 1, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(307, 387104, '\'Prezista 400 mg Tablets\'', '\'OM\'', '\'USD\'', 402.77, 402.77, 402.77, 402.77, 402.77, 402.77, 402.77, 402.77, 402.77, 402.77, 402.77, 402.77, 402.77, 402.77, 402.77, 402.77, 402.77, 402.77, 402.77, 402.77, 402.77, 402.77, 402.77, 402.77, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(308, 387107, '\'Prezista 600 mg Tablets\'', '\'OM\'', '\'USD\'', 615.22, 615.22, 615.22, 615.22, 615.22, 615.22, 615.22, 615.22, 615.22, 615.22, 615.22, 615.22, 565.8, 565.8, 565.8, 565.8, 565.8, 565.8, 565.8, 565.8, 565.8, 565.8, 565.8, 565.8, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(309, 412675, '\'Simponi 50 mg/ 0.5 ml Injection (PFP)\'', '\'OM\'', '\'USD\'', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 900, 900, 900, 900, 900, 900, 900, 900, 900, 900, 900, 900, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(310, 414434, '\'Caelyx 2 mg/ml\'', '\'OM\'', '\'USD\'', 512, 512, 512, 512, 512, 512, 512, 512, 512, 512, 512, 512, 471.04, 471.04, 471.04, 471.04, 471.04, 471.04, 471.04, 471.04, 471.04, 471.04, 471.04, 471.04, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(311, 32442, '\'Daktacort Cream                 \'', '\'OM\'', '\'USD\'', 2.31, 2.31, 2.31, 2.31, 2.31, 2.31, 2.31, 2.31, 2.31, 2.31, 2.31, 2.31, 2.31, 2.31, 2.31, 2.31, 2.31, 2.31, 2.31, 2.31, 2.31, 2.31, 2.31, 2.31, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(312, 88836, '\'Daktarin Cream 2% 15g\'', '\'OM\'', '\'USD\'', 1.68, 1.68, 1.68, 1.68, 1.68, 1.68, 1.68, 1.68, 1.68, 1.68, 1.68, 1.68, 1.2, 1.2, 1.2, 1.2, 1.2, 1.2, 1.2, 1.2, 1.2, 1.2, 1.2, 1.2, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(313, 88877, '\'Daktarin Cream 2% 30g\'', '\'OM\'', '\'USD\'', 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(314, 32441, '\'Daktarin Oral Gel 2%\'', '\'OM\'', '\'USD\'', 3.19, 3.19, 3.19, 3.19, 3.19, 3.19, 3.19, 3.19, 3.19, 3.19, 3.19, 3.19, 3.19, 3.19, 3.19, 3.19, 3.19, 3.19, 3.19, 3.19, 3.19, 3.19, 3.19, 3.19, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(315, 377017, '\'Daktarin Powder 2%\'', '\'OM\'', '\'USD\'', 2.19, 2.19, 2.19, 2.19, 2.19, 2.19, 2.19, 2.19, 2.19, 2.19, 2.19, 2.19, 2.19, 2.19, 2.19, 2.19, 2.19, 2.19, 2.19, 2.19, 2.19, 2.19, 2.19, 2.19, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(316, 387397, '\'Durogesic Transdermal Patches 100 mcg/h\'', '\'OM\'', '\'USD\'', 98.73, 98.73, 98.73, 98.73, 98.73, 98.73, 98.73, 98.73, 98.73, 98.73, 98.73, 98.73, 98.73, 98.73, 98.73, 98.73, 98.73, 98.73, 98.73, 98.73, 98.73, 98.73, 98.73, 98.73, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(317, 387398, '\'Durogesic Transdermal Patches 12 mcg/h\'', '\'OM\'', '\'USD\'', 17.62, 17.62, 17.62, 17.62, 17.62, 17.62, 17.62, 17.62, 17.62, 17.62, 17.62, 17.62, 17.62, 17.62, 17.62, 17.62, 17.62, 17.62, 17.62, 17.62, 17.62, 17.62, 17.62, 17.62, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(318, 387399, '\'Durogesic Transdermal Patches 25 mcg/h\'', '\'OM\'', '\'USD\'', 31.12, 31.12, 31.12, 31.12, 31.12, 31.12, 31.12, 31.12, 31.12, 31.12, 31.12, 31.12, 31.12, 31.12, 7.11, 7.11, 31.12, 31.12, 7.11, 7.11, 31.12, 31.12, 7.11, 7.11, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(319, 387400, '\'Durogesic Transdermal Patches 50 mcg/h\'', '\'OM\'', '\'USD\'', 52.29, 52.29, 52.29, 52.29, 52.29, 52.29, 52.29, 52.29, 52.29, 52.29, 52.29, 52.29, 52.29, 52.29, 13.07, 13.07, 52.29, 52.29, 13.07, 13.07, 52.29, 52.29, 13.07, 13.07, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(320, 387401, '\'Durogesic Transdermal Patches 75 mcg/h\'', '\'OM\'', '\'USD\'', 80.1, 80.1, 80.1, 80.1, 80.1, 80.1, 80.1, 80.1, 80.1, 80.1, 80.1, 80.1, 80.1, 80.1, 80.1, 80.1, 80.1, 80.1, 80.1, 80.1, 80.1, 80.1, 80.1, 80.1, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(321, 0, '\'Eprex 5,000 U Pre-Filled Syringes \'', '\'OM\'', '\'USD\'', 203.37, 203.37, 203.37, 203.37, 203.37, 203.37, 203.37, 203.37, 203.37, 203.37, 203.37, 203.37, 78.67, 78.67, 78.67, 78.67, 78.67, 78.67, 78.67, 78.67, 78.67, 78.67, 78.67, 78.67, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(322, 0, '\'Eprex 8,000 U Pre-Filled Syringes \'', '\'OM\'', '\'USD\'', 245.71, 245.71, 245.71, 245.71, 245.71, 245.71, 245.71, 245.71, 245.71, 245.71, 245.71, 245.71, 245.71, 245.71, 245.71, 245.71, 245.71, 245.71, 245.71, 245.71, 245.71, 245.71, 245.71, 245.71, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(323, 140788, '\'Evra Transdermal Patches \'', '\'OM\'', '\'USD\'', 8.17, 8.17, 8.17, 8.17, 8.17, 8.17, 8.17, 8.17, 8.17, 8.17, 8.17, 8.17, 8.17, 8.17, 8.17, 8.17, 8.17, 8.17, 8.17, 8.17, 8.17, 8.17, 8.17, 8.17, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(324, 0, '\'Fentanyl 0.05 mg/ml Inj. 2ml x 10 amps\'', '\'OM\'', '\'USD\'', 3.96, 3.96, 3.96, 3.96, 3.96, 3.96, 3.96, 3.96, 3.96, 3.96, 3.96, 3.96, 3.96, 3.96, 3.96, 3.96, 3.96, 3.96, 3.96, 3.96, 3.96, 3.96, 3.96, 3.96, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(325, 377424, '\'Gyno Daktarin 1200 mg V. Capsule\'', '\'OM\'', '\'USD\'', 3.1, 3.1, 3.1, 3.1, 3.1, 3.1, 3.1, 3.1, 3.1, 3.1, 3.1, 3.1, 3.1, 3.1, 3.1, 3.1, 3.1, 3.1, 3.1, 3.1, 3.1, 3.1, 3.1, 3.1, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(326, 414691, '\'Gyno Daktarin 200 mg V. Capsules\'', '\'OM\'', '\'USD\'', 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(327, 140311, '\'Gyno-Pevaryl V. Cream \'', '\'OM\'', '\'USD\'', 7.77, 7.77, 7.77, 7.77, 7.77, 7.77, 7.77, 7.77, 7.77, 7.77, 7.77, 7.77, 7.77, 7.77, 7.77, 7.77, 7.77, 7.77, 7.77, 7.77, 7.77, 7.77, 7.77, 7.77, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(328, 0, '\'Cilest Tab. 21tab\'', '\'OM\'', '\'USD\'', 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(329, 0, '\'Cilest Tab. 36tab\'', '\'OM\'', '\'USD\'', 11.55, 11.55, 11.55, 11.55, 11.55, 11.55, 11.55, 11.55, 11.55, 11.55, 11.55, 11.55, 11.55, 11.55, 11.55, 11.55, 11.55, 11.55, 11.55, 11.55, 11.55, 11.55, 11.55, 11.55, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(330, 413611, '\'Imbruvica 140mg Capsule \'', '\'OM\'', '\'USD\'', 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(331, 377907, '\'Dacogen 5 mg Injection \'', '\'OM\'', '\'USD\'', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(332, 33020, '\'Daktarin 2% Tincture\'', '\'OM\'', '\'USD\'', 3.7, 3.7, 3.7, 3.7, 3.7, 3.7, 3.7, 3.7, 3.7, 3.7, 3.7, 3.7, 3.7, 3.7, 3.7, 3.7, 3.7, 3.7, 3.7, 3.7, 3.7, 3.7, 3.7, 3.7, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(333, 0, '\'Daktarin Lotion 2% \'', '\'OM\'', '\'USD\'', 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(334, 0, '\'Doribax 500 mg Injection \'', '\'OM\'', '\'USD\'', 179.21, 179.21, 179.21, 179.21, 179.21, 179.21, 179.21, 179.21, 179.21, 179.21, 179.21, 179.21, 179.21, 179.21, 179.21, 179.21, 179.21, 179.21, 179.21, 179.21, 179.21, 179.21, 179.21, 179.21, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(335, 378218, '\'Intelence 100 mg Tab. \'', '\'OM\'', '\'USD\'', 520.82, 520.82, 520.82, 520.82, 520.82, 520.82, 520.82, 520.82, 520.82, 520.82, 520.82, 520.82, 520.82, 520.82, 520.82, 520.82, 520.82, 520.82, 520.82, 520.82, 520.82, 520.82, 520.82, 520.82, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(336, 416819, '\'Invega 3 mg Extended Release Tab. \'', '\'OM\'', '\'USD\'', 88.12, 88.12, 88.12, 88.12, 88.12, 88.12, 88.12, 88.12, 88.12, 88.12, 88.12, 88.12, 88.12, 88.12, 41.39, 41.39, 88.12, 88.12, 41.39, 41.39, 88.12, 88.12, 41.39, 41.39, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(337, 416821, '\'Invega 6 mg Extended Release Tab. \'', '\'OM\'', '\'USD\'', 88.12, 88.12, 88.12, 88.12, 88.12, 88.12, 88.12, 88.12, 88.12, 88.12, 88.12, 88.12, 88.12, 88.12, 48.8, 48.8, 88.12, 88.12, 48.8, 48.8, 88.12, 88.12, 48.8, 48.8, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(338, 416823, '\'Invega 9 mg Extended Release Tab. \'', '\'OM\'', '\'USD\'', 95.51, 95.51, 95.51, 95.51, 95.51, 95.51, 95.51, 95.51, 95.51, 95.51, 95.51, 95.51, 90.1, 90.1, 90.1, 90.1, 90.1, 90.1, 90.1, 90.1, 90.1, 90.1, 90.1, 90.1, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(339, 387760, '\'Invega Sustenna 100 mg/ 1 ml \'', '\'OM\'', '\'USD\'', 298.88, 298.88, 298.88, 298.88, 298.88, 298.88, 298.88, 298.88, 298.88, 298.88, 298.88, 298.88, 298.89, 298.89, 298.89, 298.89, 298.89, 298.89, 298.89, 298.89, 298.89, 298.89, 298.89, 298.89, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(340, 387761, '\'Invega Sustenna 150 mg/ 1.5 ml \'', '\'OM\'', '\'USD\'', 347.74, 347.74, 347.74, 347.74, 347.74, 347.74, 347.74, 347.74, 347.74, 347.74, 347.74, 347.74, 347.78, 347.78, 347.78, 347.78, 347.78, 347.78, 347.78, 347.78, 347.78, 347.78, 347.78, 347.78, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(341, 387758, '\'Invega Sustenna 50 mg/ 0.5 ml \'', '\'OM\'', '\'USD\'', 186.86, 186.86, 186.86, 186.86, 186.86, 186.86, 186.86, 186.86, 186.86, 186.86, 186.86, 186.86, 186.86, 186.86, 186.86, 186.86, 186.86, 186.86, 186.86, 186.86, 186.86, 186.86, 186.86, 186.86, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(342, 387759, '\'Invega Sustenna 75 mg/ 0.75 ml \'', '\'OM\'', '\'USD\'', 243.86, 243.86, 243.86, 243.86, 243.86, 243.86, 243.86, 243.86, 243.86, 243.86, 243.86, 243.86, 243.86, 243.86, 243.86, 243.86, 243.86, 243.86, 243.86, 243.86, 243.86, 243.86, 243.86, 243.86, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(343, 414907, '\'Invokana 100mg \'', '\'OM\'', '\'USD\'', 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(344, 414908, '\'Invokana 300mg\'', '\'OM\'', '\'USD\'', 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(345, 414064, '\'Eprex 1,000 U Pre-Filled Syringes \'', '\'OM\'', '\'USD\'', 33.36, 33.36, 33.36, 33.36, 33.36, 33.36, 33.36, 33.36, 33.36, 33.36, 33.36, 33.36, 33.36, 33.36, 33.36, 33.36, 33.36, 33.36, 33.36, 33.36, 33.36, 33.36, 33.36, 33.36, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(346, 0, '\'Guselkumab\'', '\'OM\'', '\'USD\'', 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(347, 387445, '\'Gyno Pevaryl 150 mg V. Suppositories\'', '\'OM\'', '\'USD\'', 3.73, 3.73, 3.73, 3.73, 3.73, 3.73, 3.73, 3.73, 3.73, 3.73, 3.73, 3.73, 3.73, 3.73, 3.73, 3.73, 3.73, 3.73, 3.73, 3.73, 3.73, 3.73, 3.73, 3.73, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(348, 88878, '\'Gyno-Daktarin V. Cream \'', '\'OM\'', '\'USD\'', 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(349, 387447, '\'Gyno-Pevaryl Depot 150 mg V. Ovules\'', '\'OM\'', '\'USD\'', 4.89, 4.89, 4.89, 4.89, 4.89, 4.89, 4.89, 4.89, 4.89, 4.89, 4.89, 4.89, 4.89, 4.89, 4.89, 4.89, 4.89, 4.89, 4.89, 4.89, 4.89, 4.89, 4.89, 4.89, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(350, 96041, '\'Haldol 10mg 20 Tab\'', '\'OM\'', '\'USD\'', 2.66, 2.66, 2.66, 2.66, 2.66, 2.66, 2.66, 2.66, 2.66, 2.66, 2.66, 2.66, 2.66, 2.66, 2.66, 2.66, 2.66, 2.66, 2.66, 2.66, 2.66, 2.66, 2.66, 2.66, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00');
INSERT INTO `jnj_pricing_dataentry` (`id`, `material`, `SKU`, `countryCode`, `currency`, `cif_jan`, `cif_feb`, `cif_mar`, `cif_apr`, `cif_may`, `cif_jun`, `cif_jul`, `cif_aug`, `cif_sep`, `cif_oct`, `cif_nov`, `cif_dec`, `tnd_jan`, `tnd_feb`, `tnd_mar`, `tnd_apr`, `tnd_may`, `tnd_jun`, `tnd_jul`, `tnd_aug`, `tnd_sep`, `tnd_oct`, `tnd_nov`, `tnd_dec`, `discounts`, `focs`, `totalDiscount`, `month`, `year`, `createDate`, `ModifiedDate`) VALUES
(351, 96875, '\'HALDOL 5MG 1000 TABLETS\'', '\'OM\'', '\'USD\'', 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(352, 96874, '\'Haldol 5mg tab\'', '\'OM\'', '\'USD\'', 4.39, 4.39, 4.39, 4.39, 4.39, 4.39, 4.39, 4.39, 4.39, 4.39, 4.39, 4.39, 4.39, 4.39, 4.39, 4.39, 4.39, 4.39, 4.39, 4.39, 4.39, 4.39, 4.39, 4.39, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(353, 412129, '\'Haldol Amp. 5mg/ml\'', '\'OM\'', '\'USD\'', 4.47, 4.47, 4.47, 4.47, 4.47, 4.47, 4.47, 4.47, 4.47, 4.47, 4.47, 4.47, 4.47, 4.47, 4.47, 4.47, 4.47, 4.47, 4.47, 4.47, 4.47, 4.47, 4.47, 4.47, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(354, 412127, '\'Haldol Decanoas Inj. 50mg/ml\'', '\'OM\'', '\'USD\'', 4.22, 4.22, 4.22, 4.22, 4.22, 4.22, 4.22, 4.22, 4.22, 4.22, 4.22, 4.22, 4.22, 4.22, 4.22, 4.22, 4.22, 4.22, 4.22, 4.22, 4.22, 4.22, 4.22, 4.22, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(355, 33027, '\'Haldol Oral Drops 2mg/ml\'', '\'OM\'', '\'USD\'', 2.21, 2.21, 2.21, 2.21, 2.21, 2.21, 2.21, 2.21, 2.21, 2.21, 2.21, 2.21, 2.21, 2.21, 2.21, 2.21, 2.21, 2.21, 2.21, 2.21, 2.21, 2.21, 2.21, 2.21, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(356, 0, '\'Imbruvica Tab 140mg\'', '\'OM\'', '\'USD\'', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(357, 0, '\'Imbruvica Tab 280mg\'', '\'OM\'', '\'USD\'', 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(358, 0, '\'Imbruvica Tab 420mg\'', '\'OM\'', '\'USD\'', 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(359, 0, '\'Imbruvica Tab 560mg\'', '\'OM\'', '\'USD\'', 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(360, 412414, '\'Incivo 375 mg Film-Coated Tabs.\'', '\'OM\'', '\'USD\'', 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(361, 412855, '\'LEUSTATIN 1MG/ML 7X10ML VIAL\'', '\'OM\'', '\'USD\'', 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(362, 387984, '\'Motilium supp. 30 mg for Child.\'', '\'OM\'', '\'USD\'', 2.81, 2.81, 2.81, 2.81, 2.81, 2.81, 2.81, 2.81, 2.81, 2.81, 2.81, 2.81, 2.81, 2.81, 2.81, 2.81, 2.81, 2.81, 2.81, 2.81, 2.81, 2.81, 2.81, 2.81, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(363, 0, '\'Opsumit 10mg\'', '\'OM\'', '\'USD\'', 2, 2, 2, 1, 2, 2, 2, 1, 2, 2, 2, 1, 2, 2, 2, 1, 2, 2, 2, 1, 2, 2, 2, 1, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(364, 416006, '\'Pariet 10 mg Tab. 14s\'', '\'OM\'', '\'USD\'', 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(365, 416007, '\'Pariet 10 mg Tab. 28s\'', '\'OM\'', '\'USD\'', 16.73, 16.73, 16.73, 16.73, 16.73, 16.73, 16.73, 16.73, 16.73, 16.73, 16.73, 16.73, 16.73, 16.73, 16.73, 16.73, 16.73, 16.73, 16.73, 16.73, 16.73, 16.73, 16.73, 16.73, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(366, 140307, '\'Pevaryl Cream 1 % 15g\'', '\'OM\'', '\'USD\'', 1.97, 1.97, 1.97, 1.97, 1.97, 1.97, 1.97, 1.97, 1.97, 1.97, 1.97, 1.97, 1.97, 1.97, 1.97, 1.97, 1.97, 1.97, 1.97, 1.97, 1.97, 1.97, 1.97, 1.97, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(367, 140309, '\'Pevaryl Cream 1 % 30g\'', '\'OM\'', '\'USD\'', 3.75, 3.75, 3.75, 3.75, 3.75, 3.75, 3.75, 3.75, 3.75, 3.75, 3.75, 3.75, 3.75, 3.75, 3.75, 3.75, 3.75, 3.75, 3.75, 3.75, 3.75, 3.75, 3.75, 3.75, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(368, 412323, '\'Pevisone Cream \'', '\'OM\'', '\'USD\'', 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(369, 0, '\'Apalutamide\'', '\'OM\'', '\'USD\'', 3, 3, 2, 2, 3, 3, 2, 2, 3, 3, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(370, 96394, '\'Reminyl 4 mg Tab.\'', '\'OM\'', '\'USD\'', 13.41, 13.41, 13.41, 13.41, 13.41, 13.41, 13.41, 13.41, 13.41, 13.41, 13.41, 13.41, 13.41, 13.41, 13.41, 13.41, 13.41, 13.41, 13.41, 13.41, 13.41, 13.41, 13.41, 13.41, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(371, 90839, '\'Reminyl 4 mg/ml Oral Solution  \'', '\'OM\'', '\'USD\'', 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(372, 90474, '\'Reminyl 8 mg Tab.\'', '\'OM\'', '\'USD\'', 69.66, 69.66, 69.66, 69.66, 69.66, 69.66, 69.66, 69.66, 69.66, 69.66, 69.66, 69.66, 69.66, 69.66, 69.66, 69.66, 69.66, 69.66, 69.66, 69.66, 69.66, 69.66, 69.66, 69.66, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(373, 377057, '\'Reminyl PR 16 mg 28 Capsule\'', '\'OM\'', '\'USD\'', 98, 98, 98, 98, 98, 98, 98, 98, 98, 98, 98, 98, 98, 98, 98, 98, 98, 98, 98, 98, 98, 98, 98, 98, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(374, 377058, '\'Reminyl PR 24 mg 28 Capsule\'', '\'OM\'', '\'USD\'', 120, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(375, 387691, '\'Concerta 18mg  Extended Release Tab.\'', '\'OM\'', '\'USD\'', 39.49, 39.49, 23.54, 23.54, 39.49, 39.49, 23.54, 23.54, 39.49, 39.49, 23.54, 23.54, 23.54, 23.54, 23.54, 23.54, 23.54, 23.54, 23.54, 23.54, 23.54, 23.54, 23.54, 23.54, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(376, 387693, '\'Concerta 36mg Extended Release Tab.\'', '\'OM\'', '\'USD\'', 51.43, 51.43, 32.69, 32.69, 51.43, 51.43, 32.69, 32.69, 51.43, 51.43, 32.69, 32.69, 32.69, 32.69, 32.69, 32.69, 32.69, 32.69, 32.69, 32.69, 32.69, 32.69, 32.69, 32.69, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(377, 415065, '\'Rezolsta\'', '\'OM\'', '\'USD\'', 463, 463, 463, 463, 463, 463, 463, 463, 463, 463, 463, 463, 463, 463, 463, 463, 463, 463, 463, 463, 463, 463, 463, 463, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(378, 87518, '\'Risperdal 1 mg/ml Oral Solution\'', '\'OM\'', '\'USD\'', 24.57, 24.57, 24.57, 24.57, 24.57, 24.57, 24.57, 24.57, 24.57, 24.57, 24.57, 24.57, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(379, 414063, '\'Eprex 10,000 U Pre-Filled Syringes \'', '\'OM\'', '\'USD\'', 298.4, 298.4, 298.4, 298.4, 298.4, 298.4, 298.4, 298.4, 298.4, 298.4, 298.4, 298.4, 205.08, 205.08, 205.08, 205.08, 205.08, 205.08, 205.08, 205.08, 205.08, 205.08, 205.08, 205.08, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(380, 414065, '\'Eprex 2,000 U Pre-Filled Syringes \'', '\'OM\'', '\'USD\'', 59.68, 59.68, 59.68, 59.68, 59.68, 59.68, 59.68, 59.68, 59.68, 59.68, 59.68, 59.68, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(381, 414068, '\'Eprex 4,000 U Pre-Filled Syringes \'', '\'OM\'', '\'USD\'', 119.36, 119.36, 119.36, 119.36, 119.36, 119.36, 119.36, 119.36, 119.36, 119.36, 119.36, 119.36, 61.82, 61.82, 61.82, 61.82, 61.82, 61.82, 61.82, 61.82, 61.82, 61.82, 61.82, 61.82, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(382, 414067, '\'Eprex 40,000 U Pre-Filled Syringe \'', '\'OM\'', '\'USD\'', 183.54, 183.54, 183.54, 183.54, 183.54, 183.54, 183.54, 183.54, 183.54, 183.54, 183.54, 183.54, 183.54, 183.54, 183.54, 183.54, 183.54, 183.54, 183.54, 183.54, 183.54, 183.54, 183.54, 183.54, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(383, 414069, '\'Eprex 6,000 U Pre-Filled Syringes \'', '\'OM\'', '\'USD\'', 203.37, 203.37, 203.37, 203.37, 203.37, 203.37, 203.37, 203.37, 203.37, 203.37, 203.37, 203.37, 116, 116, 116, 116, 116, 116, 116, 116, 116, 116, 116, 116, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(384, 0, '\'Simponi 100mg PFP\'', '\'OM\'', '\'USD\'', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 900, 900, 900, 900, 900, 900, 900, 900, 900, 900, 900, 900, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(385, 414549, '\'SIRTURO 100MG 188 Tablets\'', '\'OM\'', '\'USD\'', 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(386, 414097, '\'SPORANOX 1% 1X150ML OPLOS\'', '\'OM\'', '\'USD\'', 59, 59, 59, 59, 59, 59, 59, 59, 59, 59, 59, 59, 59, 59, 59, 59, 59, 59, 59, 59, 59, 59, 59, 59, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(387, 418455, '\'Remicade 100 mg \'', '\'OM\'', '\'USD\'', 363.63, 363.63, 363.63, 363.63, 363.63, 363.63, 363.63, 363.63, 363.63, 363.63, 363.63, 363.63, 260, 260, 260, 260, 260, 260, 260, 260, 260, 260, 260, 260, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(388, 0, '\'Spravato 2x28mg\'', '\'OM\'', '\'USD\'', 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(389, 0, '\'Spravato 3x28mg\'', '\'OM\'', '\'USD\'', 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(390, 60404, '\'Sufenta Ampoule 5 mcg/ml 10ml x 5 amp\'', '\'OM\'', '\'USD\'', 9.29, 9.29, 9.29, 9.29, 9.29, 9.29, 9.29, 9.29, 9.29, 9.29, 9.29, 9.29, 9.29, 9.29, 9.29, 9.29, 9.29, 9.29, 9.29, 9.29, 9.29, 9.29, 9.29, 9.29, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(391, 90501, '\'Sufenta Ampoule 5 mcg/ml 2ml x 5 amp\'', '\'OM\'', '\'USD\'', 2.32, 2.32, 2.32, 2.32, 2.32, 2.32, 2.32, 2.32, 2.32, 2.32, 2.32, 2.32, 2.32, 2.32, 2.32, 2.32, 2.32, 2.32, 2.32, 2.32, 2.32, 2.32, 2.32, 2.32, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(392, 0, '\'Sufenta Forte Amp 50 mcg/ml 5ml x 5 amp\'', '\'OM\'', '\'USD\'', 29.65, 29.65, 29.65, 29.65, 29.65, 29.65, 29.65, 29.65, 29.65, 29.65, 29.65, 29.65, 29.65, 29.65, 29.65, 29.65, 29.65, 29.65, 29.65, 29.65, 29.65, 29.65, 29.65, 29.65, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(393, 0, '\'Symtuza\'', '\'OM\'', '\'USD\'', 869, 869, 869, 869, 869, 869, 869, 869, 869, 869, 869, 869, 869, 869, 869, 869, 869, 869, 869, 869, 869, 869, 869, 869, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(394, 0, '\'Tracleer 125mg\'', '\'OM\'', '\'USD\'', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(395, 141023, '\'Topamax 200 mg Tab.\'', '\'OM\'', '\'USD\'', 69.68, 69.68, 69.68, 69.68, 69.68, 69.68, 69.68, 69.68, 69.68, 69.68, 69.68, 69.68, 69.68, 69.68, 69.68, 69.68, 69.68, 69.68, 69.68, 69.68, 69.68, 69.68, 69.68, 69.68, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(396, 412303, '\'Topamax 25 mg Sprinkle Cap.\'', '\'OM\'', '\'USD\'', 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(397, 412305, '\'Topamax 50 mg Sprinkle Cap.\'', '\'OM\'', '\'USD\'', 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(398, 0, '\'Tracleer 62.5mg\'', '\'OM\'', '\'USD\'', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(399, 0, '\'Uptravi\'', '\'OM\'', '\'USD\'', 4, 4, 4, 2, 4, 4, 4, 2, 4, 4, 4, 2, 4, 4, 4, 2, 4, 4, 4, 2, 4, 4, 4, 2, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(400, 414963, '\'Velcade Injection 3.5 mg\'', '\'OM\'', '\'USD\'', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 740, 740, 740, 740, 740, 740, 740, 740, 740, 740, 740, 740, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(401, 0, '\'Vermox 500 mg Tab.\'', '\'OM\'', '\'USD\'', 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(402, 0, '\'Zavesca 84 cap 100mg \'', '\'OM\'', '\'USD\'', 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(403, 0, '\'Zytiga 500 mg Tabs\'', '\'OM\'', '\'USD\'', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(404, 414066, '\'Eprex 3,000 U Pre-Filled Syringes \'', '\'QA\'', '\'USD\'', 91.5, 91.5, 91.5, 91.5, 91.5, 91.5, 91.5, 91.5, 91.5, 91.5, 91.5, 91.5, 91.5, 91.5, 91.5, 91.5, 91.5, 91.5, 91.5, 91.5, 91.5, 91.5, 91.5, 91.5, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(405, 414434, '\'Caelyx 2 mg/ml\'', '\'QA\'', '\'USD\'', 512, 512, 512, 512, 512, 512, 512, 512, 512, 512, 512, 512, 512, 512, 512, 512, 512, 512, 512, 512, 512, 512, 512, 512, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(406, 0, '\'Cilest Tab. 21tab\'', '\'QA\'', '\'USD\'', 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(407, 0, '\'Cilest Tab. 36tab\'', '\'QA\'', '\'USD\'', 9.08, 9.08, 9.08, 9.08, 9.08, 9.08, 9.08, 9.08, 9.08, 9.08, 9.08, 9.08, 9.08, 9.08, 9.08, 9.08, 9.08, 9.08, 9.08, 9.08, 9.08, 9.08, 9.08, 9.08, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(408, 387691, '\'Concerta 18mg  Extended Release Tab.\'', '\'QA\'', '\'USD\'', 33.57, 33.57, 33.57, 33.57, 33.57, 33.57, 33.57, 33.57, 33.57, 33.57, 33.57, 33.57, 23.54, 23.54, 23.54, 23.54, 23.54, 23.54, 23.54, 23.54, 23.54, 23.54, 23.54, 23.54, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(409, 387693, '\'Concerta 36mg Extended Release Tab.\'', '\'QA\'', '\'USD\'', 45.7, 45.7, 45.7, 45.7, 45.7, 45.7, 45.7, 45.7, 45.7, 45.7, 45.7, 45.7, 32.69, 32.69, 32.69, 32.69, 32.69, 32.69, 32.69, 32.69, 32.69, 32.69, 32.69, 32.69, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(410, 32442, '\'Daktacort Cream                 \'', '\'QA\'', '\'USD\'', 2.31, 2.31, 2.31, 2.31, 2.31, 2.31, 2.31, 2.31, 2.31, 2.31, 2.31, 2.31, 2.31, 2.31, 2.31, 2.31, 2.31, 2.31, 2.31, 2.31, 2.31, 2.31, 2.31, 2.31, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(411, 88877, '\'Daktarin Cream 2% 30g\'', '\'QA\'', '\'USD\'', 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(412, 377017, '\'Daktarin Powder 2%\'', '\'QA\'', '\'USD\'', 2.19, 2.19, 2.19, 2.19, 2.19, 2.19, 2.19, 2.19, 2.19, 2.19, 2.19, 2.19, 2.19, 2.19, 2.19, 2.19, 2.19, 2.19, 2.19, 2.19, 2.19, 2.19, 2.19, 2.19, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(413, 32441, '\'Daktarin Oral Gel 2%\'', '\'QA\'', '\'USD\'', 3.19, 3.19, 3.19, 3.19, 3.19, 3.19, 3.19, 3.19, 3.19, 3.19, 3.19, 3.19, 3.19, 3.19, 3.19, 3.19, 3.19, 3.19, 3.19, 3.19, 3.19, 3.19, 3.19, 3.19, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(414, 0, '\'Daktarin Lotion 2% \'', '\'QA\'', '\'USD\'', 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(415, 0, '\'Doribax 500 mg Injection \'', '\'QA\'', '\'USD\'', 179.21, 179.21, 179.21, 179.21, 179.21, 179.21, 179.21, 179.21, 179.21, 179.21, 179.21, 179.21, 179.21, 179.21, 179.21, 179.21, 179.21, 179.21, 179.21, 179.21, 179.21, 179.21, 179.21, 179.21, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(416, 387398, '\'Durogesic Transdermal Patches 12 mcg/h\'', '\'QA\'', '\'USD\'', 17.62, 17.62, 17.62, 17.62, 17.62, 17.62, 17.62, 17.62, 17.62, 17.62, 17.62, 17.62, 17.62, 17.62, 17.62, 17.62, 17.62, 17.62, 17.62, 17.62, 17.62, 17.62, 17.62, 17.62, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(417, 387399, '\'Durogesic Transdermal Patches 25 mcg/h\'', '\'QA\'', '\'USD\'', 31.12, 31.12, 31.12, 31.12, 31.12, 31.12, 31.12, 31.12, 31.12, 31.12, 31.12, 31.12, 31.12, 31.12, 7.11, 7.11, 31.12, 31.12, 7.11, 7.11, 31.12, 31.12, 7.11, 7.11, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(418, 387400, '\'Durogesic Transdermal Patches 50 mcg/h\'', '\'QA\'', '\'USD\'', 52.29, 52.29, 52.29, 52.29, 52.29, 52.29, 52.29, 52.29, 52.29, 52.29, 52.29, 52.29, 52.29, 52.29, 13.07, 13.07, 52.29, 52.29, 13.07, 13.07, 52.29, 52.29, 13.07, 13.07, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(419, 387401, '\'Durogesic Transdermal Patches 75 mcg/h\'', '\'QA\'', '\'USD\'', 80.1, 80.1, 80.1, 80.1, 80.1, 80.1, 80.1, 80.1, 80.1, 80.1, 80.1, 80.1, 80.1, 80.1, 80.1, 80.1, 80.1, 80.1, 80.1, 80.1, 80.1, 80.1, 80.1, 80.1, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(420, 387397, '\'Durogesic Transdermal Patches 100 mcg/h\'', '\'QA\'', '\'USD\'', 98.73, 98.73, 98.73, 98.73, 98.73, 98.73, 98.73, 98.73, 98.73, 98.73, 98.73, 98.73, 98.73, 98.73, 98.73, 98.73, 98.73, 98.73, 98.73, 98.73, 98.73, 98.73, 98.73, 98.73, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(421, 414064, '\'Eprex 1,000 U Pre-Filled Syringes \'', '\'QA\'', '\'USD\'', 33.36, 33.36, 33.36, 33.36, 33.36, 33.36, 33.36, 33.36, 33.36, 33.36, 33.36, 33.36, 33.36, 33.36, 33.36, 33.36, 33.36, 33.36, 33.36, 33.36, 33.36, 33.36, 33.36, 33.36, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(422, 414065, '\'Eprex 2,000 U Pre-Filled Syringes \'', '\'QA\'', '\'USD\'', 59.68, 59.68, 59.68, 59.68, 59.68, 59.68, 59.68, 59.68, 59.68, 59.68, 59.68, 59.68, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(423, 414068, '\'Eprex 4,000 U Pre-Filled Syringes \'', '\'QA\'', '\'USD\'', 119.36, 119.36, 119.36, 119.36, 119.36, 119.36, 119.36, 119.36, 119.36, 119.36, 119.36, 119.36, 67.2, 67.2, 67.2, 67.2, 67.2, 67.2, 67.2, 67.2, 67.2, 67.2, 67.2, 67.2, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(424, 0, '\'Eprex 5,000 U Pre-Filled Syringes \'', '\'QA\'', '\'USD\'', 203.37, 203.37, 203.37, 203.37, 203.37, 203.37, 203.37, 203.37, 203.37, 203.37, 203.37, 203.37, 78.67, 78.67, 78.67, 78.67, 78.67, 78.67, 78.67, 78.67, 78.67, 78.67, 78.67, 78.67, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(425, 414069, '\'Eprex 6,000 U Pre-Filled Syringes \'', '\'QA\'', '\'USD\'', 203.37, 203.37, 203.37, 203.37, 203.37, 203.37, 203.37, 203.37, 203.37, 203.37, 203.37, 203.37, 116, 116, 116, 116, 116, 116, 116, 116, 116, 116, 116, 116, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(426, 0, '\'Eprex 8,000 U Pre-Filled Syringes \'', '\'QA\'', '\'USD\'', 245.71, 245.71, 245.71, 245.71, 245.71, 245.71, 245.71, 245.71, 245.71, 245.71, 245.71, 245.71, 245.71, 245.71, 245.71, 245.71, 245.71, 245.71, 245.71, 245.71, 245.71, 245.71, 245.71, 245.71, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(427, 414063, '\'Eprex 10,000 U Pre-Filled Syringes \'', '\'QA\'', '\'USD\'', 298.4, 298.4, 298.4, 298.4, 298.4, 298.4, 298.4, 298.4, 298.4, 298.4, 298.4, 298.4, 205.08, 205.08, 205.08, 205.08, 205.08, 205.08, 205.08, 205.08, 205.08, 205.08, 205.08, 205.08, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(428, 414067, '\'Eprex 40,000 U Pre-Filled Syringe \'', '\'QA\'', '\'USD\'', 183.54, 183.54, 183.54, 183.54, 183.54, 183.54, 183.54, 183.54, 183.54, 183.54, 183.54, 183.54, 183.54, 183.54, 183.54, 183.54, 183.54, 183.54, 183.54, 183.54, 183.54, 183.54, 183.54, 183.54, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(429, 140788, '\'Evra Transdermal Patches \'', '\'QA\'', '\'USD\'', 8.17, 8.17, 8.17, 8.17, 8.17, 8.17, 8.17, 8.17, 8.17, 8.17, 8.17, 8.17, 8.17, 8.17, 8.17, 8.17, 8.17, 8.17, 8.17, 8.17, 8.17, 8.17, 8.17, 8.17, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(430, 88878, '\'Gyno-Daktarin V. Cream \'', '\'QA\'', '\'USD\'', 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(431, 414691, '\'Gyno Daktarin 200 mg V. Capsules\'', '\'QA\'', '\'USD\'', 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(432, 414690, '\'Gyno Daktarin 400 mg V. Capsules\'', '\'QA\'', '\'USD\'', 3.94, 3.94, 3.94, 3.94, 3.94, 3.94, 3.94, 3.94, 3.94, 3.94, 3.94, 3.94, 3.94, 3.94, 3.94, 3.94, 3.94, 3.94, 3.94, 3.94, 3.94, 3.94, 3.94, 3.94, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(433, 140311, '\'Gyno-Pevaryl V. Cream \'', '\'QA\'', '\'USD\'', 7.77, 7.77, 7.77, 7.77, 7.77, 7.77, 7.77, 7.77, 7.77, 7.77, 7.77, 7.77, 7.77, 7.77, 7.77, 7.77, 7.77, 7.77, 7.77, 7.77, 7.77, 7.77, 7.77, 7.77, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(434, 387445, '\'Gyno Pevaryl 150 mg V. Suppositories\'', '\'QA\'', '\'USD\'', 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(435, 387447, '\'Gyno-Pevaryl Depot 150 mg V. Ovules\'', '\'QA\'', '\'USD\'', 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(436, 412414, '\'Incivo 375 mg Film-Coated Tabs.\'', '\'QA\'', '\'USD\'', 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(437, 378218, '\'Intelence 100 mg Tab. \'', '\'QA\'', '\'USD\'', 491.87, 491.87, 491.87, 491.87, 491.87, 491.87, 491.87, 491.87, 491.87, 491.87, 491.87, 491.87, 491.87, 491.87, 491.87, 491.87, 491.87, 491.87, 491.87, 491.87, 491.87, 491.87, 491.87, 491.87, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(438, 387165, '\'Invega 3 mg Extended Release Tab. \'', '\'QA\'', '\'USD\'', 88.12, 88.12, 88.12, 88.12, 88.12, 88.12, 88.12, 88.12, 88.12, 88.12, 88.12, 88.12, 88.12, 88.12, 41.39, 41.39, 88.12, 88.12, 41.39, 41.39, 88.12, 88.12, 41.39, 41.39, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(439, 387168, '\'Invega 6 mg Extended Release Tab. \'', '\'QA\'', '\'USD\'', 88.12, 88.12, 88.12, 88.12, 88.12, 88.12, 88.12, 88.12, 88.12, 88.12, 88.12, 88.12, 88.12, 88.12, 48.8, 48.8, 88.12, 88.12, 48.8, 48.8, 88.12, 88.12, 48.8, 48.8, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(440, 387171, '\'Invega 9 mg Extended Release Tab. \'', '\'QA\'', '\'USD\'', 95.51, 95.51, 95.51, 95.51, 95.51, 95.51, 95.51, 95.51, 95.51, 95.51, 95.51, 95.51, 95.51, 95.51, 95.51, 95.51, 95.51, 95.51, 95.51, 95.51, 95.51, 95.51, 95.51, 95.51, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(441, 387758, '\'Invega Sustenna 50 mg/ 0.5 ml \'', '\'QA\'', '\'USD\'', 186.86, 186.86, 186.86, 186.86, 186.86, 186.86, 186.86, 186.86, 186.86, 186.86, 186.86, 186.86, 186.86, 186.86, 186.86, 186.86, 186.86, 186.86, 186.86, 186.86, 186.86, 186.86, 186.86, 186.86, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(442, 387759, '\'Invega Sustenna 75 mg/ 0.75 ml \'', '\'QA\'', '\'USD\'', 243.86, 243.86, 243.86, 243.86, 243.86, 243.86, 243.86, 243.86, 243.86, 243.86, 243.86, 243.86, 243.86, 243.86, 243.86, 243.86, 243.86, 243.86, 243.86, 243.86, 243.86, 243.86, 243.86, 243.86, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(443, 387760, '\'Invega Sustenna 100 mg/ 1 ml \'', '\'QA\'', '\'USD\'', 298.89, 298.89, 298.89, 298.89, 298.89, 298.89, 298.89, 298.89, 298.89, 298.89, 298.89, 298.89, 298.89, 298.89, 298.89, 298.89, 298.89, 298.89, 298.89, 298.89, 298.89, 298.89, 298.89, 298.89, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(444, 387761, '\'Invega Sustenna 150 mg/ 1.5 ml \'', '\'QA\'', '\'USD\'', 347.74, 347.74, 347.74, 347.74, 347.74, 347.74, 347.74, 347.74, 347.74, 347.74, 347.74, 347.74, 347.74, 347.74, 347.74, 347.74, 347.74, 347.74, 347.74, 347.74, 347.74, 347.74, 347.74, 347.74, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(445, 414907, '\'Invokana 100mg \'', '\'QA\'', '\'USD\'', 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(446, 414908, '\'Invokana 300mg\'', '\'QA\'', '\'USD\'', 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 23.54, 23.54, 23.54, 23.54, 23.54, 23.54, 23.54, 23.54, 23.54, 23.54, 23.54, 23.54, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(447, 418514, '\'Motilium 10 mg Tab. 30s\'', '\'QA\'', '\'USD\'', 3.3, 3.3, 3.3, 3.3, 3.3, 3.3, 3.3, 3.3, 3.3, 3.3, 3.3, 3.3, 2.66, 2.66, 2.66, 2.66, 2.66, 2.66, 2.66, 2.66, 2.66, 2.66, 2.66, 2.66, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(448, 416936, '\'Motilium 1 mg/ml Oral Suspension 200ml\'', '\'QA\'', '\'USD\'', 3.2, 3.2, 3.2, 3.2, 3.2, 3.2, 3.2, 3.2, 3.2, 3.2, 3.2, 3.2, 2.8, 2.8, 2.8, 2.8, 2.8, 2.8, 2.8, 2.8, 2.8, 2.8, 2.8, 2.8, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(449, 414696, '\'Nizoral Cream 2 %\'', '\'QA\'', '\'USD\'', 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(450, 416006, '\'Pariet 10 mg Tab. 14s\'', '\'QA\'', '\'USD\'', 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(451, 416007, '\'Pariet 10 mg Tab. 28s\'', '\'QA\'', '\'USD\'', 16.73, 16.73, 16.73, 16.73, 16.73, 16.73, 16.73, 16.73, 16.73, 16.73, 16.73, 16.73, 16.73, 16.73, 16.73, 16.73, 16.73, 16.73, 16.73, 16.73, 16.73, 16.73, 16.73, 16.73, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(452, 416919, '\'Pariet 20 mg Tab. 14s\'', '\'QA\'', '\'USD\'', 12.06, 12.06, 12.06, 12.06, 12.06, 12.06, 12.06, 12.06, 12.06, 12.06, 12.06, 12.06, 11.2, 11.2, 11.2, 11.2, 11.2, 11.2, 11.2, 11.2, 11.2, 11.2, 11.2, 11.2, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(453, 416920, '\'Pariet 20 mg Tab. 28s\'', '\'QA\'', '\'USD\'', 26.01, 26.01, 26.01, 26.01, 26.01, 26.01, 26.01, 26.01, 26.01, 26.01, 26.01, 26.01, 26.01, 26.01, 26.01, 26.01, 26.01, 26.01, 26.01, 26.01, 26.01, 26.01, 26.01, 26.01, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(454, 412323, '\'Pevisone Cream \'', '\'QA\'', '\'USD\'', 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(455, 140309, '\'Pevaryl Cream 1 % 30g\'', '\'QA\'', '\'USD\'', 3.75, 3.75, 3.75, 3.75, 3.75, 3.75, 3.75, 3.75, 3.75, 3.75, 3.75, 3.75, 2.6, 2.6, 2.6, 2.6, 2.6, 2.6, 2.6, 2.6, 2.6, 2.6, 2.6, 2.6, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(456, 387104, '\'Prezista 400 mg Tablets\'', '\'QA\'', '\'USD\'', 402.77, 402.77, 402.77, 402.77, 402.77, 402.77, 402.77, 402.77, 402.77, 402.77, 402.77, 402.77, 402.77, 402.77, 402.77, 402.77, 402.77, 402.77, 402.77, 402.77, 402.77, 402.77, 402.77, 402.77, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(457, 387107, '\'Prezista 600 mg Tablets\'', '\'QA\'', '\'USD\'', 615.22, 615.22, 615.22, 615.22, 615.22, 615.22, 615.22, 615.22, 615.22, 615.22, 615.22, 615.22, 615.22, 615.22, 615.22, 615.22, 615.22, 615.22, 615.22, 615.22, 615.22, 615.22, 615.22, 615.22, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(458, 96394, '\'Reminyl 4 mg Tab.\'', '\'QA\'', '\'USD\'', 13.41, 13.41, 13.41, 13.41, 13.41, 13.41, 13.41, 13.41, 13.41, 13.41, 13.41, 13.41, 13.41, 13.41, 13.41, 13.41, 13.41, 13.41, 13.41, 13.41, 13.41, 13.41, 13.41, 13.41, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(459, 90474, '\'Reminyl 8 mg Tab.\'', '\'QA\'', '\'USD\'', 69.66, 69.66, 69.66, 69.66, 69.66, 69.66, 69.66, 69.66, 69.66, 69.66, 69.66, 69.66, 69.66, 69.66, 69.66, 69.66, 69.66, 69.66, 69.66, 69.66, 69.66, 69.66, 69.66, 69.66, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(460, 90839, '\'Reminyl 4 mg/ml Oral Solution  \'', '\'QA\'', '\'USD\'', 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(461, 412688, '\'Remicade 100 mg \'', '\'QA\'', '\'USD\'', 468.97, 468.97, 468.97, 468.97, 468.97, 468.97, 468.97, 468.97, 468.97, 468.97, 468.97, 468.97, 240, 240, 240, 240, 240, 240, 240, 240, 240, 240, 240, 240, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(462, 414050, '\'Resolor 1 mg Film-Coated Tabs.\'', '\'QA\'', '\'USD\'', 32.51, 32.51, 26.33, 26.33, 32.51, 32.51, 26.33, 26.33, 32.51, 32.51, 26.33, 26.33, 32.51, 32.51, 26.33, 26.33, 32.51, 32.51, 26.33, 26.33, 32.51, 32.51, 26.33, 26.33, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(463, 414053, '\'Resolor 2 mg Film-Coated Tabs.\'', '\'QA\'', '\'USD\'', 53.46, 53.46, 43.29, 43.29, 53.46, 53.46, 43.29, 43.29, 53.46, 53.46, 43.29, 43.29, 53.46, 53.46, 23.54, 23.54, 53.46, 53.46, 23.54, 23.54, 53.46, 53.46, 23.54, 23.54, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(464, 376853, '\'Risperdal 1mg Tab. 6s\'', '\'QA\'', '\'USD\'', 4.58, 4.58, 4.58, 4.58, 4.58, 4.58, 4.58, 4.58, 4.58, 4.58, 4.58, 4.58, 2.29, 2.29, 2.29, 2.29, 2.29, 2.29, 2.29, 2.29, 2.29, 2.29, 2.29, 2.29, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(465, 376854, '\'Risperdal 1mg Tab. 20s\'', '\'QA\'', '\'USD\'', 15.27, 15.27, 15.27, 15.27, 15.27, 15.27, 15.27, 15.27, 15.27, 15.27, 15.27, 15.27, 7.63, 7.63, 7.63, 7.63, 7.63, 7.63, 7.63, 7.63, 7.63, 7.63, 7.63, 7.63, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(466, 88081, '\'Risperdal 1mg Tab. 60s\'', '\'QA\'', '\'USD\'', 45.8, 45.8, 45.8, 45.8, 45.8, 45.8, 45.8, 45.8, 45.8, 45.8, 45.8, 45.8, 22.9, 22.9, 22.9, 22.9, 22.9, 22.9, 22.9, 22.9, 22.9, 22.9, 22.9, 22.9, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(467, 376855, '\'Risperdal 2mg Tab. 20s\'', '\'QA\'', '\'USD\'', 21.27, 21.27, 21.27, 21.27, 21.27, 21.27, 21.27, 21.27, 21.27, 21.27, 21.27, 21.27, 10.64, 10.64, 10.64, 10.64, 10.64, 10.64, 10.64, 10.64, 10.64, 10.64, 10.64, 10.64, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(468, 96552, '\'Risperdal 2mg Tab. 60s\'', '\'QA\'', '\'USD\'', 58.54, 58.54, 58.54, 58.54, 58.54, 58.54, 58.54, 58.54, 58.54, 58.54, 58.54, 58.54, 29.27, 29.27, 29.27, 29.27, 29.27, 29.27, 29.27, 29.27, 29.27, 29.27, 29.27, 29.27, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(469, 376856, '\'Risperdal 3mg Tab. 20s\'', '\'QA\'', '\'USD\'', 27.36, 27.36, 27.36, 27.36, 27.36, 27.36, 27.36, 27.36, 27.36, 27.36, 27.36, 27.36, 13.68, 13.68, 13.68, 13.68, 13.68, 13.68, 13.68, 13.68, 13.68, 13.68, 13.68, 13.68, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(470, 96568, '\'Risperdal 3mg Tab. 60s\'', '\'QA\'', '\'USD\'', 75.29, 75.29, 75.29, 75.29, 75.29, 75.29, 75.29, 75.29, 75.29, 75.29, 75.29, 75.29, 37.65, 37.65, 37.65, 37.65, 37.65, 37.65, 37.65, 37.65, 37.65, 37.65, 37.65, 37.65, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(471, 96327, '\'Risperdal 4mg Tab. 20s\'', '\'QA\'', '\'USD\'', 34.89, 34.89, 34.89, 34.89, 34.89, 34.89, 34.89, 34.89, 34.89, 34.89, 34.89, 34.89, 17.45, 17.45, 17.45, 17.45, 17.45, 17.45, 17.45, 17.45, 17.45, 17.45, 17.45, 17.45, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(472, 96569, '\'Risperdal 4mg Tab. 60s\'', '\'QA\'', '\'USD\'', 96, 96, 96, 96, 96, 96, 96, 96, 96, 96, 96, 96, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(473, 87518, '\'Risperdal 1 mg/ml Oral Solution\'', '\'QA\'', '\'USD\'', 46.52, 46.52, 46.52, 46.52, 46.52, 46.52, 46.52, 46.52, 46.52, 46.52, 46.52, 46.52, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(474, 376595, '\'Risperdal Consta 25 mg Inj.  \'', '\'QA\'', '\'USD\'', 116.79, 116.79, 116.79, 116.79, 116.79, 116.79, 116.79, 116.79, 116.79, 116.79, 116.79, 116.79, 73.96, 73.96, 73.96, 73.96, 73.96, 73.96, 73.96, 73.96, 73.96, 73.96, 73.96, 73.96, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(475, 376596, '\'Risperdal Consta 37.5 mg Inj. \'', '\'QA\'', '\'USD\'', 154.05, 154.05, 154.05, 154.05, 154.05, 154.05, 154.05, 154.05, 154.05, 154.05, 154.05, 154.05, 102.95, 102.95, 102.95, 102.95, 102.95, 102.95, 102.95, 102.95, 102.95, 102.95, 102.95, 102.95, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(476, 376597, '\'Risperdal Consta 50 mg Inj.  \'', '\'QA\'', '\'USD\'', 189.61, 189.61, 189.61, 189.61, 189.61, 189.61, 189.61, 189.61, 189.61, 189.61, 189.61, 189.61, 122.95, 122.95, 122.95, 122.95, 122.95, 122.95, 122.95, 122.95, 122.95, 122.95, 122.95, 122.95, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(477, 412675, '\'Simponi 50 mg/ 0.5 ml Injection (PFP)\'', '\'QA\'', '\'USD\'', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(478, 414287, '\'Stelara 45mg/0.5ml \'', '\'QA\'', '\'USD\'', 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(479, 414288, '\'Stelara 90mg/1ml\'', '\'QA\'', '\'USD\'', 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(480, 96489, '\'Sporanox 100 mg Cap. 4s\'', '\'QA\'', '\'USD\'', 6.51, 6.51, 6.51, 6.51, 6.51, 6.51, 6.51, 6.51, 6.51, 6.51, 6.51, 6.51, 6.51, 6.51, 6.51, 6.51, 6.51, 6.51, 6.51, 6.51, 6.51, 6.51, 6.51, 6.51, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(481, 376935, '\'Sporanox 100 mg Cap. 15s\'', '\'QA\'', '\'USD\'', 21.26, 21.26, 21.26, 21.26, 21.26, 21.26, 21.26, 21.26, 21.26, 21.26, 21.26, 21.26, 21.26, 21.26, 21.26, 21.26, 21.26, 21.26, 21.26, 21.26, 21.26, 21.26, 21.26, 21.26, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(482, 96046, '\'Stugeron 25 mg Tab.\'', '\'QA\'', '\'USD\'', 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(483, 141016, '\'Topamax 25 mg Tab.\'', '\'QA\'', '\'USD\'', 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(484, 141019, '\'Topamax 50 mg Tab.\'', '\'QA\'', '\'USD\'', 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(485, 141021, '\'Topamax 100 mg Tab.\'', '\'QA\'', '\'USD\'', 42.49, 42.49, 42.49, 42.49, 42.49, 42.49, 42.49, 42.49, 42.49, 42.49, 42.49, 42.49, 42.49, 42.49, 42.49, 42.49, 42.49, 42.49, 42.49, 42.49, 42.49, 42.49, 42.49, 42.49, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(486, 141023, '\'Topamax 200 mg Tab.\'', '\'QA\'', '\'USD\'', 69.68, 69.68, 69.68, 69.68, 69.68, 69.68, 69.68, 69.68, 69.68, 69.68, 69.68, 69.68, 69.68, 69.68, 69.68, 69.68, 69.68, 69.68, 69.68, 69.68, 69.68, 69.68, 69.68, 69.68, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(487, 412301, '\'Topamax 15 mg Sprinkle Cap.\'', '\'QA\'', '\'USD\'', 11.78, 11.78, 11.78, 11.78, 11.78, 11.78, 11.78, 11.78, 11.78, 11.78, 11.78, 11.78, 11.78, 11.78, 11.78, 11.78, 11.78, 11.78, 11.78, 11.78, 11.78, 11.78, 11.78, 11.78, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(488, 412303, '\'Topamax 25 mg Sprinkle Cap.\'', '\'QA\'', '\'USD\'', 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(489, 412305, '\'Topamax 50 mg Sprinkle Cap.\'', '\'QA\'', '\'USD\'', 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(490, 96063, '\'Vermox 100 mg Tab. 6s\'', '\'QA\'', '\'USD\'', 1.56, 1.56, 1.56, 1.56, 1.56, 1.56, 1.56, 1.56, 1.56, 1.56, 1.56, 1.56, 1.56, 1.56, 1.56, 1.56, 1.56, 1.56, 1.56, 1.56, 1.56, 1.56, 1.56, 1.56, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(491, 96048, '\'Vermox 500 mg Tab.\'', '\'QA\'', '\'USD\'', 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(492, 32461, '\'Vermox 20 mg/ml Oral Susp.\'', '\'QA\'', '\'USD\'', 1.66, 1.66, 1.66, 1.66, 1.66, 1.66, 1.66, 1.66, 1.66, 1.66, 1.66, 1.66, 1.66, 1.66, 1.66, 1.66, 1.66, 1.66, 1.66, 1.66, 1.66, 1.66, 1.66, 1.66, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(493, 414963, '\'Velcade Injection 3.5 mg\'', '\'QA\'', '\'USD\'', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 740, 740, 740, 740, 740, 740, 740, 740, 740, 740, 740, 740, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(494, 385589, '\'Yondelis 1 mg Injection \'', '\'QA\'', '\'USD\'', 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(495, 414448, '\'Zytiga 250 mg Tabs\'', '\'QA\'', '\'USD\'', 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(496, 415168, '\'Darzalex 100mg\'', '\'QA\'', '\'USD\'', 449.75, 449.75, 449.75, 449.75, 449.75, 449.75, 449.75, 449.75, 449.75, 449.75, 449.75, 449.75, 449.75, 449.75, 449.75, 449.75, 449.75, 449.75, 449.75, 449.75, 449.75, 449.75, 449.75, 449.75, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(497, 0, '\'Simponi 100mg PFP\'', '\'QA\'', '\'USD\'', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(498, 0, '\'Zytiga 500 mg Tabs\'', '\'QA\'', '\'USD\'', 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(499, 415065, '\'Rezolsta\'', '\'QA\'', '\'USD\'', 463, 463, 463, 463, 463, 463, 463, 463, 463, 463, 463, 463, 463, 463, 463, 463, 463, 463, 463, 463, 463, 463, 463, 463, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(500, 414778, '\'Imbruvica 140mg Capsule \'', '\'QA\'', '\'USD\'', 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(501, 415169, '\'Darzalex 400mg\'', '\'QA\'', '\'USD\'', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(502, 418626, '\'Trevicta 175mg (50mg eq.)\'', '\'QA\'', '\'USD\'', 563.33, 563.33, 563.33, 563.33, 563.33, 563.33, 563.33, 563.33, 563.33, 563.33, 563.33, 563.33, 563.33, 563.33, 563.33, 563.33, 563.33, 563.33, 563.33, 563.33, 563.33, 563.33, 563.33, 563.33, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(503, 418624, '\'Trevicta 263mg (75mg eq.) \'', '\'QA\'', '\'USD\'', 746.93, 746.93, 746.93, 746.93, 746.93, 746.93, 746.93, 746.93, 746.93, 746.93, 746.93, 746.93, 746.93, 746.93, 746.93, 746.93, 746.93, 746.93, 746.93, 746.93, 746.93, 746.93, 746.93, 746.93, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(504, 418623, '\'Trevicta 360mg (100mg eq.) \'', '\'QA\'', '\'USD\'', 952.11, 952.11, 952.11, 952.11, 952.11, 952.11, 952.11, 952.11, 952.11, 952.11, 952.11, 952.11, 952.11, 952.11, 952.11, 952.11, 952.11, 952.11, 952.11, 952.11, 952.11, 952.11, 952.11, 952.11, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(505, 418621, '\'Trevicta 525mg (150mg eq.) \'', '\'QA\'', '\'USD\'', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(506, 377907, '\'DACOGEN IV 1X50MG VIAL\'', '\'QA\'', '\'USD\'', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(507, 387692, '\'CONCERTA 27MG 30 OR.TABL. BOTT GURA A SE\'', '\'QA\'', '\'USD\'', 53.46, 53.46, 53.46, 53.46, 53.46, 53.46, 53.46, 53.46, 53.46, 53.46, 53.46, 53.46, 53.46, 53.46, 53.46, 53.46, 53.46, 53.46, 53.46, 53.46, 53.46, 53.46, 53.46, 53.46, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(508, 387694, '\'CONCERTA 54MG 30 OR.TABL.\'', '\'QA\'', '\'USD\'', 71.28, 71.28, 71.28, 71.28, 71.28, 71.28, 71.28, 71.28, 71.28, 71.28, 71.28, 71.28, 71.28, 71.28, 71.28, 71.28, 71.28, 71.28, 71.28, 71.28, 71.28, 71.28, 71.28, 71.28, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(509, 412117, '\'Fentanyl 0.05 mg/ml Inj. 2ml x 50 amps\'', '\'QA\'', '\'USD\'', 19.73, 19.73, 19.73, 19.73, 19.73, 19.73, 19.73, 19.73, 19.73, 19.73, 19.73, 19.73, 19.73, 19.73, 19.73, 19.73, 19.73, 19.73, 19.73, 19.73, 19.73, 19.73, 19.73, 19.73, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(510, 412129, '\'Haldol Amp. 5mg/ml\'', '\'QA\'', '\'USD\'', 4.47, 4.47, 4.47, 4.47, 4.47, 4.47, 4.47, 4.47, 4.47, 4.47, 4.47, 4.47, 4.47, 4.47, 4.47, 4.47, 4.47, 4.47, 4.47, 4.47, 4.47, 4.47, 4.47, 4.47, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(511, 412132, '\'Haldol Deconoas Inj. 100mg/ml\'', '\'QA\'', '\'USD\'', 9.75, 9.75, 9.75, 9.75, 9.75, 9.75, 9.75, 9.75, 9.75, 9.75, 9.75, 9.75, 9.75, 9.75, 9.75, 9.75, 9.75, 9.75, 9.75, 9.75, 9.75, 9.75, 9.75, 9.75, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(512, 96044, '\'Orap Forte Tab. 4mg\'', '\'QA\'', '\'USD\'', 7.88, 7.88, 7.88, 7.88, 7.88, 7.88, 7.88, 7.88, 7.88, 7.88, 7.88, 7.88, 7.88, 7.88, 7.88, 7.88, 7.88, 7.88, 7.88, 7.88, 7.88, 7.88, 7.88, 7.88, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(513, 378353, '\'PEVARYL 10MG/G 1X30ML PUMP.SPR LUSO INTL\'', '\'QA\'', '\'USD\'', 6.75, 6.75, 6.75, 6.75, 6.75, 6.75, 6.75, 6.75, 6.75, 6.75, 6.75, 6.75, 6.75, 6.75, 6.75, 6.75, 6.75, 6.75, 6.75, 6.75, 6.75, 6.75, 6.75, 6.75, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(514, 414549, '\'SIRTURO 100MG 188 Tablets\'', '\'QA\'', '\'USD\'', 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(515, 0, '\'Guselkumab\'', '\'QA\'', '\'USD\'', 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(516, 0, '\'Stelara 130mg\'', '\'QA\'', '\'USD\'', 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(517, 0, '\'Apalutamide\'', '\'QA\'', '\'USD\'', 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(518, 0, '\'Tracleer 62.5mg\'', '\'QA\'', '\'USD\'', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(519, 0, '\'Tracleer 125mg\'', '\'QA\'', '\'USD\'', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(520, 0, '\'Uptravi\'', '\'QA\'', '\'USD\'', 5, 3, 3, 3, 5, 3, 3, 3, 5, 3, 3, 3, 5, 4, 4, 4, 5, 4, 4, 4, 5, 4, 4, 4, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(521, 0, '\'Opsumit 10mg\'', '\'QA\'', '\'USD\'', 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(522, 0, '\'Zavesca 84 cap 100mg \'', '\'QA\'', '\'USD\'', 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(523, 0, '\'Symtuza\'', '\'QA\'', '\'USD\'', 869, 869, 869, 869, 869, 869, 869, 869, 869, 869, 869, 869, 869, 869, 869, 869, 869, 869, 869, 869, 869, 869, 869, 869, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(524, 0, '\'Haldol 10mg 20 Tab\'', '\'QA\'', '\'USD\'', 2.68, 2.68, 2.68, 2.68, 2.68, 2.68, 2.68, 2.68, 2.68, 2.68, 2.68, 2.68, 2.68, 2.68, 2.68, 2.68, 2.68, 2.68, 2.68, 2.68, 2.68, 2.68, 2.68, 2.68, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(525, 0, '\'HALDOL 5MG 1000 TABL. QUELUZ ST.EXP.\'', '\'QA\'', '\'USD\'', 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(526, 0, '\'Imbruvica Tab 140mg\'', '\'QA\'', '\'USD\'', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(527, 0, '\'Imbruvica Tab 280mg\'', '\'QA\'', '\'USD\'', 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(528, 0, '\'Imbruvica Tab 420mg\'', '\'QA\'', '\'USD\'', 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(529, 0, '\'Imbruvica Tab 560mg\'', '\'QA\'', '\'USD\'', 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00');
INSERT INTO `jnj_pricing_dataentry` (`id`, `material`, `SKU`, `countryCode`, `currency`, `cif_jan`, `cif_feb`, `cif_mar`, `cif_apr`, `cif_may`, `cif_jun`, `cif_jul`, `cif_aug`, `cif_sep`, `cif_oct`, `cif_nov`, `cif_dec`, `tnd_jan`, `tnd_feb`, `tnd_mar`, `tnd_apr`, `tnd_may`, `tnd_jun`, `tnd_jul`, `tnd_aug`, `tnd_sep`, `tnd_oct`, `tnd_nov`, `tnd_dec`, `discounts`, `focs`, `totalDiscount`, `month`, `year`, `createDate`, `ModifiedDate`) VALUES
(530, 0, '\'Spravato 2x28mg\'', '\'QA\'', '\'USD\'', 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(531, 0, '\'Spravato 3x28mg\'', '\'QA\'', '\'USD\'', 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(532, 416941, '\'Imbruvica 140mg Capsule \'', '\'SA\'', '\'USD\'', 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(533, 90710, '\'Risperdal 1 mg/ml Oral Solution\'', '\'SA\'', '\'USD\'', 35.99, 35.99, 35.99, 35.99, 35.99, 35.99, 35.99, 35.99, 35.99, 35.99, 35.99, 35.99, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(534, 376635, '\'Risperdal Consta 25 mg Inj.  \'', '\'SA\'', '\'USD\'', 73.96, 73.96, 73.96, 73.96, 73.96, 73.96, 73.96, 73.96, 73.96, 73.96, 73.96, 73.96, 73.96, 73.96, 73.96, 73.96, 73.96, 73.96, 73.96, 73.96, 73.96, 73.96, 73.96, 73.96, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(535, 376661, '\'Risperdal Consta 37.5 mg Inj. \'', '\'SA\'', '\'USD\'', 102.95, 102.95, 102.95, 102.95, 102.95, 102.95, 102.95, 102.95, 102.95, 102.95, 102.95, 102.95, 102.95, 102.95, 102.95, 102.95, 102.95, 102.95, 102.95, 102.95, 102.95, 102.95, 102.95, 102.95, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(536, 387758, '\'Invega Sustenna 50 mg/ 0.5 ml \'', '\'SA\'', '\'USD\'', 186.86, 186.86, 186.86, 186.86, 186.86, 186.86, 186.86, 186.86, 186.86, 186.86, 186.86, 186.86, 186.86, 186.86, 186.86, 186.86, 186.86, 186.86, 186.86, 186.86, 186.86, 186.86, 186.86, 186.86, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(537, 387759, '\'Invega Sustenna 75 mg/ 0.75 ml \'', '\'SA\'', '\'USD\'', 243.86, 243.86, 243.86, 243.86, 243.86, 243.86, 243.86, 243.86, 243.86, 243.86, 243.86, 243.86, 243.86, 243.86, 243.86, 243.86, 243.86, 243.86, 243.86, 243.86, 243.86, 243.86, 243.86, 243.86, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(538, 387760, '\'Invega Sustenna 100 mg/ 1 ml \'', '\'SA\'', '\'USD\'', 298.88, 298.88, 298.88, 298.88, 298.88, 298.88, 298.88, 298.88, 298.88, 298.88, 298.88, 298.88, 298.89, 298.89, 298.89, 298.89, 298.89, 298.89, 298.89, 298.89, 298.89, 298.89, 298.89, 298.89, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(539, 387761, '\'Invega Sustenna 150 mg/ 1.5 ml \'', '\'SA\'', '\'USD\'', 347.74, 347.74, 347.74, 347.74, 347.74, 347.74, 347.74, 347.74, 347.74, 347.74, 347.74, 347.74, 347.74, 347.74, 347.74, 347.74, 347.74, 347.74, 347.74, 347.74, 347.74, 347.74, 347.74, 347.74, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(540, 376688, '\'Risperdal Consta 50 mg Inj.  \'', '\'SA\'', '\'USD\'', 122.95, 122.95, 122.95, 122.95, 122.95, 122.95, 122.95, 122.95, 122.95, 122.95, 122.95, 122.95, 122.95, 122.95, 122.95, 122.95, 122.95, 122.95, 122.95, 122.95, 122.95, 122.95, 122.95, 122.95, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(541, 0, '\'Cilest Tab. 21tab\'', '\'SA\'', '\'USD\'', 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(542, 412675, '\'Simponi 50 mg/ 0.5 ml Injection (PFP)\'', '\'SA\'', '\'USD\'', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 666.67, 666.67, 666.67, 666.67, 666.67, 666.67, 666.67, 666.67, 666.67, 666.67, 666.67, 666.67, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(543, 377568, '\'Concerta 18mg  Extended Release Tab.\'', '\'SA\'', '\'USD\'', 23.54, 23.54, 23.54, 23.54, 23.54, 23.54, 23.54, 23.54, 23.54, 23.54, 23.54, 23.54, 23.54, 23.54, 23.54, 23.54, 23.54, 23.54, 23.54, 23.54, 23.54, 23.54, 23.54, 23.54, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(544, 377567, '\'Concerta 36mg Extended Release Tab.\'', '\'SA\'', '\'USD\'', 32.69, 32.69, 32.69, 32.69, 32.69, 32.69, 32.69, 32.69, 32.69, 32.69, 32.69, 32.69, 32.69, 32.69, 32.69, 32.69, 32.69, 32.69, 32.69, 32.69, 32.69, 32.69, 32.69, 32.69, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(545, 27467, '\'Daktacort Cream                 \'', '\'SA\'', '\'USD\'', 2.31, 2.31, 2.31, 2.31, 2.31, 2.31, 2.31, 2.31, 2.31, 2.31, 2.31, 2.31, 2.31, 2.31, 2.31, 2.31, 2.31, 2.31, 2.31, 2.31, 2.31, 2.31, 2.31, 2.31, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(546, 27463, '\'Daktarin cream 2% 30g\'', '\'SA\'', '\'USD\'', 4.15, 4.15, 1.65, 1.65, 4.15, 4.15, 1.65, 1.65, 4.15, 4.15, 1.65, 1.65, 4.15, 4.15, 1.65, 1.65, 4.15, 4.15, 1.65, 1.65, 4.15, 4.15, 1.65, 1.65, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(547, 32230, '\'Daktarin Oral gel 2%\'', '\'SA\'', '\'USD\'', 3.43, 3.43, 2.7, 2.7, 3.43, 3.43, 2.7, 2.7, 3.43, 3.43, 2.7, 2.7, 2.96, 2.96, 2.7, 2.7, 2.96, 2.96, 2.7, 2.7, 2.96, 2.96, 2.7, 2.7, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(548, 27465, '\'Daktarin powder 2%\'', '\'SA\'', '\'USD\'', 2.92, 2.92, 1.95, 1.95, 2.92, 2.92, 1.95, 1.95, 2.92, 2.92, 1.95, 1.95, 2.92, 2.92, 1.95, 1.95, 2.92, 2.92, 1.95, 1.95, 2.92, 2.92, 1.95, 1.95, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(549, 37226, '\'Daktarin 2% Tincture\'', '\'SA\'', '\'USD\'', 3.7, 3.7, 3.7, 3.7, 3.7, 3.7, 3.7, 3.7, 3.7, 3.7, 3.7, 3.7, 3.7, 3.7, 3.7, 3.7, 3.7, 3.7, 3.7, 3.7, 3.7, 3.7, 3.7, 3.7, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(550, 0, '\'Daktarin Lotion 2% \'', '\'SA\'', '\'USD\'', 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(551, 0, '\'Doribax 500 mg Injection \'', '\'SA\'', '\'USD\'', 179.21, 179.21, 179.21, 179.21, 179.21, 179.21, 179.21, 179.21, 179.21, 179.21, 179.21, 179.21, 179.21, 179.21, 179.21, 179.21, 179.21, 179.21, 179.21, 179.21, 179.21, 179.21, 179.21, 179.21, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(552, 387398, '\'Durogesic Transdermal Patches 12 mcg/h\'', '\'SA\'', '\'USD\'', 17.62, 3.88, 3.88, 3.88, 17.62, 3.88, 3.88, 3.88, 17.62, 3.88, 3.88, 3.88, 17.62, 3.88, 3.88, 3.88, 17.62, 3.88, 3.88, 3.88, 17.62, 3.88, 3.88, 3.88, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(553, 387399, '\'Durogesic Transdermal Patches 25 mcg/h\'', '\'SA\'', '\'USD\'', 31.12, 6.94, 6.94, 6.94, 31.12, 6.94, 6.94, 6.94, 31.12, 6.94, 6.94, 6.94, 31.12, 6.94, 6.94, 6.94, 31.12, 6.94, 6.94, 6.94, 31.12, 6.94, 6.94, 6.94, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(554, 387400, '\'Durogesic Transdermal Patches 50 mcg/h\'', '\'SA\'', '\'USD\'', 54.66, 12.76, 12.76, 12.76, 54.66, 12.76, 12.76, 12.76, 54.66, 12.76, 12.76, 12.76, 54.66, 12.76, 12.76, 12.76, 54.66, 12.76, 12.76, 12.76, 54.66, 12.76, 12.76, 12.76, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(555, 387401, '\'Durogesic Transdermal Patches 75 mcg/h\'', '\'SA\'', '\'USD\'', 80.1, 17.51, 17.51, 17.51, 80.1, 17.51, 17.51, 17.51, 80.1, 17.51, 17.51, 17.51, 80.1, 17.51, 17.51, 17.51, 80.1, 17.51, 17.51, 17.51, 80.1, 17.51, 17.51, 17.51, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(556, 387397, '\'Durogesic Transdermal Patches 100 mcg/h\'', '\'SA\'', '\'USD\'', 98.73, 21.69, 21.69, 21.69, 98.73, 21.69, 21.69, 21.69, 98.73, 21.69, 21.69, 21.69, 98.73, 21.69, 21.69, 21.69, 98.73, 21.69, 21.69, 21.69, 98.73, 21.69, 21.69, 21.69, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(557, 378385, '\'Eprex 1,000 U Pre-Filled Syringes \'', '\'SA\'', '\'USD\'', 28.54, 28.54, 28.54, 28.54, 28.54, 28.54, 28.54, 28.54, 28.54, 28.54, 28.54, 28.54, 28.54, 28.54, 28.54, 28.54, 28.54, 28.54, 28.54, 28.54, 28.54, 28.54, 28.54, 28.54, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(558, 378386, '\'Eprex 2,000 U Pre-Filled Syringes \'', '\'SA\'', '\'USD\'', 59.68, 59.68, 59.68, 59.68, 59.68, 59.68, 59.68, 59.68, 59.68, 59.68, 59.68, 59.68, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(559, 414066, '\'Eprex 3,000 U Pre-Filled Syringes \'', '\'SA\'', '\'USD\'', 89.52, 89.52, 89.52, 89.52, 89.52, 89.52, 89.52, 89.52, 89.52, 89.52, 89.52, 89.52, 89.52, 89.52, 89.52, 89.52, 89.52, 89.52, 89.52, 89.52, 89.52, 89.52, 89.52, 89.52, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(560, 378387, '\'Eprex 4,000 U Pre-Filled Syringes \'', '\'SA\'', '\'USD\'', 119.36, 119.36, 119.36, 119.36, 119.36, 119.36, 119.36, 119.36, 119.36, 119.36, 119.36, 119.36, 67.2, 67.2, 67.2, 67.2, 67.2, 67.2, 67.2, 67.2, 67.2, 67.2, 67.2, 67.2, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(561, 378388, '\'Eprex 10,000 U Pre-Filled Syringes \'', '\'SA\'', '\'USD\'', 298.4, 298.4, 298.4, 298.4, 298.4, 298.4, 298.4, 298.4, 298.4, 298.4, 298.4, 298.4, 205.08, 205.08, 205.08, 205.08, 205.08, 205.08, 205.08, 205.08, 205.08, 205.08, 205.08, 205.08, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(562, 378389, '\'Eprex 40,000 U Pre-Filled Syringe \'', '\'SA\'', '\'USD\'', 198.93, 198.93, 198.93, 198.93, 198.93, 198.93, 198.93, 198.93, 198.93, 198.93, 198.93, 198.93, 198.93, 198.93, 198.93, 198.93, 198.93, 198.93, 198.93, 198.93, 198.93, 198.93, 198.93, 198.93, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(563, 191330, '\'Eprex New Stabilizer 4000 IU/ml Vial\'', '\'SA\'', '\'USD\'', 119.36, 119.36, 119.36, 119.36, 119.36, 119.36, 119.36, 119.36, 119.36, 119.36, 119.36, 119.36, 67.2, 67.2, 67.2, 67.2, 67.2, 67.2, 67.2, 67.2, 67.2, 67.2, 67.2, 67.2, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(564, 378389, '\'Eprex 40,000 IU/ml Vial\'', '\'SA\'', '\'USD\'', 198.93, 198.93, 198.93, 198.93, 198.93, 198.93, 198.93, 198.93, 198.93, 198.93, 198.93, 198.93, 198.93, 198.93, 198.93, 198.93, 198.93, 198.93, 198.93, 198.93, 198.93, 198.93, 198.93, 198.93, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(565, 377735, '\'Evra Transdermal Patches\'', '\'SA\'', '\'USD\'', 4.67, 4.67, 4.67, 4.67, 4.67, 4.67, 4.67, 4.67, 4.67, 4.67, 4.67, 4.67, 4.67, 4.67, 4.67, 4.67, 4.67, 4.67, 4.67, 4.67, 4.67, 4.67, 4.67, 4.67, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(566, 0, '\'Fentanyl 0.05 mg/ml Inj. 2ml x 5 amps\'', '\'SA\'', '\'USD\'', 2.05, 0.8, 0.8, 0.8, 2.05, 0.8, 0.8, 0.8, 2.05, 0.8, 0.8, 0.8, 2.05, 0.8, 0.8, 0.8, 2.05, 0.8, 0.8, 0.8, 2.05, 0.8, 0.8, 0.8, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(567, 412117, '\'Fentanyl 0.05 mg/ml Inj. 2ml x 50 amps\'', '\'SA\'', '\'USD\'', 19.76, 8.02, 8.02, 8.02, 19.76, 8.02, 8.02, 8.02, 19.76, 8.02, 8.02, 8.02, 19.73, 8.02, 8.02, 8.02, 19.73, 8.02, 8.02, 8.02, 19.73, 8.02, 8.02, 8.02, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(568, 0, '\'Fentanyl 0.05 mg/ml Inj. 10ml x 5 amps\'', '\'SA\'', '\'USD\'', 9.59, 1.97, 1.97, 1.97, 9.59, 1.97, 1.97, 1.97, 9.59, 1.97, 1.97, 1.97, 9.59, 1.97, 1.97, 1.97, 9.59, 1.97, 1.97, 1.97, 9.59, 1.97, 1.97, 1.97, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(569, 412115, '\'Fentanyl 0.05 mg/ml Inj. 10ml x 50 amps\'', '\'SA\'', '\'USD\'', 40.53, 31.63, 31.63, 31.63, 40.53, 31.63, 31.63, 31.63, 40.53, 31.63, 31.63, 31.63, 40.53, 31.63, 31.63, 31.63, 40.53, 31.63, 31.63, 31.63, 40.53, 31.63, 31.63, 31.63, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(570, 32388, '\'Gyno-Daktarin V. Cream \'', '\'SA\'', '\'USD\'', 6.31, 5.46, 5.46, 5.46, 6.31, 5.46, 5.46, 5.46, 6.31, 5.46, 5.46, 5.46, 6.31, 5.46, 5.46, 5.46, 6.31, 5.46, 5.46, 5.46, 6.31, 5.46, 5.46, 5.46, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(571, 37228, '\'Gyno Daktarin 400 mg V. Capsules\'', '\'SA\'', '\'USD\'', 3.94, 3.47, 3.47, 3.47, 3.94, 3.47, 3.47, 3.47, 3.94, 3.47, 3.47, 3.47, 3.94, 3.47, 3.47, 3.47, 3.94, 3.47, 3.47, 3.47, 3.94, 3.47, 3.47, 3.47, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(572, 72223, '\'Gyno Daktarin 1200 mg V. Capsule\'', '\'SA\'', '\'USD\'', 3.1, 3.1, 3.1, 3.1, 3.1, 3.1, 3.1, 3.1, 3.1, 3.1, 3.1, 3.1, 3.1, 3.1, 3.1, 3.1, 3.1, 3.1, 3.1, 3.1, 3.1, 3.1, 3.1, 3.1, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(573, 0, '\'Gyno-Pevaryl-50 Vag. Supp. 50mg\'', '\'SA\'', '\'USD\'', 8.03, 8.03, 8.03, 8.03, 8.03, 8.03, 8.03, 8.03, 8.03, 8.03, 8.03, 8.03, 8.03, 8.03, 8.03, 8.03, 8.03, 8.03, 8.03, 8.03, 8.03, 8.03, 8.03, 8.03, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(574, 191386, '\'Gyno Pevaryl 150 mg V. Suppositories\'', '\'SA\'', '\'USD\'', 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(575, 412129, '\'Haldol Amp. 5mg/ml\'', '\'SA\'', '\'USD\'', 4.47, 1.05, 1.05, 1.05, 4.47, 1.05, 1.05, 1.05, 4.47, 1.05, 1.05, 1.05, 4.47, 1.05, 1.05, 1.05, 4.47, 1.05, 1.05, 1.05, 4.47, 1.05, 1.05, 1.05, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(576, 412130, '\'Haldol Decanoas Inj. 50mg/ml\'', '\'SA\'', '\'USD\'', 4.22, 1.72, 1.72, 1.72, 4.22, 1.72, 1.72, 1.72, 4.22, 1.72, 1.72, 1.72, 4.22, 1.72, 1.72, 1.72, 4.22, 1.72, 1.72, 1.72, 4.22, 1.72, 1.72, 1.72, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(577, 412132, '\'Haldol Deconoas Inj. 100mg/ml\'', '\'SA\'', '\'USD\'', 7.99, 4.54, 4.54, 4.54, 7.99, 4.54, 4.54, 4.54, 7.99, 4.54, 4.54, 4.54, 7.99, 4.54, 4.54, 4.54, 7.99, 4.54, 4.54, 4.54, 7.99, 4.54, 4.54, 4.54, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(578, 33027, '\'Haldol Oral Drops 2mg/ml\'', '\'SA\'', '\'USD\'', 2.21, 0.68, 0.68, 0.68, 2.21, 0.68, 0.68, 0.68, 2.21, 0.68, 0.68, 0.68, 2.21, 0.68, 0.68, 0.68, 2.21, 0.68, 0.68, 0.68, 2.21, 0.68, 0.68, 0.68, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(579, 52049, '\'Haldol 5mg tab\'', '\'SA\'', '\'USD\'', 3.82, 1.25, 1.25, 1.25, 3.82, 1.25, 1.25, 1.25, 3.82, 1.25, 1.25, 1.25, 3.82, 1.25, 1.25, 1.25, 3.82, 1.25, 1.25, 1.25, 3.82, 1.25, 1.25, 1.25, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(580, 0, '\'Imodium cap 2mg\'', '\'SA\'', '\'USD\'', 1.25, 1.25, 1.25, 1.25, 1.25, 1.25, 1.25, 1.25, 1.25, 1.25, 1.25, 1.25, 1.25, 1.25, 1.25, 1.25, 1.25, 1.25, 1.25, 1.25, 1.25, 1.25, 1.25, 1.25, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(581, 378218, '\'Intelence 100 mg Tab.\'', '\'SA\'', '\'USD\'', 491.87, 491.87, 341.98, 341.98, 491.87, 491.87, 341.98, 341.98, 491.87, 491.87, 341.98, 341.98, 491.87, 491.87, 341.98, 341.98, 491.87, 491.87, 341.98, 341.98, 491.87, 491.87, 341.98, 341.98, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(582, 0, '\'Incivo 375 mg Film-Coated Tabs.\'', '\'SA\'', '\'USD\'', 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(583, 0, '\'Livostin eye drops 0.5mg/ml\'', '\'SA\'', '\'USD\'', 6.95, 6.95, 6.95, 6.95, 6.95, 6.95, 6.95, 6.95, 6.95, 6.95, 6.95, 6.95, 6.95, 6.95, 6.95, 6.95, 6.95, 6.95, 6.95, 6.95, 6.95, 6.95, 6.95, 6.95, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(584, 0, '\'Livostin nasal spray 0.5mg/ml\'', '\'SA\'', '\'USD\'', 6.5, 6.5, 6.5, 6.5, 6.5, 6.5, 6.5, 6.5, 6.5, 6.5, 6.5, 6.5, 6.5, 6.5, 6.5, 6.5, 6.5, 6.5, 6.5, 6.5, 6.5, 6.5, 6.5, 6.5, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(585, 0, '\'Motilium supp. 10 mg for Infant\'', '\'SA\'', '\'USD\'', 2.18, 2.18, 2.18, 2.18, 2.18, 2.18, 2.18, 2.18, 2.18, 2.18, 2.18, 2.18, 2.18, 2.18, 2.18, 2.18, 2.18, 2.18, 2.18, 2.18, 2.18, 2.18, 2.18, 2.18, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(586, 0, '\'Motilium supp. 30 mg for Child.\'', '\'SA\'', '\'USD\'', 2.81, 2.81, 2.81, 2.81, 2.81, 2.81, 2.81, 2.81, 2.81, 2.81, 2.81, 2.81, 2.81, 2.81, 2.81, 2.81, 2.81, 2.81, 2.81, 2.81, 2.81, 2.81, 2.81, 2.81, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(587, 0, '\'Motilium supp. 60 mg for Adult\'', '\'SA\'', '\'USD\'', 4.2, 4.2, 4.2, 4.2, 4.2, 4.2, 4.2, 4.2, 4.2, 4.2, 4.2, 4.2, 4.2, 4.2, 4.2, 4.2, 4.2, 4.2, 4.2, 4.2, 4.2, 4.2, 4.2, 4.2, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(588, 27480, '\'Motilium 1 mg/ml Oral Suspension 200ml\'', '\'SA\'', '\'USD\'', 3.2, 3.2, 3.2, 3.2, 3.2, 3.2, 3.2, 3.2, 3.2, 3.2, 3.2, 3.2, 3.2, 3.2, 3.2, 3.2, 3.2, 3.2, 3.2, 3.2, 3.2, 3.2, 3.2, 3.2, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(589, 27478, '\'Motilium 10 mg Tab. 30s\'', '\'SA\'', '\'USD\'', 3.3, 3.3, 1.38, 1.38, 3.3, 3.3, 1.38, 1.38, 3.3, 3.3, 1.38, 1.38, 2.66, 2.66, 1.38, 1.38, 2.66, 2.66, 1.38, 1.38, 2.66, 2.66, 1.38, 1.38, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(590, 60202, '\'Nizoral Cream 2 %\'', '\'SA\'', '\'USD\'', 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(591, 0, '\'Nizoral shampoo 2%\'', '\'SA\'', '\'USD\'', 5.91, 5.91, 5.91, 5.91, 5.91, 5.91, 5.91, 5.91, 5.91, 5.91, 5.91, 5.91, 5.91, 5.91, 5.91, 5.91, 5.91, 5.91, 5.91, 5.91, 5.91, 5.91, 5.91, 5.91, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(592, 416303, '\'Olysio 150 mg capsules\'', '\'SA\'', '\'USD\'', 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 444.5, 444.5, 444.5, 444.5, 444.5, 444.5, 444.5, 444.5, 444.5, 444.5, 444.5, 444.5, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(593, 0, '\'Orap Forte Tab. 4mg\'', '\'SA\'', '\'USD\'', 3.85, 3.85, 3.85, 3.85, 3.85, 3.85, 3.85, 3.85, 3.85, 3.85, 3.85, 3.85, 3.85, 3.85, 3.85, 3.85, 3.85, 3.85, 3.85, 3.85, 3.85, 3.85, 3.85, 3.85, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(594, 377358, '\'Pariet 10 mg Tab. 14s\'', '\'SA\'', '\'USD\'', 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(595, 377359, '\'Pariet 20 mg Tab. 14s\'', '\'SA\'', '\'USD\'', 3.81, 3.81, 3.81, 3.81, 3.81, 3.81, 3.81, 3.81, 3.81, 3.81, 3.81, 3.81, 3.81, 3.81, 3.81, 3.81, 3.81, 3.81, 3.81, 3.81, 3.81, 3.81, 3.81, 3.81, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(596, 0, '\'Pevisone Cream \'', '\'SA\'', '\'USD\'', 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(597, 0, '\'Pevaryl Spray Powder 1%\'', '\'SA\'', '\'USD\'', 5.17, 5.17, 5.17, 5.17, 5.17, 5.17, 5.17, 5.17, 5.17, 5.17, 5.17, 5.17, 5.17, 5.17, 5.17, 5.17, 5.17, 5.17, 5.17, 5.17, 5.17, 5.17, 5.17, 5.17, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(598, 412124, '\'Rapifen Amp 500mcg/ml 2ml x 5 amp\'', '\'SA\'', '\'USD\'', 3.76, 3.76, 1.43, 1.43, 3.76, 3.76, 1.43, 1.43, 3.76, 3.76, 1.43, 1.43, 3.76, 3.76, 1.43, 1.43, 3.76, 3.76, 1.43, 1.43, 3.76, 3.76, 1.43, 1.43, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(599, 412126, '\'Rapifen Amp 500mcg/ml 10ml x 5 amp\'', '\'SA\'', '\'USD\'', 17.49, 17.49, 14.6, 14.6, 17.49, 17.49, 14.6, 14.6, 17.49, 17.49, 14.6, 14.6, 17.49, 17.49, 14.6, 14.6, 17.49, 17.49, 14.6, 14.6, 17.49, 17.49, 14.6, 14.6, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(600, 412557, '\'Remicade 100 mg \'', '\'SA\'', '\'USD\'', 363.63, 363.63, 363.63, 363.63, 363.63, 363.63, 363.63, 363.63, 363.63, 363.63, 363.63, 363.63, 204, 204, 204, 204, 204, 204, 204, 204, 204, 204, 204, 204, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(601, 377010, '\'Reminyl 4 mg Tab.\'', '\'SA\'', '\'USD\'', 13.41, 13.41, 5.6, 5.6, 13.41, 13.41, 5.6, 5.6, 13.41, 13.41, 5.6, 5.6, 13.41, 13.41, 5.6, 5.6, 13.41, 13.41, 5.6, 5.6, 13.41, 13.41, 5.6, 5.6, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(602, 377006, '\'Reminyl 8 mg Tab.\'', '\'SA\'', '\'USD\'', 69.66, 69.66, 19.27, 19.27, 69.66, 69.66, 19.27, 19.27, 69.66, 69.66, 19.27, 19.27, 69.66, 69.66, 19.27, 19.27, 69.66, 69.66, 19.27, 19.27, 69.66, 69.66, 19.27, 19.27, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(603, 418012, '\'Reminyl 12 mg 56 Tablets\'', '\'SA\'', '\'USD\'', 83.38, 83.38, 31, 31, 83.38, 83.38, 31, 31, 83.38, 83.38, 31, 31, 83.38, 83.38, 31, 31, 83.38, 83.38, 31, 31, 83.38, 83.38, 31, 31, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(604, 418014, '\'Reminyl 4 mg/ml Oral Solution  \'', '\'SA\'', '\'USD\'', 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(605, 0, '\'Reminyl PR 8 mg 28 Capsule\'', '\'SA\'', '\'USD\'', 50.75, 50.75, 50.75, 50.75, 50.75, 50.75, 50.75, 50.75, 50.75, 50.75, 50.75, 50.75, 50.75, 50.75, 50.75, 50.75, 50.75, 50.75, 50.75, 50.75, 50.75, 50.75, 50.75, 50.75, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(606, 377057, '\'Reminyl PR 16 mg 28 Capsule\'', '\'SA\'', '\'USD\'', 75.06, 75.06, 75.06, 75.06, 75.06, 75.06, 75.06, 75.06, 75.06, 75.06, 75.06, 75.06, 75.06, 75.06, 75.06, 75.06, 75.06, 75.06, 75.06, 75.06, 75.06, 75.06, 75.06, 75.06, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(607, 377058, '\'Reminyl PR 24 mg 28 Capsule\'', '\'SA\'', '\'USD\'', 97.7, 97.7, 97.7, 97.7, 97.7, 97.7, 97.7, 97.7, 97.7, 97.7, 97.7, 97.7, 97.7, 97.7, 97.7, 97.7, 97.7, 97.7, 97.7, 97.7, 97.7, 97.7, 97.7, 97.7, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(608, 0, '\'Sibelium caps 5mg\'', '\'SA\'', '\'USD\'', 3.33, 3.33, 3.33, 3.33, 3.33, 3.33, 3.33, 3.33, 3.33, 3.33, 3.33, 3.33, 3.33, 3.33, 3.33, 3.33, 3.33, 3.33, 3.33, 3.33, 3.33, 3.33, 3.33, 3.33, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(609, 63067, '\'Sporanox 100 mg Cap. 4s\'', '\'SA\'', '\'USD\'', 1.85, 1.85, 1.85, 1.85, 1.85, 1.85, 1.85, 1.85, 1.85, 1.85, 1.85, 1.85, 1.85, 1.85, 1.85, 1.85, 1.85, 1.85, 1.85, 1.85, 1.85, 1.85, 1.85, 1.85, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(610, 63068, '\'Sporanox 100 mg Cap. 15s\'', '\'SA\'', '\'USD\'', 6.94, 6.94, 6.94, 6.94, 6.94, 6.94, 6.94, 6.94, 6.94, 6.94, 6.94, 6.94, 6.94, 6.94, 6.94, 6.94, 6.94, 6.94, 6.94, 6.94, 6.94, 6.94, 6.94, 6.94, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(611, 27484, '\'Stugeron 25 mg Tab.\'', '\'SA\'', '\'USD\'', 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(612, 412119, '\'Sufenta Ampoule 5 mcg/ml 2ml x 5 amp\'', '\'SA\'', '\'USD\'', 3.64, 1.25, 1.25, 1.25, 3.64, 1.25, 1.25, 1.25, 3.64, 1.25, 1.25, 1.25, 3.64, 1.25, 1.25, 1.25, 3.64, 1.25, 1.25, 1.25, 3.64, 1.25, 1.25, 1.25, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(613, 412122, '\'Sufenta Ampoule 5 mcg/ml 10ml x 5 amp\'', '\'SA\'', '\'USD\'', 14.06, 5.05, 5.05, 5.05, 14.06, 5.05, 5.05, 5.05, 14.06, 5.05, 5.05, 5.05, 14.06, 5.05, 5.05, 5.05, 14.06, 5.05, 5.05, 5.05, 14.06, 5.05, 5.05, 5.05, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(614, 412120, '\'Sufenta Forte Amp 50 mcg/ml 5ml x 5 amp\'', '\'SA\'', '\'USD\'', 40.4, 29.65, 29.65, 29.65, 40.4, 29.65, 29.65, 29.65, 40.4, 29.65, 29.65, 29.65, 40.4, 29.65, 29.65, 29.65, 40.4, 29.65, 29.65, 29.65, 40.4, 29.65, 29.65, 29.65, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(615, 140300, '\'Topamax 25 mg Tab.\'', '\'SA\'', '\'USD\'', 6.4, 6.4, 6.4, 6.4, 6.4, 6.4, 6.4, 6.4, 6.4, 6.4, 6.4, 6.4, 6.4, 6.4, 6.4, 6.4, 6.4, 6.4, 6.4, 6.4, 6.4, 6.4, 6.4, 6.4, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(616, 140301, '\'Topamax 100 mg Tab.\'', '\'SA\'', '\'USD\'', 25.83, 25.83, 25.83, 25.83, 25.83, 25.83, 25.83, 25.83, 25.83, 25.83, 25.83, 25.83, 25.83, 25.83, 25.83, 25.83, 25.83, 25.83, 25.83, 25.83, 25.83, 25.83, 25.83, 25.83, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(617, 387648, '\'Topamax 200 mg Tab.\'', '\'SA\'', '\'USD\'', 46.69, 46.69, 46.69, 46.69, 46.69, 46.69, 46.69, 46.69, 46.69, 46.69, 46.69, 46.69, 46.69, 46.69, 46.69, 46.69, 46.69, 46.69, 46.69, 46.69, 46.69, 46.69, 46.69, 46.69, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(618, 141023, '\'Topamax 15 mg Sprinkle Cap.\'', '\'SA\'', '\'USD\'', 7.21, 7.21, 7.21, 7.21, 7.21, 7.21, 7.21, 7.21, 7.21, 7.21, 7.21, 7.21, 7.21, 7.21, 7.21, 7.21, 7.21, 7.21, 7.21, 7.21, 7.21, 7.21, 7.21, 7.21, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(619, 412303, '\'Topamax 25 mg Sprinkle Cap.\'', '\'SA\'', '\'USD\'', 7.96, 7.96, 7.96, 7.96, 7.96, 7.96, 7.96, 7.96, 7.96, 7.96, 7.96, 7.96, 7.96, 7.96, 7.96, 7.96, 7.96, 7.96, 7.96, 7.96, 7.96, 7.96, 7.96, 7.96, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(620, 387647, '\'Topamax 50 mg Sprinkle Cap.\'', '\'SA\'', '\'USD\'', 12.95, 12.95, 12.95, 12.95, 12.95, 12.95, 12.95, 12.95, 12.95, 12.95, 12.95, 12.95, 12.95, 12.95, 12.95, 12.95, 12.95, 12.95, 12.95, 12.95, 12.95, 12.95, 12.95, 12.95, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(621, 0, '\'Tylenol Forte Tab. 500mg \'', '\'SA\'', '\'USD\'', 1.46, 1.46, 1.46, 1.46, 1.46, 1.46, 1.46, 1.46, 1.46, 1.46, 1.46, 1.46, 1.46, 1.46, 1.46, 1.46, 1.46, 1.46, 1.46, 1.46, 1.46, 1.46, 1.46, 1.46, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(622, 0, '\'Tylenol supp. 100 mg\'', '\'SA\'', '\'USD\'', 1.96, 1.96, 1.96, 1.96, 1.96, 1.96, 1.96, 1.96, 1.96, 1.96, 1.96, 1.96, 1.96, 1.96, 1.96, 1.96, 1.96, 1.96, 1.96, 1.96, 1.96, 1.96, 1.96, 1.96, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(623, 0, '\'Tylenol supp. 200 mg\'', '\'SA\'', '\'USD\'', 2.21, 2.21, 2.21, 2.21, 2.21, 2.21, 2.21, 2.21, 2.21, 2.21, 2.21, 2.21, 2.21, 2.21, 2.21, 2.21, 2.21, 2.21, 2.21, 2.21, 2.21, 2.21, 2.21, 2.21, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(624, 0, '\'Tylenol supp. 350 mg\'', '\'SA\'', '\'USD\'', 2.5, 2.5, 2.5, 2.5, 2.5, 2.5, 2.5, 2.5, 2.5, 2.5, 2.5, 2.5, 2.5, 2.5, 2.5, 2.5, 2.5, 2.5, 2.5, 2.5, 2.5, 2.5, 2.5, 2.5, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(625, 377738, '\'Velcade Injection 3.5 mg\'', '\'SA\'', '\'USD\'', 872.72, 872.72, 872.72, 872.72, 872.72, 872.72, 872.72, 872.72, 872.72, 872.72, 872.72, 872.72, 740, 740, 740, 740, 740, 740, 740, 740, 740, 740, 740, 740, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(626, 27490, '\'Vermox 20 mg/ml Oral Susp.\'', '\'SA\'', '\'USD\'', 2.37, 2.37, 2.37, 2.37, 2.37, 2.37, 2.37, 2.37, 2.37, 2.37, 2.37, 2.37, 2.37, 2.37, 2.37, 2.37, 2.37, 2.37, 2.37, 2.37, 2.37, 2.37, 2.37, 2.37, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(627, 27488, '\'Vermox 100 mg Tab. 6s\'', '\'SA\'', '\'USD\'', 1.84, 1.84, 1.84, 1.84, 1.84, 1.84, 1.84, 1.84, 1.84, 1.84, 1.84, 1.84, 1.84, 1.84, 1.84, 1.84, 1.84, 1.84, 1.84, 1.84, 1.84, 1.84, 1.84, 1.84, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(628, 385589, '\'Yondelis 1 mg Injection \'', '\'SA\'', '\'USD\'', 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(629, 387104, '\'Prezista 400 mg Tablets\'', '\'SA\'', '\'USD\'', 402.77, 402.77, 402.77, 109.8, 402.77, 402.77, 402.77, 109.8, 402.77, 402.77, 402.77, 109.8, 402.77, 402.77, 402.77, 109.8, 402.77, 402.77, 402.77, 109.8, 402.77, 402.77, 402.77, 109.8, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(630, 387107, '\'Prezista 600 mg Tablets\'', '\'SA\'', '\'USD\'', 615.22, 615.22, 615.22, 156.1, 615.22, 615.22, 615.22, 156.1, 615.22, 615.22, 615.22, 156.1, 615.22, 615.22, 615.22, 156.1, 615.22, 615.22, 615.22, 156.1, 615.22, 615.22, 615.22, 156.1, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(631, 387284, '\'Invega 3 mg Extended Release Tab. \'', '\'SA\'', '\'USD\'', 88.12, 88.12, 41.39, 41.39, 88.12, 88.12, 41.39, 41.39, 88.12, 88.12, 41.39, 41.39, 88.12, 88.12, 41.39, 41.39, 88.12, 88.12, 41.39, 41.39, 88.12, 88.12, 41.39, 41.39, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(632, 387285, '\'Invega 6 mg Extended Release Tab. \'', '\'SA\'', '\'USD\'', 88.12, 88.12, 48.8, 48.8, 88.12, 88.12, 48.8, 48.8, 88.12, 88.12, 48.8, 48.8, 88.12, 88.12, 48.8, 48.8, 88.12, 88.12, 48.8, 48.8, 88.12, 88.12, 48.8, 48.8, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(633, 387286, '\'Invega 9 mg Extended Release Tab. \'', '\'SA\'', '\'USD\'', 95.51, 95.51, 87.4, 87.4, 95.51, 95.51, 87.4, 87.4, 95.51, 95.51, 87.4, 87.4, 95.51, 95.51, 87.4, 87.4, 95.51, 95.51, 87.4, 87.4, 95.51, 95.51, 87.4, 87.4, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(634, 88845, '\'Risperdal 1mg Tab. 6s\'', '\'SA\'', '\'USD\'', 1.5, 1.5, 1.5, 1.5, 1.5, 1.5, 1.5, 1.5, 1.5, 1.5, 1.5, 1.5, 1.5, 1.5, 1.5, 1.5, 1.5, 1.5, 1.5, 1.5, 1.5, 1.5, 1.5, 1.5, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(635, 88846, '\'Risperdal 2mg Tab. 20s\'', '\'SA\'', '\'USD\'', 2.56, 2.56, 2.56, 2.56, 2.56, 2.56, 2.56, 2.56, 2.56, 2.56, 2.56, 2.56, 2.56, 2.56, 2.56, 2.56, 2.56, 2.56, 2.56, 2.56, 2.56, 2.56, 2.56, 2.56, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(636, 88847, '\'Risperdal 2mg Tab. 60s\'', '\'SA\'', '\'USD\'', 7.68, 7.68, 7.68, 7.68, 7.68, 7.68, 7.68, 7.68, 7.68, 7.68, 7.68, 7.68, 7.68, 7.68, 7.68, 7.68, 7.68, 7.68, 7.68, 7.68, 7.68, 7.68, 7.68, 7.68, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(637, 0, '\'Risperdal 3mg Tab. 20s\'', '\'SA\'', '\'USD\'', 3.74, 3.74, 3.74, 3.74, 3.74, 3.74, 3.74, 3.74, 3.74, 3.74, 3.74, 3.74, 3.74, 3.74, 3.74, 3.74, 3.74, 3.74, 3.74, 3.74, 3.74, 3.74, 3.74, 3.74, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(638, 0, '\'Risperdal 3mg Tab. 60s\'', '\'SA\'', '\'USD\'', 11.23, 11.23, 11.23, 11.23, 11.23, 11.23, 11.23, 11.23, 11.23, 11.23, 11.23, 11.23, 11.23, 11.23, 11.23, 11.23, 11.23, 11.23, 11.23, 11.23, 11.23, 11.23, 11.23, 11.23, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(639, 88851, '\'Risperdal 4mg Tab. 20s\'', '\'SA\'', '\'USD\'', 4.15, 4.15, 4.15, 4.15, 4.15, 4.15, 4.15, 4.15, 4.15, 4.15, 4.15, 4.15, 4.15, 4.15, 4.15, 4.15, 4.15, 4.15, 4.15, 4.15, 4.15, 4.15, 4.15, 4.15, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(640, 88851, '\'Risperdal 4mg Tab. 60s\'', '\'SA\'', '\'USD\'', 12.45, 12.45, 12.45, 12.45, 12.45, 12.45, 12.45, 12.45, 12.45, 12.45, 12.45, 12.45, 12.45, 12.45, 12.45, 12.45, 12.45, 12.45, 12.45, 12.45, 12.45, 12.45, 12.45, 12.45, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(641, 414529, '\'Stelara 45mg/0.5ml \'', '\'SA\'', '\'USD\'', 3, 3, 3, 1, 3, 3, 3, 1, 3, 3, 3, 1, 2, 2, 2, 1, 2, 2, 2, 1, 2, 2, 2, 1, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(642, 414530, '\'Stelara 90mg/1ml\'', '\'SA\'', '\'USD\'', 3, 3, 3, 1, 3, 3, 3, 1, 3, 3, 3, 1, 2, 2, 2, 1, 2, 2, 2, 1, 2, 2, 2, 1, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(643, 414122, '\'Zytiga 250 mg Tabs\'', '\'SA\'', '\'USD\'', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(644, 414922, '\'Invokana 300mg\'', '\'SA\'', '\'USD\'', 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(645, 416021, '\'Simponi 100mg PFP\'', '\'SA\'', '\'USD\'', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 900, 900, 900, 900, 900, 900, 900, 900, 900, 900, 900, 900, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(646, 0, '\'Zytiga 500 mg Tabs\'', '\'SA\'', '\'USD\'', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(647, 415065, '\'Rezolsta\'', '\'SA\'', '\'USD\'', 463, 463, 463, 463, 463, 463, 463, 463, 463, 463, 463, 463, 463, 463, 463, 463, 463, 463, 463, 463, 463, 463, 463, 463, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(648, 415169, '\'Darzalex 400mg\'', '\'SA\'', '\'USD\'', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(649, 418626, '\'Trevicta 175mg (50mg eq.)\'', '\'SA\'', '\'USD\'', 457.81, 457.81, 457.81, 457.81, 457.81, 457.81, 457.81, 457.81, 457.81, 457.81, 457.81, 457.81, 457.81, 457.81, 457.81, 457.81, 457.81, 457.81, 457.81, 457.81, 457.81, 457.81, 457.81, 457.81, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(650, 418624, '\'Trevicta 263mg (75mg eq.) \'', '\'SA\'', '\'USD\'', 564.47, 564.47, 564.47, 564.47, 564.47, 564.47, 564.47, 564.47, 564.47, 564.47, 564.47, 564.47, 564.47, 564.47, 564.47, 564.47, 564.47, 564.47, 564.47, 564.47, 564.47, 564.47, 564.47, 564.47, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(651, 418623, '\'Trevicta 360mg (100mg eq.) \'', '\'SA\'', '\'USD\'', 637.99, 637.99, 637.99, 637.99, 637.99, 637.99, 637.99, 637.99, 637.99, 637.99, 637.99, 637.99, 637.99, 637.99, 637.99, 637.99, 637.99, 637.99, 637.99, 637.99, 637.99, 637.99, 637.99, 637.99, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(652, 418621, '\'Trevicta 525mg (150mg eq.) \'', '\'SA\'', '\'USD\'', 784.53, 784.53, 784.53, 784.53, 784.53, 784.53, 784.53, 784.53, 784.53, 784.53, 784.53, 784.53, 784.53, 784.53, 784.53, 784.53, 784.53, 784.53, 784.53, 784.53, 784.53, 784.53, 784.53, 784.53, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(653, 414434, '\'Caelyx 2 mg/ml\'', '\'SA\'', '\'USD\'', 563.2, 563.2, 563.2, 563.2, 563.2, 563.2, 563.2, 563.2, 563.2, 563.2, 563.2, 563.2, 563.2, 563.2, 563.2, 563.2, 563.2, 563.2, 563.2, 563.2, 563.2, 563.2, 563.2, 563.2, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(654, 377907, '\'DACOGEN IV 1X50MG VIAL\'', '\'SA\'', '\'USD\'', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(655, 88836, '\'Daktarin Cream 2% 15g\'', '\'SA\'', '\'USD\'', 1.35, 1.35, 1.35, 1.35, 1.35, 1.35, 1.35, 1.35, 1.35, 1.35, 1.35, 1.35, 1.35, 1.35, 1.35, 1.35, 1.35, 1.35, 1.35, 1.35, 1.35, 1.35, 1.35, 1.35, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(656, 96875, '\'HALDOL 5MG 1000 TABLETS\'', '\'SA\'', '\'USD\'', 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(657, 387907, '\'Jurnista 8mg Tablet \'', '\'SA\'', '\'USD\'', 32.73, 32.73, 32.73, 32.73, 32.73, 32.73, 32.73, 32.73, 32.73, 32.73, 32.73, 32.73, 32.73, 32.73, 32.73, 32.73, 32.73, 32.73, 32.73, 32.73, 32.73, 32.73, 32.73, 32.73, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(658, 387903, '\'Jurnista 16mg Tablet \'', '\'SA\'', '\'USD\'', 54.09, 54.09, 54.09, 54.09, 54.09, 54.09, 54.09, 54.09, 54.09, 54.09, 54.09, 54.09, 54.09, 54.09, 54.09, 54.09, 54.09, 54.09, 54.09, 54.09, 54.09, 54.09, 54.09, 54.09, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(659, 387904, '\'Jurnista 32mg Tablet \'', '\'SA\'', '\'USD\'', 99.84, 99.84, 99.84, 99.84, 99.84, 99.84, 99.84, 99.84, 99.84, 99.84, 99.84, 99.84, 99.84, 99.84, 99.84, 99.84, 99.84, 99.84, 99.84, 99.84, 99.84, 99.84, 99.84, 99.84, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(660, 387903, '\'Jurnista 64mg Tablet \'', '\'SA\'', '\'USD\'', 175.96, 175.96, 175.96, 175.96, 175.96, 175.96, 175.96, 175.96, 175.96, 175.96, 175.96, 175.96, 175.96, 175.96, 175.96, 175.96, 175.96, 175.96, 175.96, 175.96, 175.96, 175.96, 175.96, 175.96, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(661, 412855, '\'LEUSTATIN 1MG/ML 7X10ML VIAL\'', '\'SA\'', '\'USD\'', 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(662, 412041, '\'Resolor 2 mg Film-Coated Tabs.\'', '\'SA\'', '\'USD\'', 60.99, 60.99, 43.29, 43.29, 60.99, 60.99, 43.29, 43.29, 60.99, 60.99, 43.29, 43.29, 60.99, 60.99, 43.29, 43.29, 60.99, 60.99, 43.29, 43.29, 60.99, 60.99, 43.29, 43.29, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(663, 414050, '\'Resolor 1 mg Film-Coated Tabs.\'', '\'SA\'', '\'USD\'', 37.93, 37.93, 26.33, 26.33, 37.93, 37.93, 26.33, 26.33, 37.93, 37.93, 26.33, 26.33, 37.93, 37.93, 26.33, 26.33, 37.93, 37.93, 26.33, 26.33, 37.93, 37.93, 26.33, 26.33, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(664, 412519, '\'Sporanox IV\'', '\'SA\'', '\'USD\'', 118.8, 118.8, 118.8, 118.8, 118.8, 118.8, 118.8, 118.8, 118.8, 118.8, 118.8, 118.8, 118.8, 118.8, 118.8, 118.8, 118.8, 118.8, 118.8, 118.8, 118.8, 118.8, 118.8, 118.8, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(665, 96041, '\'Haldol 10mg 20 Tab\'', '\'SA\'', '\'USD\'', 2.66, 2.66, 2.66, 2.66, 2.66, 2.66, 2.66, 2.66, 2.66, 2.66, 2.66, 2.66, 2.66, 2.66, 2.66, 2.66, 2.66, 2.66, 2.66, 2.66, 2.66, 2.66, 2.66, 2.66, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(666, 141019, '\'Topamax 50 mg Tab.\'', '\'SA\'', '\'USD\'', 60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(667, 415168, '\'Darzalex 100mg\'', '\'SA\'', '\'USD\'', 449.75, 449.75, 449.75, 449.75, 449.75, 449.75, 449.75, 449.75, 449.75, 449.75, 449.75, 449.75, 449.75, 449.75, 449.75, 449.75, 449.75, 449.75, 449.75, 449.75, 449.75, 449.75, 449.75, 449.75, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(668, 414921, '\'Invokana 100mg \'', '\'SA\'', '\'USD\'', 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 33.52, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(669, 0, '\'Guselkumab\'', '\'SA\'', '\'USD\'', 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(670, 0, '\'Stelara 130mg\'', '\'SA\'', '\'USD\'', 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(671, 0, '\'Apalutamide\'', '\'SA\'', '\'USD\'', 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(672, 0, '\'Tracleer 125mg\'', '\'SA\'', '\'USD\'', 1, 1, 682.2, 682.2, 1, 1, 682.2, 682.2, 1, 1, 682.2, 682.2, 769, 769, 682.2, 682.2, 769, 769, 682.2, 682.2, 769, 769, 682.2, 682.2, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(673, 0, '\'Tracleer 62.5mg\'', '\'SA\'', '\'USD\'', 1, 1, 460.6, 460.6, 1, 1, 460.6, 460.6, 1, 1, 460.6, 460.6, 769, 769, 460.6, 460.6, 769, 769, 460.6, 460.6, 769, 769, 460.6, 460.6, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(674, 0, '\'Opsumit 10mg\'', '\'SA\'', '\'USD\'', 3, 3, 1, 1, 3, 3, 1, 1, 3, 3, 1, 1, 3, 3, 1, 1, 3, 3, 1, 1, 3, 3, 1, 1, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(675, 0, '\'Uptravi\'', '\'SA\'', '\'USD\'', 4, 4, 2, 2, 4, 4, 2, 2, 4, 4, 2, 2, 4, 4, 2, 2, 4, 4, 2, 2, 4, 4, 2, 2, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(676, 0, '\'Tracleer 32mg\'', '\'SA\'', '\'USD\'', 769, 769, 682, 682, 769, 769, 682, 682, 769, 769, 682, 682, 769, 769, 769, 769, 769, 769, 769, 769, 769, 769, 769, 769, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(677, 0, '\'Symtuza\'', '\'SA\'', '\'USD\'', 869, 869, 869, 869, 869, 869, 869, 869, 869, 869, 869, 869, 869, 869, 869, 869, 869, 869, 869, 869, 869, 869, 869, 869, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(678, 0, '\'Zavesca 84 cap 100mg \'', '\'SA\'', '\'USD\'', 6, 2, 2, 2, 6, 2, 2, 2, 6, 2, 2, 2, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(679, 0, '\'HALDOL DEC 50MG/ML 5X1ML AMP. GSK-ST.EXP\'', '\'SA\'', '\'USD\'', 4.22, 4.22, 4.22, 4.22, 4.22, 4.22, 4.22, 4.22, 4.22, 4.22, 4.22, 4.22, 4.22, 4.22, 4.22, 4.22, 4.22, 4.22, 4.22, 4.22, 4.22, 4.22, 4.22, 4.22, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(680, 0, '\'HALDOL 2MG/ML 1X30ML DROPS INTL.\'', '\'SA\'', '\'USD\'', 2.21, 2.21, 2.21, 2.21, 2.21, 2.21, 2.21, 2.21, 2.21, 2.21, 2.21, 2.21, 2.21, 2.21, 2.21, 2.21, 2.21, 2.21, 2.21, 2.21, 2.21, 2.21, 2.21, 2.21, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(681, 0, '\'SPORANOX I.V. 1% 1X25ML AMP. LUSO-ST.EXP\'', '\'SA\'', '\'USD\'', 118.8, 118.8, 118.8, 118.8, 118.8, 118.8, 118.8, 118.8, 118.8, 118.8, 118.8, 118.8, 118.8, 118.8, 118.8, 118.8, 118.8, 118.8, 118.8, 118.8, 118.8, 118.8, 118.8, 118.8, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(682, 0, '\'SPORANOX 1% 1X150ML ORSOL. ST.EXP. (2)  \'', '\'SA\'', '\'USD\'', 55.02, 55.02, 55.02, 55.02, 55.02, 55.02, 55.02, 55.02, 55.02, 55.02, 55.02, 55.02, 55.02, 55.02, 55.02, 55.02, 55.02, 55.02, 55.02, 55.02, 55.02, 55.02, 55.02, 55.02, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(683, 0, '\'Imbruvica Tab 140mg\'', '\'SA\'', '\'USD\'', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(684, 0, '\'Imbruvica Tab 280mg\'', '\'SA\'', '\'USD\'', 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(685, 0, '\'Imbruvica Tab 420mg\'', '\'SA\'', '\'USD\'', 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(686, 0, '\'Imbruvica Tab 560mg\'', '\'SA\'', '\'USD\'', 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(687, 0, '\'Spravato 2x28mg\'', '\'SA\'', '\'USD\'', 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(688, 0, '\'Spravato 3x28mg\'', '\'SA\'', '\'USD\'', 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(689, 0, '\'Cilest Tab. 21tab\'', '\'AE\'', '\'USD\'', 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, 3.12, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(690, 0, '\'Cilest Tab. 36tab\'', '\'AE\'', '\'USD\'', 9.4, 9.4, 7.39, 7.39, 9.4, 9.4, 7.39, 7.39, 9.4, 9.4, 7.39, 7.39, 9.4, 9.4, 7.39, 7.39, 9.4, 9.4, 7.39, 7.39, 9.4, 9.4, 7.39, 7.39, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(691, 32442, '\'Daktacort Cream                 \'', '\'AE\'', '\'USD\'', 2.31, 2.31, 2.31, 2.31, 2.31, 2.31, 2.31, 2.31, 2.31, 2.31, 2.31, 2.31, 1.8, 1.8, 1.8, 1.8, 1.8, 1.8, 1.8, 1.8, 1.8, 1.8, 1.8, 1.8, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(692, 32441, '\'Daktarin Oral Gel 2%\'', '\'AE\'', '\'USD\'', 3.19, 3.19, 3.19, 3.19, 3.19, 3.19, 3.19, 3.19, 3.19, 3.19, 3.19, 3.19, 3.19, 3.19, 3.19, 3.19, 3.19, 3.19, 3.19, 3.19, 3.19, 3.19, 3.19, 3.19, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(693, 387397, '\'Durogesic Transdermal Patches 100 mcg/h\'', '\'AE\'', '\'USD\'', 98.73, 98.73, 98.73, 98.73, 98.73, 98.73, 98.73, 98.73, 98.73, 98.73, 98.73, 98.73, 98.73, 98.73, 98.73, 98.73, 98.73, 98.73, 98.73, 98.73, 98.73, 98.73, 98.73, 98.73, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(694, 387398, '\'Durogesic Transdermal Patches 12 mcg/h\'', '\'AE\'', '\'USD\'', 17.62, 17.62, 17.62, 17.62, 17.62, 17.62, 17.62, 17.62, 17.62, 17.62, 17.62, 17.62, 17.62, 17.62, 17.62, 17.62, 17.62, 17.62, 17.62, 17.62, 17.62, 17.62, 17.62, 17.62, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(695, 387399, '\'Durogesic Transdermal Patches 25 mcg/h\'', '\'AE\'', '\'USD\'', 31.12, 31.12, 31.12, 31.12, 31.12, 31.12, 31.12, 31.12, 31.12, 31.12, 31.12, 31.12, 31.12, 31.12, 7.11, 7.11, 31.12, 31.12, 7.11, 7.11, 31.12, 31.12, 7.11, 7.11, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(696, 387400, '\'Durogesic Transdermal Patches 50 mcg/h\'', '\'AE\'', '\'USD\'', 52.29, 52.29, 52.29, 52.29, 52.29, 52.29, 52.29, 52.29, 52.29, 52.29, 52.29, 52.29, 52.29, 52.29, 54.66, 54.66, 52.29, 52.29, 54.66, 54.66, 52.29, 52.29, 54.66, 54.66, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(697, 387401, '\'Durogesic Transdermal Patches 75 mcg/h\'', '\'AE\'', '\'USD\'', 80.1, 80.1, 80.1, 80.1, 80.1, 80.1, 80.1, 80.1, 80.1, 80.1, 80.1, 80.1, 80.1, 80.1, 80.1, 80.1, 80.1, 80.1, 80.1, 80.1, 80.1, 80.1, 80.1, 80.1, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(698, 414064, '\'Eprex 1,000 U Pre-Filled Syringes \'', '\'AE\'', '\'USD\'', 70.3, 70.3, 70.3, 70.3, 70.3, 70.3, 70.3, 70.3, 70.3, 70.3, 70.3, 70.3, 28.54, 28.54, 28.54, 28.54, 28.54, 28.54, 28.54, 28.54, 28.54, 28.54, 28.54, 28.54, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(699, 414063, '\'Eprex 10,000 U Pre-Filled Syringes \'', '\'AE\'', '\'USD\'', 677.4, 677.4, 677.4, 677.4, 677.4, 677.4, 677.4, 677.4, 677.4, 677.4, 677.4, 677.4, 298.4, 298.4, 298.4, 298.4, 298.4, 298.4, 298.4, 298.4, 298.4, 298.4, 298.4, 298.4, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(700, 414065, '\'Eprex 2,000 U Pre-Filled Syringes \'', '\'AE\'', '\'USD\'', 139.31, 139.31, 139.31, 139.31, 139.31, 139.31, 139.31, 139.31, 139.31, 139.31, 139.31, 139.31, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(701, 414066, '\'Eprex 3,000 U Pre-Filled Syringes \'', '\'AE\'', '\'USD\'', 91.5, 91.5, 91.5, 91.5, 91.5, 91.5, 91.5, 91.5, 91.5, 91.5, 91.5, 91.5, 89.52, 89.52, 89.52, 89.52, 89.52, 89.52, 89.52, 89.52, 89.52, 89.52, 89.52, 89.52, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(702, 414068, '\'Eprex 4,000 U Pre-Filled Syringes \'', '\'AE\'', '\'USD\'', 276.56, 276.56, 276.56, 276.56, 276.56, 276.56, 276.56, 276.56, 276.56, 276.56, 276.56, 276.56, 67.2, 67.2, 67.2, 67.2, 67.2, 67.2, 67.2, 67.2, 67.2, 67.2, 67.2, 67.2, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(703, 414067, '\'Eprex 40,000 U Pre-Filled Syringe \'', '\'AE\'', '\'USD\'', 462.68, 462.68, 462.68, 462.68, 462.68, 462.68, 462.68, 462.68, 462.68, 462.68, 462.68, 462.68, 183.54, 183.54, 183.54, 183.54, 183.54, 183.54, 183.54, 183.54, 183.54, 183.54, 183.54, 183.54, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00');
INSERT INTO `jnj_pricing_dataentry` (`id`, `material`, `SKU`, `countryCode`, `currency`, `cif_jan`, `cif_feb`, `cif_mar`, `cif_apr`, `cif_may`, `cif_jun`, `cif_jul`, `cif_aug`, `cif_sep`, `cif_oct`, `cif_nov`, `cif_dec`, `tnd_jan`, `tnd_feb`, `tnd_mar`, `tnd_apr`, `tnd_may`, `tnd_jun`, `tnd_jul`, `tnd_aug`, `tnd_sep`, `tnd_oct`, `tnd_nov`, `tnd_dec`, `discounts`, `focs`, `totalDiscount`, `month`, `year`, `createDate`, `ModifiedDate`) VALUES
(704, 0, '\'Eprex 5,000 U Pre-Filled Syringes \'', '\'AE\'', '\'USD\'', 345.09, 345.09, 345.09, 345.09, 345.09, 345.09, 345.09, 345.09, 345.09, 345.09, 345.09, 345.09, 110, 110, 110, 110, 110, 110, 110, 110, 110, 110, 110, 110, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(705, 414069, '\'Eprex 6,000 U Pre-Filled Syringes \'', '\'AE\'', '\'USD\'', 414.11, 414.11, 414.11, 414.11, 414.11, 414.11, 414.11, 414.11, 414.11, 414.11, 414.11, 414.11, 116, 116, 116, 116, 116, 116, 116, 116, 116, 116, 116, 116, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(706, 0, '\'Eprex 8,000 U Pre-Filled Syringes \'', '\'AE\'', '\'USD\'', 552.14, 552.14, 552.14, 552.14, 552.14, 552.14, 552.14, 552.14, 552.14, 552.14, 552.14, 552.14, 245.71, 245.71, 245.71, 245.71, 245.71, 245.71, 245.71, 245.71, 245.71, 245.71, 245.71, 245.71, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(707, 88878, '\'Gyno-Daktarin V. Cream \'', '\'AE\'', '\'USD\'', 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, 6.31, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(708, 414691, '\'Gyno Daktarin 200 mg V. Capsules\'', '\'AE\'', '\'USD\'', 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(709, 414690, '\'Gyno Daktarin 400 mg V. Capsules\'', '\'AE\'', '\'USD\'', 3.94, 3.94, 3.94, 3.94, 3.94, 3.94, 3.94, 3.94, 3.94, 3.94, 3.94, 3.94, 3.94, 3.94, 3.94, 3.94, 3.94, 3.94, 3.94, 3.94, 3.94, 3.94, 3.94, 3.94, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(710, 140311, '\'Gyno-Pevaryl V. Cream \'', '\'AE\'', '\'USD\'', 7.77, 7.77, 7.77, 7.77, 7.77, 7.77, 7.77, 7.77, 7.77, 7.77, 7.77, 7.77, 7.77, 7.77, 7.77, 7.77, 7.77, 7.77, 7.77, 7.77, 7.77, 7.77, 7.77, 7.77, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(711, 387445, '\'Gyno Pevaryl 150 mg V. Suppositories\'', '\'AE\'', '\'USD\'', 3.84, 3.84, 3.73, 3.73, 3.84, 3.84, 3.73, 3.73, 3.84, 3.84, 3.73, 3.73, 3.73, 3.73, 3.73, 3.73, 3.73, 3.73, 3.73, 3.73, 3.73, 3.73, 3.73, 3.73, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(712, 387447, '\'Gyno-Pevaryl Depot 150 mg V. Ovules\'', '\'AE\'', '\'USD\'', 4.89, 4.89, 4.81, 4.81, 4.89, 4.89, 4.81, 4.81, 4.89, 4.89, 4.81, 4.81, 4.89, 4.89, 4.81, 4.81, 4.89, 4.89, 4.81, 4.81, 4.89, 4.89, 4.81, 4.81, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(713, 387165, '\'Invega 3 mg Extended Release Tab. \'', '\'AE\'', '\'USD\'', 88.12, 88.12, 88.12, 88.12, 88.12, 88.12, 88.12, 88.12, 88.12, 88.12, 88.12, 88.12, 88.12, 88.12, 41.39, 41.39, 88.12, 88.12, 41.39, 41.39, 88.12, 88.12, 41.39, 41.39, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(714, 387168, '\'Invega 6 mg Extended Release Tab. \'', '\'AE\'', '\'USD\'', 88.12, 88.12, 88.12, 88.12, 88.12, 88.12, 88.12, 88.12, 88.12, 88.12, 88.12, 88.12, 88.12, 88.12, 48.8, 48.8, 88.12, 88.12, 48.8, 48.8, 88.12, 88.12, 48.8, 48.8, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(715, 387171, '\'Invega 9 mg Extended Release Tab. \'', '\'AE\'', '\'USD\'', 95.51, 95.51, 95.51, 95.51, 95.51, 95.51, 95.51, 95.51, 95.51, 95.51, 95.51, 95.51, 95.51, 95.51, 95.51, 95.51, 95.51, 95.51, 95.51, 95.51, 95.51, 95.51, 95.51, 95.51, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(716, 387758, '\'Invega Sustenna 50 mg/ 0.5 ml \'', '\'AE\'', '\'USD\'', 221.77, 221.77, 221.77, 221.77, 221.77, 221.77, 221.77, 221.77, 221.77, 221.77, 221.77, 221.77, 221.77, 221.77, 221.77, 221.77, 221.77, 221.77, 221.77, 221.77, 221.77, 221.77, 221.77, 221.77, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(717, 387759, '\'Invega Sustenna 75 mg/ 0.75 ml \'', '\'AE\'', '\'USD\'', 292.64, 292.64, 292.64, 292.64, 292.64, 292.64, 292.64, 292.64, 292.64, 292.64, 292.64, 292.64, 292.64, 292.64, 292.64, 292.64, 292.64, 292.64, 292.64, 292.64, 292.64, 292.64, 292.64, 292.64, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(718, 387760, '\'Invega Sustenna 100 mg/ 1 ml \'', '\'AE\'', '\'USD\'', 358.67, 358.67, 358.67, 358.67, 358.67, 358.67, 358.67, 358.67, 358.67, 358.67, 358.67, 358.67, 358.67, 358.67, 358.67, 358.67, 358.67, 358.67, 358.67, 358.67, 358.67, 358.67, 358.67, 358.67, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(719, 387761, '\'Invega Sustenna 150 mg/ 1.5 ml \'', '\'AE\'', '\'USD\'', 417.29, 417.29, 417.29, 417.29, 417.29, 417.29, 417.29, 417.29, 417.29, 417.29, 417.29, 417.29, 417.29, 417.29, 417.29, 417.29, 417.29, 417.29, 417.29, 417.29, 417.29, 417.29, 417.29, 417.29, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(720, 96056, '\'Motilium 10 mg Tab. 30s\'', '\'AE\'', '\'USD\'', 3.3, 3.3, 3.3, 3.3, 3.3, 3.3, 3.3, 3.3, 3.3, 3.3, 3.3, 3.3, 3.3, 3.3, 3.3, 3.3, 3.3, 3.3, 3.3, 3.3, 3.3, 3.3, 3.3, 3.3, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(721, 32451, '\'Motilium 1 mg/ml Oral Suspension 200ml\'', '\'AE\'', '\'USD\'', 3.2, 3.2, 3.2, 3.2, 3.2, 3.2, 3.2, 3.2, 3.2, 3.2, 3.2, 3.2, 3.2, 3.2, 3.2, 3.2, 3.2, 3.2, 3.2, 3.2, 3.2, 3.2, 3.2, 3.2, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(722, 414696, '\'Nizoral Cream 2 %\'', '\'AE\'', '\'USD\'', 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, 3.5, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(723, 416306, '\'Olysio 150 mg capsules\'', '\'AE\'', '\'USD\'', 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 500, 500, 500, 500, 500, 500, 500, 500, 500, 500, 500, 500, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(724, 416006, '\'Pariet 10 mg Tab. 14s\'', '\'AE\'', '\'USD\'', 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, 7.11, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(725, 416007, '\'Pariet 10 mg Tab. 28s\'', '\'AE\'', '\'USD\'', 16.73, 16.73, 16.73, 16.73, 16.73, 16.73, 16.73, 16.73, 16.73, 16.73, 16.73, 16.73, 16.73, 16.73, 16.73, 16.73, 16.73, 16.73, 16.73, 16.73, 16.73, 16.73, 16.73, 16.73, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(726, 416009, '\'Pariet 20 mg Tab. 14s\'', '\'AE\'', '\'USD\'', 14.35, 14.35, 14.35, 14.35, 14.35, 14.35, 14.35, 14.35, 14.35, 14.35, 14.35, 14.35, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(727, 416010, '\'Pariet 20 mg Tab. 28s\'', '\'AE\'', '\'USD\'', 26.01, 26.01, 26.01, 26.01, 26.01, 26.01, 26.01, 26.01, 26.01, 26.01, 26.01, 26.01, 26.01, 26.01, 26.01, 26.01, 26.01, 26.01, 26.01, 26.01, 26.01, 26.01, 26.01, 26.01, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(728, 140307, '\'Pevaryl Cream 1 % 15g\'', '\'AE\'', '\'USD\'', 1.97, 1.97, 1.97, 1.97, 1.97, 1.97, 1.97, 1.97, 1.97, 1.97, 1.97, 1.97, 1.97, 1.97, 1.97, 1.97, 1.97, 1.97, 1.97, 1.97, 1.97, 1.97, 1.97, 1.97, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(729, 140309, '\'Pevaryl Cream 1 % 30g\'', '\'AE\'', '\'USD\'', 3.75, 3.75, 3.75, 3.75, 3.75, 3.75, 3.75, 3.75, 3.75, 3.75, 3.75, 3.75, 3.75, 3.75, 3.75, 3.75, 3.75, 3.75, 3.75, 3.75, 3.75, 3.75, 3.75, 3.75, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(730, 412323, '\'Pevisone Cream \'', '\'AE\'', '\'USD\'', 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, 2.91, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(731, 0, '\'Prezista 300 mg Tab. \'', '\'AE\'', '\'USD\'', 792.41, 792.41, 792.41, 792.41, 792.41, 792.41, 792.41, 792.41, 792.41, 792.41, 792.41, 792.41, 792.41, 792.41, 792.41, 792.41, 792.41, 792.41, 792.41, 792.41, 792.41, 792.41, 792.41, 792.41, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(732, 96394, '\'Reminyl 4 mg Tab.\'', '\'AE\'', '\'USD\'', 13.41, 13.41, 13.41, 13.41, 13.41, 13.41, 13.41, 13.41, 13.41, 13.41, 13.41, 13.41, 13.41, 13.41, 13.41, 13.41, 13.41, 13.41, 13.41, 13.41, 13.41, 13.41, 13.41, 13.41, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(733, 90839, '\'Reminyl 4 mg/ml Oral Solution  \'', '\'AE\'', '\'USD\'', 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, 46.94, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(734, 376853, '\'Risperdal 1mg Tab. 6s\'', '\'AE\'', '\'USD\'', 4.58, 4.58, 4.58, 4.58, 4.58, 4.58, 4.58, 4.58, 4.58, 4.58, 4.58, 4.58, 2.29, 2.29, 2.29, 2.29, 2.29, 2.29, 2.29, 2.29, 2.29, 2.29, 2.29, 2.29, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(735, 376854, '\'Risperdal 1mg Tab. 20s\'', '\'AE\'', '\'USD\'', 15.27, 15.27, 15.27, 15.27, 15.27, 15.27, 15.27, 15.27, 15.27, 15.27, 15.27, 15.27, 7.63, 7.63, 7.63, 7.63, 7.63, 7.63, 7.63, 7.63, 7.63, 7.63, 7.63, 7.63, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(736, 90474, '\'Reminyl 8 mg Tab.\'', '\'AE\'', '\'USD\'', 69.66, 69.66, 69.66, 69.66, 69.66, 69.66, 69.66, 69.66, 69.66, 69.66, 69.66, 69.66, 69.66, 69.66, 69.66, 69.66, 69.66, 69.66, 69.66, 69.66, 69.66, 69.66, 69.66, 69.66, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(737, 87518, '\'Risperdal 1 mg/ml Oral Solution\'', '\'AE\'', '\'USD\'', 52.03, 52.03, 46.52, 46.52, 52.03, 52.03, 46.52, 46.52, 52.03, 52.03, 46.52, 46.52, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(738, 376855, '\'Risperdal 2mg Tab. 20s\'', '\'AE\'', '\'USD\'', 21.27, 21.27, 21.27, 21.27, 21.27, 21.27, 21.27, 21.27, 21.27, 21.27, 21.27, 21.27, 10.64, 10.64, 10.64, 10.64, 10.64, 10.64, 10.64, 10.64, 10.64, 10.64, 10.64, 10.64, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(739, 88082, '\'Risperdal 2mg Tab. 60s\'', '\'AE\'', '\'USD\'', 58.54, 58.54, 58.54, 58.54, 58.54, 58.54, 58.54, 58.54, 58.54, 58.54, 58.54, 58.54, 29.27, 29.27, 29.27, 29.27, 29.27, 29.27, 29.27, 29.27, 29.27, 29.27, 29.27, 29.27, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(740, 376856, '\'Risperdal 3mg Tab. 20s\'', '\'AE\'', '\'USD\'', 27.36, 27.36, 27.36, 27.36, 27.36, 27.36, 27.36, 27.36, 27.36, 27.36, 27.36, 27.36, 13.68, 13.68, 13.68, 13.68, 13.68, 13.68, 13.68, 13.68, 13.68, 13.68, 13.68, 13.68, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(741, 96568, '\'Risperdal 3mg Tab. 60s\'', '\'AE\'', '\'USD\'', 75.29, 75.29, 75.29, 75.29, 75.29, 75.29, 75.29, 75.29, 75.29, 75.29, 75.29, 75.29, 37.65, 37.65, 37.65, 37.65, 37.65, 37.65, 37.65, 37.65, 37.65, 37.65, 37.65, 37.65, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(742, 96327, '\'Risperdal 4mg Tab. 20s\'', '\'AE\'', '\'USD\'', 34.89, 34.89, 34.89, 34.89, 34.89, 34.89, 34.89, 34.89, 34.89, 34.89, 34.89, 34.89, 17.45, 17.45, 17.45, 17.45, 17.45, 17.45, 17.45, 17.45, 17.45, 17.45, 17.45, 17.45, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(743, 96569, '\'Risperdal 4mg Tab. 60s\'', '\'AE\'', '\'USD\'', 96, 96, 96, 96, 96, 96, 96, 96, 96, 96, 96, 96, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(744, 376595, '\'Risperdal Consta 25 mg Inj.  \'', '\'AE\'', '\'USD\'', 116.79, 116.79, 116.79, 116.79, 116.79, 116.79, 116.79, 116.79, 116.79, 116.79, 116.79, 116.79, 73.96, 73.96, 73.96, 73.96, 73.96, 73.96, 73.96, 73.96, 73.96, 73.96, 73.96, 73.96, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(745, 376596, '\'Risperdal Consta 37.5 mg Inj. \'', '\'AE\'', '\'USD\'', 154.05, 154.05, 154.05, 154.05, 154.05, 154.05, 154.05, 154.05, 154.05, 154.05, 154.05, 154.05, 102.95, 102.95, 102.95, 102.95, 102.95, 102.95, 102.95, 102.95, 102.95, 102.95, 102.95, 102.95, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(746, 376597, '\'Risperdal Consta 50 mg Inj.  \'', '\'AE\'', '\'USD\'', 189.61, 189.61, 189.61, 189.61, 189.61, 189.61, 189.61, 189.61, 189.61, 189.61, 189.61, 189.61, 122.95, 122.95, 122.95, 122.95, 122.95, 122.95, 122.95, 122.95, 122.95, 122.95, 122.95, 122.95, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(747, 376935, '\'Sporanox 100 mg Cap. 15s\'', '\'AE\'', '\'USD\'', 21.26, 21.26, 21.26, 21.26, 21.26, 21.26, 21.26, 21.26, 21.26, 21.26, 21.26, 21.26, 21.26, 21.26, 21.26, 21.26, 21.26, 21.26, 21.26, 21.26, 21.26, 21.26, 21.26, 21.26, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(748, 96489, '\'Sporanox 100 mg Cap. 4s\'', '\'AE\'', '\'USD\'', 6.51, 6.51, 6.51, 6.51, 6.51, 6.51, 6.51, 6.51, 6.51, 6.51, 6.51, 6.51, 6.51, 6.51, 6.51, 6.51, 6.51, 6.51, 6.51, 6.51, 6.51, 6.51, 6.51, 6.51, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(749, 414287, '\'Stelara 45mg/0.5ml \'', '\'AE\'', '\'USD\'', 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(750, 414288, '\'Stelara 90mg/1ml \'', '\'AE\'', '\'USD\'', 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(751, 96046, '\'Stugeron 25 mg Tab.\'', '\'AE\'', '\'USD\'', 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, 2.09, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(752, 141021, '\'Topamax 100 mg Tab.\'', '\'AE\'', '\'USD\'', 42.49, 42.49, 42.49, 42.49, 42.49, 42.49, 42.49, 42.49, 42.49, 42.49, 42.49, 42.49, 42.49, 42.49, 42.49, 42.49, 42.49, 42.49, 42.49, 42.49, 42.49, 42.49, 42.49, 42.49, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(753, 412301, '\'Topamax 15 mg Sprinkle Cap.\'', '\'AE\'', '\'USD\'', 11.78, 11.78, 11.78, 11.78, 11.78, 11.78, 11.78, 11.78, 11.78, 11.78, 11.78, 11.78, 11.78, 11.78, 11.78, 11.78, 11.78, 11.78, 11.78, 11.78, 11.78, 11.78, 11.78, 11.78, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(754, 141023, '\'Topamax 200 mg Tab.\'', '\'AE\'', '\'USD\'', 69.68, 69.68, 69.68, 69.68, 69.68, 69.68, 69.68, 69.68, 69.68, 69.68, 69.68, 69.68, 69.68, 69.68, 69.68, 69.68, 69.68, 69.68, 69.68, 69.68, 69.68, 69.68, 69.68, 69.68, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(755, 412303, '\'Topamax 25 mg Sprinkle Cap.\'', '\'AE\'', '\'USD\'', 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(756, 141016, '\'Topamax 25 mg Tab.\'', '\'AE\'', '\'USD\'', 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, 15.28, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(757, 412305, '\'Topamax 50 mg Sprinkle Cap.\'', '\'AE\'', '\'USD\'', 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(758, 141019, '\'Topamax 50 mg Tab.\'', '\'AE\'', '\'USD\'', 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, 25.91, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(759, 96063, '\'Vermox 100 mg Tab. 6s\'', '\'AE\'', '\'USD\'', 1.56, 1.56, 1.56, 1.56, 1.56, 1.56, 1.56, 1.56, 1.56, 1.56, 1.56, 1.56, 1.56, 1.56, 1.56, 1.56, 1.56, 1.56, 1.56, 1.56, 1.56, 1.56, 1.56, 1.56, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(760, 96065, '\'Vermox 100 mg Tab. 240\'s\'', '\'AE\'', '\'USD\'', 41.25, 41.25, 41.25, 41.25, 41.25, 41.25, 41.25, 41.25, 41.25, 41.25, 41.25, 41.25, 23.54, 23.54, 23.54, 23.54, 23.54, 23.54, 23.54, 23.54, 23.54, 23.54, 23.54, 23.54, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(761, 96048, '\'Vermox 500 mg Tab.\'', '\'AE\'', '\'USD\'', 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, 1.3, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(762, 32461, '\'Vermox 20 mg/ml Oral Susp.\'', '\'AE\'', '\'USD\'', 1.66, 1.66, 1.66, 1.66, 1.66, 1.66, 1.66, 1.66, 1.66, 1.66, 1.66, 1.66, 1.66, 1.66, 1.66, 1.66, 1.66, 1.66, 1.66, 1.66, 1.66, 1.66, 1.66, 1.66, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(763, 385589, '\'Yondelis 1 mg Injection \'', '\'AE\'', '\'USD\'', 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(764, 88836, '\'Daktarin Cream 2% 15g\'', '\'AE\'', '\'USD\'', 1.68, 1.68, 1.68, 1.68, 1.68, 1.68, 1.68, 1.68, 1.68, 1.68, 1.68, 1.68, 1.68, 1.68, 1.68, 1.68, 1.68, 1.68, 1.68, 1.68, 1.68, 1.68, 1.68, 1.68, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(765, 88877, '\'Daktarin Cream 2% 30g\'', '\'AE\'', '\'USD\'', 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, 3.06, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(766, 377017, '\'Daktarin Powder 2%\'', '\'AE\'', '\'USD\'', 2.19, 2.19, 2.19, 2.19, 2.19, 2.19, 2.19, 2.19, 2.19, 2.19, 2.19, 2.19, 2.19, 2.19, 2.19, 2.19, 2.19, 2.19, 2.19, 2.19, 2.19, 2.19, 2.19, 2.19, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(767, 0, '\'Daktarin Lotion 2% \'', '\'AE\'', '\'USD\'', 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, 2.01, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(768, 414963, '\'Velcade Injection 3.5 mg\'', '\'AE\'', '\'USD\'', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 803, 803, 803, 803, 803, 803, 803, 803, 803, 803, 803, 803, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(769, 412688, '\'Remicade 100 mg \'', '\'AE\'', '\'USD\'', 560, 560, 560, 560, 560, 560, 560, 560, 560, 560, 560, 560, 420, 420, 350, 350, 420, 420, 350, 350, 420, 420, 350, 350, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(770, 140788, '\'Evra Transdermal Patches \'', '\'AE\'', '\'USD\'', 8.17, 8.17, 8.17, 8.17, 8.17, 8.17, 8.17, 8.17, 8.17, 8.17, 8.17, 8.17, 8.17, 8.17, 8.17, 8.17, 8.17, 8.17, 8.17, 8.17, 8.17, 8.17, 8.17, 8.17, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(771, 387691, '\'Concerta 18mg  Extended Release Tab.\'', '\'AE\'', '\'USD\'', 33.57, 33.57, 28.25, 28.25, 33.57, 33.57, 28.25, 28.25, 33.57, 33.57, 28.25, 28.25, 33.57, 33.57, 28.25, 28.25, 33.57, 33.57, 28.25, 28.25, 33.57, 33.57, 28.25, 28.25, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(772, 387693, '\'Concerta 36mg Extended Release Tab.\'', '\'AE\'', '\'USD\'', 45.7, 45.7, 39.23, 39.23, 45.7, 45.7, 39.23, 39.23, 45.7, 45.7, 39.23, 39.23, 45.7, 45.7, 39.23, 39.23, 45.7, 45.7, 39.23, 39.23, 45.7, 45.7, 39.23, 39.23, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(773, 414434, '\'Caelyx 2 mg/ml\'', '\'AE\'', '\'USD\'', 512, 512, 512, 512, 512, 512, 512, 512, 512, 512, 512, 512, 512, 512, 512, 512, 512, 512, 512, 512, 512, 512, 512, 512, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(774, 414448, '\'Zytiga 250 mg Tabs\'', '\'AE\'', '\'USD\'', 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(775, 412414, '\'Incivo 375 mg Film-Coated Tabs.\'', '\'AE\'', '\'USD\'', 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(776, 412675, '\'Simponi 50 mg/ 0.5 ml Injection (PFP)\'', '\'AE\'', '\'USD\'', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 953, 953, 1, 1, 953, 953, 1, 1, 953, 953, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(777, 414050, '\'Resolor 1 mg Film-Coated Tabs.\'', '\'AE\'', '\'USD\'', 30.95, 30.95, 26.33, 26.33, 30.95, 30.95, 26.33, 26.33, 30.95, 30.95, 26.33, 26.33, 30.95, 30.95, 26.33, 26.33, 30.95, 30.95, 26.33, 26.33, 30.95, 30.95, 26.33, 26.33, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(778, 414053, '\'Resolor 2 mg Film-Coated Tabs.\'', '\'AE\'', '\'USD\'', 50.76, 50.76, 43.29, 43.29, 50.76, 50.76, 43.29, 43.29, 50.76, 50.76, 43.29, 43.29, 50.76, 50.76, 43.29, 43.29, 50.76, 50.76, 43.29, 43.29, 50.76, 50.76, 43.29, 43.29, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(779, 414907, '\'Invokana 100mg \'', '\'AE\'', '\'USD\'', 49.5, 49.5, 49.5, 49.5, 49.5, 49.5, 49.5, 49.5, 49.5, 49.5, 49.5, 49.5, 49.5, 49.5, 49.5, 49.5, 49.5, 49.5, 49.5, 49.5, 49.5, 49.5, 49.5, 49.5, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(780, 414908, '\'Invokana 300mg\'', '\'AE\'', '\'USD\'', 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(781, 387104, '\'Prezista 400 mg Tablets\'', '\'AE\'', '\'USD\'', 461.18, 461.18, 461.18, 461.18, 461.18, 461.18, 461.18, 461.18, 461.18, 461.18, 461.18, 461.18, 402.77, 402.77, 402.77, 402.77, 402.77, 402.77, 402.77, 402.77, 402.77, 402.77, 402.77, 402.77, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(782, 387107, '\'Prezista 600 mg Tablets\'', '\'AE\'', '\'USD\'', 622.59, 622.59, 622.59, 622.59, 622.59, 622.59, 622.59, 622.59, 622.59, 622.59, 622.59, 622.59, 615.22, 615.22, 615.22, 615.22, 615.22, 615.22, 615.22, 615.22, 615.22, 615.22, 615.22, 615.22, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(783, 415168, '\'Darzalex 100mg\'', '\'AE\'', '\'USD\'', 449.75, 449.75, 449.75, 449.75, 449.75, 449.75, 449.75, 449.75, 449.75, 449.75, 449.75, 449.75, 427, 427, 427, 427, 427, 427, 427, 427, 427, 427, 427, 427, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(784, 415169, '\'Darzalex 400mg\'', '\'AE\'', '\'USD\'', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(785, 0, '\'Simponi 100mg PFP\'', '\'AE\'', '\'USD\'', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(786, 0, '\'Zytiga 500 mg Tabs\'', '\'AE\'', '\'USD\'', 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(787, 418298, '\'Vokanamet 50/850mg Tablets\'', '\'AE\'', '\'USD\'', 52.8, 52.8, 52.8, 52.8, 52.8, 52.8, 52.8, 52.8, 52.8, 52.8, 52.8, 52.8, 52.8, 52.8, 52.8, 52.8, 52.8, 52.8, 52.8, 52.8, 52.8, 52.8, 52.8, 52.8, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(788, 418299, '\'Vokanamet 50/1000mg Tablets\'', '\'AE\'', '\'USD\'', 52.8, 52.8, 52.8, 52.8, 52.8, 52.8, 52.8, 52.8, 52.8, 52.8, 52.8, 52.8, 52.8, 52.8, 52.8, 52.8, 52.8, 52.8, 52.8, 52.8, 52.8, 52.8, 52.8, 52.8, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(789, 418301, '\'Vokanamet 150/850mg Tablets\'', '\'AE\'', '\'USD\'', 79.2, 79.2, 79.2, 79.2, 79.2, 79.2, 79.2, 79.2, 79.2, 79.2, 79.2, 79.2, 79.2, 79.2, 79.2, 79.2, 79.2, 79.2, 79.2, 79.2, 79.2, 79.2, 79.2, 79.2, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(790, 418302, '\'Vokanamet 150/1000mg Tablets\'', '\'AE\'', '\'USD\'', 79.2, 79.2, 79.2, 79.2, 79.2, 79.2, 79.2, 79.2, 79.2, 79.2, 79.2, 79.2, 79.2, 79.2, 79.2, 79.2, 79.2, 79.2, 79.2, 79.2, 79.2, 79.2, 79.2, 79.2, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(791, 415065, '\'Rezolsta\'', '\'AE\'', '\'USD\'', 463, 463, 463, 463, 463, 463, 463, 463, 463, 463, 463, 463, 463, 463, 463, 463, 463, 463, 463, 463, 463, 463, 463, 463, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(792, 414778, '\'Imbruvica 140mg Capsule \'', '\'AE\'', '\'USD\'', 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(793, 418626, '\'Trevicta 175mg (50mg eq.)\'', '\'AE\'', '\'USD\'', 563.33, 563.33, 563.33, 563.33, 563.33, 563.33, 563.33, 563.33, 563.33, 563.33, 563.33, 563.33, 563.33, 563.33, 563.33, 563.33, 563.33, 563.33, 563.33, 563.33, 563.33, 563.33, 563.33, 563.33, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(794, 418624, '\'Trevicta 263mg (75mg eq.) \'', '\'AE\'', '\'USD\'', 746.93, 746.93, 746.93, 746.93, 746.93, 746.93, 746.93, 746.93, 746.93, 746.93, 746.93, 746.93, 746.93, 746.93, 746.93, 746.93, 746.93, 746.93, 746.93, 746.93, 746.93, 746.93, 746.93, 746.93, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(795, 418623, '\'Trevicta 360mg (100mg eq.) \'', '\'AE\'', '\'USD\'', 952.11, 952.11, 952.11, 952.11, 952.11, 952.11, 952.11, 952.11, 952.11, 952.11, 952.11, 952.11, 952.11, 952.11, 952.11, 952.11, 952.11, 952.11, 952.11, 952.11, 952.11, 952.11, 952.11, 952.11, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(796, 418621, '\'Trevicta 525mg (150mg eq.) \'', '\'AE\'', '\'USD\'', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(797, 377907, '\'DACOGEN IV 1X50MG VIAL\'', '\'AE\'', '\'USD\'', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(798, 412117, '\'Fentanyl 0.05 mg/ml Inj. 2ml x 50 amps\'', '\'AE\'', '\'USD\'', 20.25, 20.25, 20.25, 20.25, 20.25, 20.25, 20.25, 20.25, 20.25, 20.25, 20.25, 20.25, 20.25, 20.25, 20.25, 20.25, 20.25, 20.25, 20.25, 20.25, 20.25, 20.25, 20.25, 20.25, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(799, 32444, '\'Fentanyl 0.05 mg/ml Inj. 10ml x 50 amps\'', '\'AE\'', '\'USD\'', 101.9, 101.9, 101.9, 101.9, 101.9, 101.9, 101.9, 101.9, 101.9, 101.9, 101.9, 101.9, 101.9, 101.9, 101.9, 101.9, 101.9, 101.9, 101.9, 101.9, 101.9, 101.9, 101.9, 101.9, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(800, 0, '\'Guselkumab\'', '\'AE\'', '\'USD\'', 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(801, 0, '\'Stelara 130mg\'', '\'AE\'', '\'USD\'', 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(802, 0, '\'Apalutamide\'', '\'AE\'', '\'USD\'', 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(803, 0, '\'Tracleer 62.5mg\'', '\'AE\'', '\'USD\'', 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 900, 900, 900, 900, 900, 900, 900, 900, 900, 900, 900, 900, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(804, 0, '\'Tracleer 125mg\'', '\'AE\'', '\'USD\'', 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 900, 900, 900, 900, 900, 900, 900, 900, 900, 900, 900, 900, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(805, 0, '\'Uptravi\'', '\'AE\'', '\'USD\'', 4, 3, 3, 3, 4, 3, 3, 3, 4, 3, 3, 3, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(806, 0, '\'Opsumit 10mg\'', '\'AE\'', '\'USD\'', 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(807, 0, '\'Zavesca 84 cap 100mg \'', '\'AE\'', '\'USD\'', 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(808, 0, '\'Symtuza\'', '\'AE\'', '\'USD\'', 869, 869, 869, 869, 869, 869, 869, 869, 869, 869, 869, 869, 869, 869, 869, 869, 869, 869, 869, 869, 869, 869, 869, 869, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(809, 0, '\'GYNO-PEVARYL 150MG 3 OVULS MEWA\'', '\'AE\'', '\'USD\'', 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, 3.84, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(810, 0, '\'Haldol 10mg 20 Tab\'', '\'AE\'', '\'USD\'', 2.2, 2.2, 2.2, 2.2, 2.2, 2.2, 2.2, 2.2, 2.2, 2.2, 2.2, 2.2, 2.2, 2.2, 2.2, 2.2, 2.2, 2.2, 2.2, 2.2, 2.2, 2.2, 2.2, 2.2, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(811, 0, '\'HALDOL 5MG 25 TABL. QUELUZ ST.EXP.\'', '\'AE\'', '\'USD\'', 4.39, 4.39, 4.39, 4.39, 4.39, 4.39, 4.39, 4.39, 4.39, 4.39, 4.39, 4.39, 4.39, 4.39, 4.39, 4.39, 4.39, 4.39, 4.39, 4.39, 4.39, 4.39, 4.39, 4.39, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(812, 0, '\'HALDOL 5MG 1000 TABL. QUELUZ ST.EXP.\'', '\'AE\'', '\'USD\'', 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(813, 0, '\'HALDOL DEC 50MG/ML 5X1ML AMP. GSK-ST.EXP\'', '\'AE\'', '\'USD\'', 4.85, 4.85, 4.85, 4.85, 4.85, 4.85, 4.85, 4.85, 4.85, 4.85, 4.85, 4.85, 4.85, 4.85, 4.85, 4.85, 4.85, 4.85, 4.85, 4.85, 4.85, 4.85, 4.85, 4.85, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(814, 0, '\'HALDOL 5MG/ML 5X1ML AMP. GSK-ST.EXP\'', '\'AE\'', '\'USD\'', 3.94, 3.94, 3.94, 3.94, 3.94, 3.94, 3.94, 3.94, 3.94, 3.94, 3.94, 3.94, 3.94, 3.94, 3.94, 3.94, 3.94, 3.94, 3.94, 3.94, 3.94, 3.94, 3.94, 3.94, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(815, 0, '\'HALDOL DEC 100MG/ML 1X1ML AMP. GSK-ST.EX\'', '\'AE\'', '\'USD\'', 8.75, 8.75, 8.75, 8.75, 8.75, 8.75, 8.75, 8.75, 8.75, 8.75, 8.75, 8.75, 8.75, 8.75, 8.75, 8.75, 8.75, 8.75, 8.75, 8.75, 8.75, 8.75, 8.75, 8.75, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(816, 0, '\'INTELENCE 100MG 120 TABL. T1 ST.EXP.    \'', '\'AE\'', '\'USD\'', 541.2, 541.2, 541.2, 541.2, 541.2, 541.2, 541.2, 541.2, 541.2, 541.2, 541.2, 541.2, 541.2, 541.2, 541.2, 541.2, 541.2, 541.2, 541.2, 541.2, 541.2, 541.2, 541.2, 541.2, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(817, 0, '\'JURNISTA 16MG 28 ORTABL. LATINA-INTL.\'', '\'AE\'', '\'USD\'', 91.55, 91.55, 91.55, 91.55, 91.55, 91.55, 91.55, 91.55, 91.55, 91.55, 91.55, 91.55, 91.55, 91.55, 91.55, 91.55, 91.55, 91.55, 91.55, 91.55, 91.55, 91.55, 91.55, 91.55, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(818, 0, '\'JURNISTA 8MG 28 ORTABL. LATINA-INTL.    \'', '\'AE\'', '\'USD\'', 36.01, 36.01, 36.01, 36.01, 36.01, 36.01, 36.01, 36.01, 36.01, 36.01, 36.01, 36.01, 36.01, 36.01, 36.01, 36.01, 36.01, 36.01, 36.01, 36.01, 36.01, 36.01, 36.01, 36.01, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(819, 0, '\'LEUSTATIN 1MG/ML 7X10ML VIAL GSK NON-EU\'', '\'AE\'', '\'USD\'', 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(820, 0, '\'SPORANOX 1% 1X150ML ORSOL. ST.EXP. (2)  \'', '\'AE\'', '\'USD\'', 49.05, 49.05, 49.05, 49.05, 49.05, 49.05, 49.05, 49.05, 49.05, 49.05, 49.05, 49.05, 49.05, 49.05, 49.05, 49.05, 49.05, 49.05, 49.05, 49.05, 49.05, 49.05, 49.05, 49.05, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(821, 0, '\'Imbruvica Tab 140mg\'', '\'AE\'', '\'USD\'', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(822, 0, '\'Imbruvica Tab 280mg\'', '\'AE\'', '\'USD\'', 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(823, 0, '\'Imbruvica Tab 420mg\'', '\'AE\'', '\'USD\'', 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(824, 0, '\'Imbruvica Tab 560mg\'', '\'AE\'', '\'USD\'', 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(825, 0, '\'Spravato 2x28mg\'', '\'AE\'', '\'USD\'', 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, 313.6, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(826, 0, '\'Spravato 3x28mg\'', '\'AE\'', '\'USD\'', 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, 470.4, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(827, 412122, '\'Sufenta Ampoule 5 mcg/ml 10ml X 5 Amp\'', '\'\'', '\'USD\'', 13.75, 13.75, 13.75, 13.75, 13.75, 13.75, 13.75, 13.75, 13.75, 13.75, 13.75, 13.75, 13.75, 13.75, 13.75, 13.75, 13.75, 13.75, 13.75, 13.75, 13.75, 13.75, 13.75, 13.75, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00'),
(828, 412117, '\'FENTANYL 0.05MG/ML 50X2ML AMP. GSK-ST.EX\'', '\'\'', '\'USD\'', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0.00%', '8.25%', '8.25%', 10, 2019, '0000-00-00 00:00:00', '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `jnj_registration`
--

CREATE TABLE `jnj_registration` (
  `id` int(9) NOT NULL,
  `customerName` int(6) NOT NULL,
  `password` varchar(225) NOT NULL,
  `confpassword` varchar(225) NOT NULL,
  `email` varchar(60) NOT NULL,
  `userRole` int(4) DEFAULT 9,
  `assignCustomes` text NOT NULL,
  `assignItems` text NOT NULL,
  `countryName` int(4) NOT NULL,
  `month` int(2) NOT NULL,
  `year` int(4) NOT NULL,
  `userStatus` int(2) NOT NULL DEFAULT 2,
  `createDate` date NOT NULL,
  `modifiedDate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jnj_registration`
--

INSERT INTO `jnj_registration` (`id`, `customerName`, `password`, `confpassword`, `email`, `userRole`, `assignCustomes`, `assignItems`, `countryName`, `month`, `year`, `userStatus`, `createDate`, `modifiedDate`) VALUES
(1, 1, 'YWRtaW4sMjAxOQ==', 'YWRtaW4sMjAxOQ==', 'admin@jnj.com', 0, '', '', 1, 8, 2019, 1, '2019-08-03', '2019-08-03'),
(2, 54847, 'YWJAMTIzLDIwMTk=', 'YWJAMTIzLDIwMTk=', '54847tal@jnj.com', 2, '54824', '50,51,52,54,55,85', 1, 8, 2019, 1, '2019-08-03', '2019-08-03'),
(3, 54817, 'YWJAMTIzLDIwMTk=', 'YWJAMTIzLDIwMTk=', '54808cvtl@jnj.com', 3, '', '7,8,9', 1, 8, 2019, 1, '2019-08-12', '2019-08-12'),
(4, 59051, 'YWJAMTIzLDIwMTk=', 'YWJAMTIzLDIwMTk=', '54817tal@jnj.com', 2, '54817', '2,3,5,7', 1, 8, 2019, 1, '2019-08-12', '2019-08-12'),
(5, 54824, 'YWJAMTIzLDIwMTk=', 'YWJAMTIzLDIwMTk=', '12345@jnj.com', 3, '', '51,54,55,60', 1, 8, 2019, 1, '2019-08-18', '2019-08-18'),
(6, 564789, 'YWJAMTIzLDIwMTk=', 'YWJAMTIzLDIwMTk=', '564789@jnj.com', 5, '', '', 1, 10, 2019, 1, '2019-10-09', '2019-10-09');

-- --------------------------------------------------------

--
-- Table structure for table `jnj_temp_actualsalesvalue`
--

CREATE TABLE `jnj_temp_actualsalesvalue` (
  `id` int(7) NOT NULL DEFAULT 0,
  `customerWWID` int(7) NOT NULL,
  `countryId` int(5) NOT NULL,
  `type` varchar(11) NOT NULL,
  `category` varchar(45) NOT NULL,
  `itemId` int(7) NOT NULL,
  `brandId` int(7) NOT NULL,
  `unit` varchar(25) NOT NULL,
  `month` int(4) NOT NULL,
  `actualSales` int(11) NOT NULL,
  `actualVolume` float NOT NULL,
  `unitPrice` float NOT NULL,
  `year` int(4) NOT NULL,
  `busSelector` varchar(5) NOT NULL,
  `status` int(2) NOT NULL,
  `sapCode` int(10) NOT NULL,
  `divested` int(2) NOT NULL,
  `createdDate` datetime NOT NULL,
  `modifiedDate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `jnj_temp_cvtl_dataentry`
--

CREATE TABLE `jnj_temp_cvtl_dataentry` (
  `talId` int(5) NOT NULL,
  `customerName` int(7) NOT NULL,
  `countryId` varchar(5) NOT NULL,
  `type` varchar(10) NOT NULL,
  `busSelector` varchar(5) NOT NULL,
  `itemId` int(5) NOT NULL,
  `brandId` int(5) NOT NULL,
  `jan_fcast` int(5) NOT NULL,
  `feb_fcast` int(5) NOT NULL,
  `mar_fcast` int(5) NOT NULL,
  `apr_fcast` int(5) NOT NULL,
  `may_fcast` int(5) NOT NULL,
  `jun_fcast` int(5) NOT NULL,
  `jul_fcast` int(5) NOT NULL,
  `aug_fcast` int(5) NOT NULL,
  `sep_fcast` int(5) NOT NULL,
  `oct_fcast` int(5) NOT NULL,
  `nov_fcast` int(5) NOT NULL,
  `dec_fcast` int(5) NOT NULL,
  `totalSalesTarget_fcast` int(5) NOT NULL,
  `lastRollingForecast_fcast` int(5) NOT NULL,
  `totalForecast_fcast` int(5) NOT NULL,
  `varient_fcast` int(5) NOT NULL,
  `ytd_fcast` int(5) NOT NULL,
  `yearToGo_fcast` int(5) NOT NULL,
  `financialPlan_fcast` varchar(255) NOT NULL,
  `jan_focs` int(5) NOT NULL,
  `feb_focs` int(5) NOT NULL,
  `mar_focs` int(5) NOT NULL,
  `apr_focs` int(5) NOT NULL,
  `may_focs` int(5) NOT NULL,
  `jun_focs` int(5) NOT NULL,
  `jul_focs` int(5) NOT NULL,
  `aug_focs` int(5) NOT NULL,
  `sep_focs` int(5) NOT NULL,
  `oct_focs` int(5) NOT NULL,
  `nov_focs` int(5) NOT NULL,
  `dec_focs` int(5) NOT NULL,
  `totalSalesTarget_focs` int(5) NOT NULL,
  `lastRollingForecast_focs` int(5) NOT NULL,
  `totalForecast_focs` int(5) NOT NULL,
  `varient_focs` int(5) NOT NULL,
  `ytd_focs` int(5) NOT NULL,
  `yearToGo_focs` int(5) NOT NULL,
  `financialPlan_focs` int(5) NOT NULL,
  `year` int(4) NOT NULL,
  `formSubmitted` int(11) NOT NULL,
  `actionDone` int(3) NOT NULL,
  `rejectionRemark` varchar(35) NOT NULL,
  `createDate` date NOT NULL,
  `ModifiedDate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `jnj_temp_cvtl_volume`
--

CREATE TABLE `jnj_temp_cvtl_volume` (
  `cvtlId` int(5) NOT NULL DEFAULT 0,
  `customerName` int(7) NOT NULL,
  `countryId` varchar(5) CHARACTER SET latin1 NOT NULL,
  `type` varchar(10) CHARACTER SET latin1 NOT NULL,
  `busSelector` varchar(5) CHARACTER SET latin1 NOT NULL,
  `itemId` int(5) NOT NULL,
  `brandId` int(5) NOT NULL,
  `jan_fcast` int(5) NOT NULL,
  `feb_fcast` int(5) NOT NULL,
  `mar_fcast` int(5) NOT NULL,
  `apr_fcast` int(5) NOT NULL,
  `may_fcast` int(5) NOT NULL,
  `jun_fcast` int(5) NOT NULL,
  `jul_fcast` int(5) NOT NULL,
  `aug_fcast` int(5) NOT NULL,
  `sep_fcast` int(5) NOT NULL,
  `oct_fcast` int(5) NOT NULL,
  `nov_fcast` int(5) NOT NULL,
  `dec_fcast` int(5) NOT NULL,
  `totalSalesTarget_fcast` int(5) NOT NULL,
  `lastRollingForecast_fcast` int(5) NOT NULL,
  `totalForecast_fcast` int(5) NOT NULL,
  `varient_fcast` int(5) NOT NULL,
  `ytd_fcast` int(5) NOT NULL,
  `yearToGo_fcast` int(5) NOT NULL,
  `financialPlan_fcast` varchar(255) CHARACTER SET latin1 NOT NULL,
  `year` int(4) NOT NULL,
  `formSubmitted` int(11) NOT NULL,
  `createDate` date NOT NULL,
  `ModifiedDate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `jnj_temp_dataentry`
--

CREATE TABLE `jnj_temp_dataentry` (
  `tempid` int(4) NOT NULL,
  `customerName` int(6) NOT NULL,
  `countryId` int(4) NOT NULL,
  `tempforecast` int(5) NOT NULL,
  `tempfocs` int(5) NOT NULL,
  `month` int(2) NOT NULL,
  `year` int(4) NOT NULL,
  `approveStatus` int(2) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `jnj_temp_fcast_focs_dataentry`
--

CREATE TABLE `jnj_temp_fcast_focs_dataentry` (
  `talId` int(11) NOT NULL,
  `customerWWID` int(11) NOT NULL,
  `countryId` int(11) NOT NULL,
  `custType` varchar(23) NOT NULL,
  `TransName` varchar(23) NOT NULL,
  `itemId` int(11) NOT NULL,
  `brandId` int(11) NOT NULL,
  `unit` varchar(30) NOT NULL,
  `month` int(4) NOT NULL,
  `fcast` int(11) NOT NULL,
  `focs` int(11) NOT NULL,
  `year` int(11) NOT NULL,
  `status` varchar(40) NOT NULL,
  `sapCode` int(11) NOT NULL,
  `divested` int(11) NOT NULL,
  `createdDate` datetime NOT NULL,
  `modifiedDate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `jnj_temp_tal_dataentry`
--

CREATE TABLE `jnj_temp_tal_dataentry` (
  `talId` int(5) NOT NULL,
  `customerWWID` int(7) NOT NULL,
  `countryId` varchar(5) NOT NULL,
  `type` varchar(10) NOT NULL,
  `busSelector` varchar(5) NOT NULL,
  `itemId` int(5) NOT NULL,
  `brandId` int(5) NOT NULL,
  `jan_fcast` int(11) NOT NULL,
  `feb_fcast` int(11) NOT NULL,
  `mar_fcast` int(11) NOT NULL,
  `apr_fcast` int(11) NOT NULL,
  `may_fcast` int(11) NOT NULL,
  `jun_fcast` int(11) NOT NULL,
  `jul_fcast` int(11) NOT NULL,
  `aug_fcast` int(11) NOT NULL,
  `sep_fcast` int(11) NOT NULL,
  `oct_fcast` int(11) NOT NULL,
  `nov_fcast` int(11) NOT NULL,
  `dec_fcast` int(11) NOT NULL,
  `totalSalesTarget_fcast` int(11) NOT NULL,
  `lastRollingForecast_fcast` int(11) NOT NULL,
  `totalForecast_fcast` int(11) NOT NULL,
  `varient_fcast` int(11) NOT NULL,
  `ytd_fcast` int(11) NOT NULL,
  `yearToGo_fcast` int(11) NOT NULL,
  `financialPlan_fcast` int(11) NOT NULL,
  `jan_focs` int(11) NOT NULL,
  `feb_focs` int(11) NOT NULL,
  `mar_focs` int(11) NOT NULL,
  `apr_focs` int(11) NOT NULL,
  `may_focs` int(11) NOT NULL,
  `jun_focs` int(11) NOT NULL,
  `jul_focs` int(11) NOT NULL,
  `aug_focs` int(11) NOT NULL,
  `sep_focs` int(11) NOT NULL,
  `oct_focs` int(11) NOT NULL,
  `nov_focs` int(11) NOT NULL,
  `dec_focs` int(11) NOT NULL,
  `totalSalesTarget_focs` int(11) NOT NULL,
  `lastRollingForecast_focs` int(11) NOT NULL,
  `totalForecast_focs` int(11) NOT NULL,
  `varient_focs` int(11) NOT NULL,
  `ytd_focs` int(11) NOT NULL,
  `yearToGo_focs` int(11) NOT NULL,
  `financialPlan_focs` int(11) NOT NULL,
  `year` int(4) NOT NULL,
  `formSubmitted` int(11) NOT NULL DEFAULT 0,
  `actionDone` int(3) NOT NULL,
  `rejectionRemark` varchar(35) NOT NULL,
  `createDate` datetime NOT NULL,
  `ModifiedDate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jnj_temp_tal_dataentry`
--

INSERT INTO `jnj_temp_tal_dataentry` (`talId`, `customerWWID`, `countryId`, `type`, `busSelector`, `itemId`, `brandId`, `jan_fcast`, `feb_fcast`, `mar_fcast`, `apr_fcast`, `may_fcast`, `jun_fcast`, `jul_fcast`, `aug_fcast`, `sep_fcast`, `oct_fcast`, `nov_fcast`, `dec_fcast`, `totalSalesTarget_fcast`, `lastRollingForecast_fcast`, `totalForecast_fcast`, `varient_fcast`, `ytd_fcast`, `yearToGo_fcast`, `financialPlan_fcast`, `jan_focs`, `feb_focs`, `mar_focs`, `apr_focs`, `may_focs`, `jun_focs`, `jul_focs`, `aug_focs`, `sep_focs`, `oct_focs`, `nov_focs`, `dec_focs`, `totalSalesTarget_focs`, `lastRollingForecast_focs`, `totalForecast_focs`, `varient_focs`, `ytd_focs`, `yearToGo_focs`, `financialPlan_focs`, `year`, `formSubmitted`, `actionDone`, `rejectionRemark`, `createDate`, `ModifiedDate`) VALUES
(1, 54817, 'SA', 'Institutio', 'DPO', 7, 4, 628, 707, 583, 475, 775, 620, 669, 461, 776, 120, 122, 456, 6100, 410, 6392, 5982, 5694, -5644, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2019, 1, 2, 't', '2019-11-07 16:57:08', '2019-11-07'),
(2, 54817, 'SA', 'Private', 'DPO', 8, 5, 598, 849, 421, 687, 766, 792, 683, 480, 536, 12, 45, 1112, 14400, 158, 6981, 6823, 5812, 288, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2019, 1, 0, '', '2019-11-07 16:57:08', '2019-11-07'),
(3, 54817, 'SA', 'Private', 'DPO', 9, 6, 1198, 939, 1215, 1605, 399, 7, 3, 0, 2171, 0, 0, 0, 10200, 1504, 7537, 7379, 7537, 6863, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2019, 1, 0, '', '2019-11-07 16:57:08', '2019-11-07');

-- --------------------------------------------------------

--
-- Table structure for table `jnj_temp_totalsalestarget`
--

CREATE TABLE `jnj_temp_totalsalestarget` (
  `id` int(5) NOT NULL,
  `customerName` int(6) NOT NULL,
  `countryId` int(5) NOT NULL,
  `itemName` int(60) NOT NULL,
  `acumulatedMonth` int(3) NOT NULL,
  `year` int(4) NOT NULL,
  `ffTarget` int(10) NOT NULL,
  `createdDate` date NOT NULL,
  `modifiedDate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jnj_temp_totalsalestarget`
--

INSERT INTO `jnj_temp_totalsalestarget` (`id`, `customerName`, `countryId`, `itemName`, `acumulatedMonth`, `year`, `ffTarget`, `createdDate`, `modifiedDate`) VALUES
(1, 0, 0, 0, 0, 0, 0, '2019-09-25', '2019-09-25'),
(2, 54806, 5, 2, 12, 2019, 390, '2019-09-25', '2019-09-25'),
(3, 54806, 5, 7, 12, 2019, 63000, '2019-09-25', '2019-09-25'),
(4, 54806, 5, 8, 12, 2019, 165000, '2019-09-25', '2019-09-25'),
(5, 54806, 5, 9, 12, 2019, 55000, '2019-09-25', '2019-09-25'),
(6, 54847, 1, 85, 12, 2019, 46851, '2019-09-25', '2019-09-25'),
(7, 54847, 1, 50, 12, 2019, 23312, '2019-09-25', '2019-09-25'),
(8, 54847, 1, 51, 12, 2019, 22201, '2019-09-25', '2019-09-25'),
(9, 54847, 1, 52, 12, 2019, 80, '2019-09-25', '2019-09-25'),
(10, 54847, 1, 54, 12, 2019, 50100, '2019-09-25', '2019-09-25'),
(11, 54847, 1, 55, 12, 2019, 3290, '2019-09-25', '2019-09-25'),
(12, 59051, 1, 2, 12, 2019, 0, '2019-09-25', '2019-09-25'),
(13, 59051, 1, 3, 12, 2019, 27818, '2019-09-25', '2019-09-25'),
(14, 59051, 1, 5, 12, 2019, 9840, '2019-09-25', '2019-09-25'),
(15, 59051, 1, 7, 12, 2019, 304500, '2019-09-25', '2019-09-25'),
(16, 54817, 1, 2, 12, 2019, 50, '2019-09-25', '2019-09-25'),
(17, 54817, 1, 7, 12, 2019, 6100, '2019-09-25', '2019-09-25'),
(18, 54817, 1, 8, 12, 2019, 14400, '2019-09-25', '2019-09-25'),
(19, 54817, 1, 9, 12, 2019, 10200, '2019-09-25', '2019-09-25'),
(20, 54824, 1, 51, 12, 2019, 2629, '2019-09-25', '2019-09-25'),
(21, 54824, 1, 54, 12, 2019, 27000, '2019-09-25', '2019-09-25'),
(22, 54824, 1, 55, 12, 2019, 10000, '2019-09-25', '2019-09-25'),
(23, 54824, 1, 60, 12, 2019, 13500, '2019-09-25', '2019-09-25');

-- --------------------------------------------------------

--
-- Table structure for table `jnj_totalrollingforecast`
--

CREATE TABLE `jnj_totalrollingforecast` (
  `id` int(4) NOT NULL,
  `customerWWID` int(7) NOT NULL,
  `itemId` int(4) NOT NULL,
  `month` int(2) NOT NULL,
  `year` int(4) NOT NULL,
  `rollingForecast` float NOT NULL,
  `rollingForecastFocs` float NOT NULL,
  `createdDate` datetime NOT NULL,
  `modifiedDate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jnj_totalrollingforecast`
--

INSERT INTO `jnj_totalrollingforecast` (`id`, `customerWWID`, `itemId`, `month`, `year`, `rollingForecast`, `rollingForecastFocs`, `createdDate`, `modifiedDate`) VALUES
(1, 54806, 2, 8, 2019, 204, 0, '2019-09-25 11:57:06', '2019-09-25'),
(2, 54806, 7, 8, 2019, 798, 0, '2019-09-25 11:57:06', '2019-09-25'),
(3, 54806, 8, 8, 2019, 1012, 0, '2019-09-25 11:57:06', '2019-09-25'),
(4, 54806, 9, 8, 2019, 520, 0, '2019-09-25 11:57:06', '2019-09-25'),
(5, 54817, 2, 9, 2019, 15397, 0, '2019-09-25 11:57:06', '2019-09-25'),
(6, 54817, 7, 9, 2019, 410, 0, '2019-09-25 11:57:06', '2019-09-25'),
(7, 54817, 8, 9, 2019, 158, 0, '2019-09-25 11:57:06', '2019-09-25'),
(8, 54817, 9, 9, 2019, 1504, 0, '2019-09-25 11:57:06', '2019-09-25'),
(9, 54824, 51, 8, 2019, 576348, 0, '2019-09-25 11:57:06', '2019-09-25'),
(10, 54824, 54, 8, 2019, 3277, 0, '2019-09-25 11:57:06', '2019-09-25'),
(11, 54824, 55, 8, 2019, 5187, 0, '2019-09-25 11:57:06', '2019-09-25'),
(12, 54824, 60, 8, 2019, 1455, 0, '2019-09-25 11:57:06', '2019-09-25'),
(13, 54824, 60, 9, 2019, 1455, 0, '2019-09-26 00:18:01', '2019-09-26'),
(14, 54824, 55, 9, 2019, 5187, 0, '2019-09-26 00:18:01', '2019-09-26'),
(15, 54824, 54, 9, 2019, 3277, 0, '2019-09-26 00:18:01', '2019-09-26'),
(16, 54824, 51, 9, 2019, 576348, 0, '2019-09-26 00:18:01', '2019-09-26'),
(17, 54824, 60, 9, 2019, 1455, 0, '2019-09-26 00:22:24', '2019-09-26'),
(18, 54824, 55, 9, 2019, 5187, 0, '2019-09-26 00:22:24', '2019-09-26'),
(19, 54824, 54, 9, 2019, 3277, 0, '2019-09-26 00:22:24', '2019-09-26'),
(20, 54824, 51, 9, 2019, 576348, 0, '2019-09-26 00:22:24', '2019-09-26'),
(21, 54824, 60, 9, 2019, 1455, 0, '2019-09-26 00:23:33', '2019-09-26'),
(22, 54824, 55, 9, 2019, 5187, 0, '2019-09-26 00:23:33', '2019-09-26'),
(23, 54824, 54, 9, 2019, 3277, 0, '2019-09-26 00:23:33', '2019-09-26'),
(24, 54824, 51, 9, 2019, 576348, 0, '2019-09-26 00:23:33', '2019-09-26'),
(25, 54824, 60, 9, 2019, 1455, 0, '2019-09-26 01:12:25', '2019-09-26'),
(26, 54824, 55, 9, 2019, 5187, 0, '2019-09-26 01:12:25', '2019-09-26'),
(27, 54824, 54, 9, 2019, 3277, 0, '2019-09-26 01:12:25', '2019-09-26'),
(28, 54824, 51, 9, 2019, 576348, 0, '2019-09-26 01:12:25', '2019-09-26'),
(29, 54824, 60, 9, 2019, 1455, 0, '2019-09-26 01:15:16', '2019-09-26'),
(30, 54824, 55, 9, 2019, 5187, 0, '2019-09-26 01:15:16', '2019-09-26'),
(31, 54824, 54, 9, 2019, 3277, 0, '2019-09-26 01:15:16', '2019-09-26'),
(32, 54824, 51, 9, 2019, 576348, 0, '2019-09-26 01:15:16', '2019-09-26'),
(33, 54817, 2, 10, 2019, 15397, 0, '2019-10-17 13:42:02', '2019-10-17'),
(34, 54817, 7, 10, 2019, 410, 0, '2019-10-17 13:42:02', '2019-10-17'),
(35, 54817, 8, 10, 2019, 158, 0, '2019-10-17 13:42:02', '2019-10-17'),
(36, 54817, 9, 10, 2019, 1504, 0, '2019-10-17 13:42:02', '2019-10-17'),
(37, 54817, 2, 10, 2019, 15397, 0, '2019-10-17 18:24:39', '2019-10-17'),
(38, 54817, 7, 10, 2019, 410, 0, '2019-10-17 18:24:39', '2019-10-17'),
(39, 54817, 8, 10, 2019, 158, 0, '2019-10-17 18:24:39', '2019-10-17'),
(40, 54817, 9, 10, 2019, 1504, 0, '2019-10-17 18:24:39', '2019-10-17'),
(41, 54817, 2, 10, 2019, 15397, 0, '2019-10-28 12:57:31', '2019-10-28'),
(42, 54817, 7, 10, 2019, 410, 0, '2019-10-28 12:57:31', '2019-10-28'),
(43, 54817, 8, 10, 2019, 158, 0, '2019-10-28 12:57:31', '2019-10-28'),
(44, 54817, 9, 10, 2019, 1504, 0, '2019-10-28 12:57:31', '2019-10-28'),
(45, 54817, 2, 11, 2019, 15397, 0, '2019-11-04 15:46:16', '2019-11-04'),
(46, 54817, 7, 11, 2019, 410, 0, '2019-11-04 15:46:16', '2019-11-04'),
(47, 54817, 8, 11, 2019, 158, 0, '2019-11-04 15:46:16', '2019-11-04'),
(48, 54817, 9, 11, 2019, 1504, 0, '2019-11-04 15:46:16', '2019-11-04'),
(49, 54817, 2, 11, 2019, 15397, 0, '2019-11-06 22:57:15', '2019-11-06'),
(50, 54817, 7, 11, 2019, 410, 0, '2019-11-06 22:57:15', '2019-11-06'),
(51, 54817, 8, 11, 2019, 158, 0, '2019-11-06 22:57:15', '2019-11-06'),
(52, 54817, 9, 11, 2019, 1504, 0, '2019-11-06 22:57:15', '2019-11-06'),
(53, 54817, 2, 11, 2019, 15397, 0, '2019-11-06 23:05:36', '2019-11-06'),
(54, 54817, 7, 11, 2019, 410, 0, '2019-11-06 23:05:36', '2019-11-06'),
(55, 54817, 8, 11, 2019, 158, 0, '2019-11-06 23:05:36', '2019-11-06'),
(56, 54817, 9, 11, 2019, 1504, 0, '2019-11-06 23:05:36', '2019-11-06'),
(57, 54817, 2, 11, 2019, 15397, 0, '2019-11-06 23:15:00', '2019-11-06'),
(58, 54817, 7, 11, 2019, 410, 0, '2019-11-06 23:15:00', '2019-11-06'),
(59, 54817, 8, 11, 2019, 158, 0, '2019-11-06 23:15:00', '2019-11-06'),
(60, 54817, 9, 11, 2019, 1504, 0, '2019-11-06 23:15:00', '2019-11-06'),
(61, 54817, 2, 11, 2019, 15397, 0, '2019-11-06 23:23:09', '2019-11-06'),
(62, 54817, 7, 11, 2019, 410, 0, '2019-11-06 23:23:09', '2019-11-06'),
(63, 54817, 8, 11, 2019, 158, 0, '2019-11-06 23:23:09', '2019-11-06'),
(64, 54817, 9, 11, 2019, 1504, 0, '2019-11-06 23:23:09', '2019-11-06'),
(65, 54817, 2, 11, 2019, 15397, 0, '2019-11-06 23:23:39', '2019-11-06'),
(66, 54817, 7, 11, 2019, 410, 0, '2019-11-06 23:23:39', '2019-11-06'),
(67, 54817, 8, 11, 2019, 158, 0, '2019-11-06 23:23:39', '2019-11-06'),
(68, 54817, 9, 11, 2019, 1504, 0, '2019-11-06 23:23:39', '2019-11-06'),
(69, 54817, 2, 11, 2019, 15397, 0, '2019-11-06 23:28:58', '2019-11-06'),
(70, 54817, 7, 11, 2019, 410, 0, '2019-11-06 23:28:58', '2019-11-06'),
(71, 54817, 8, 11, 2019, 158, 0, '2019-11-06 23:28:58', '2019-11-06'),
(72, 54817, 9, 11, 2019, 1504, 0, '2019-11-06 23:28:58', '2019-11-06'),
(73, 54817, 2, 11, 2019, 15397, 0, '2019-11-06 23:34:17', '2019-11-06'),
(74, 54817, 7, 11, 2019, 410, 0, '2019-11-06 23:34:17', '2019-11-06'),
(75, 54817, 8, 11, 2019, 158, 0, '2019-11-06 23:34:17', '2019-11-06'),
(76, 54817, 9, 11, 2019, 1504, 0, '2019-11-06 23:34:17', '2019-11-06'),
(77, 54817, 2, 11, 2019, 15397, 0, '2019-11-06 23:39:30', '2019-11-06'),
(78, 54817, 7, 11, 2019, 410, 0, '2019-11-06 23:39:30', '2019-11-06'),
(79, 54817, 8, 11, 2019, 158, 0, '2019-11-06 23:39:30', '2019-11-06'),
(80, 54817, 9, 11, 2019, 1504, 0, '2019-11-06 23:39:30', '2019-11-06'),
(81, 54817, 7, 11, 2019, 410, 0, '2019-11-07 14:16:01', '2019-11-07'),
(82, 54817, 8, 11, 2019, 158, 0, '2019-11-07 14:16:01', '2019-11-07'),
(83, 54817, 9, 11, 2019, 1504, 0, '2019-11-07 14:16:01', '2019-11-07'),
(84, 54817, 7, 11, 2019, 410, 0, '2019-11-07 15:42:59', '2019-11-07'),
(85, 54817, 8, 11, 2019, 158, 0, '2019-11-07 15:42:59', '2019-11-07'),
(86, 54817, 9, 11, 2019, 1504, 0, '2019-11-07 15:42:59', '2019-11-07'),
(87, 54817, 7, 11, 2019, 410, 0, '2019-11-07 16:57:08', '2019-11-07'),
(88, 54817, 8, 11, 2019, 158, 0, '2019-11-07 16:57:08', '2019-11-07'),
(89, 54817, 9, 11, 2019, 1504, 0, '2019-11-07 16:57:08', '2019-11-07');

-- --------------------------------------------------------

--
-- Table structure for table `jnj_totalrollingforecast_cvt`
--

CREATE TABLE `jnj_totalrollingforecast_cvt` (
  `id` int(4) NOT NULL,
  `customerWWID` int(7) NOT NULL,
  `itemId` int(4) NOT NULL,
  `month` int(2) NOT NULL,
  `year` int(4) NOT NULL,
  `rollingForecast` float NOT NULL,
  `rollingForecastFocs` float NOT NULL,
  `createdDate` datetime NOT NULL,
  `modifiedDate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jnj_totalrollingforecast_cvt`
--

INSERT INTO `jnj_totalrollingforecast_cvt` (`id`, `customerWWID`, `itemId`, `month`, `year`, `rollingForecast`, `rollingForecastFocs`, `createdDate`, `modifiedDate`) VALUES
(1, 54847, 85, 8, 2019, 36235, 0, '2019-09-25 11:52:36', '2019-09-25'),
(2, 54847, 50, 8, 2019, 430092, 0, '2019-09-25 11:52:36', '2019-09-25'),
(3, 54847, 51, 8, 2019, 150723, 0, '2019-09-25 11:52:36', '2019-09-25'),
(4, 54847, 52, 8, 2019, 5225, 0, '2019-09-25 11:52:36', '2019-09-25'),
(5, 54847, 54, 8, 2019, 3817, 0, '2019-09-25 11:52:36', '2019-09-25'),
(6, 54847, 55, 8, 2019, 1504, 0, '2019-09-25 11:52:36', '2019-09-25'),
(7, 59051, 2, 8, 2019, 1040, 0, '2019-09-25 11:52:36', '2019-09-25'),
(8, 59051, 3, 8, 2019, 1655, 0, '2019-09-25 11:52:36', '2019-09-25'),
(9, 59051, 5, 8, 2019, 1783, 0, '2019-09-25 11:52:36', '2019-09-25'),
(10, 59051, 7, 8, 2019, 15440, 0, '2019-09-25 11:52:36', '2019-09-25'),
(11, 59051, 2, 11, 2019, 0, 0, '2019-11-07 01:02:24', '2019-11-07'),
(12, 59051, 3, 11, 2019, 0, 0, '2019-11-07 01:02:24', '2019-11-07'),
(13, 59051, 5, 11, 2019, 0, 0, '2019-11-07 01:02:24', '2019-11-07'),
(14, 59051, 7, 11, 2019, 0, 0, '2019-11-07 01:02:24', '2019-11-07'),
(15, 59051, 2, 11, 2019, 0, 0, '2019-11-07 01:06:41', '2019-11-07'),
(16, 59051, 3, 11, 2019, 0, 0, '2019-11-07 01:06:41', '2019-11-07'),
(17, 59051, 5, 11, 2019, 0, 0, '2019-11-07 01:06:41', '2019-11-07'),
(18, 59051, 7, 11, 2019, 0, 0, '2019-11-07 01:06:41', '2019-11-07'),
(19, 59051, 2, 11, 2019, 0, 0, '2019-11-07 10:01:54', '2019-11-07'),
(20, 59051, 3, 11, 2019, 0, 0, '2019-11-07 10:01:54', '2019-11-07'),
(21, 59051, 5, 11, 2019, 0, 0, '2019-11-07 10:01:54', '2019-11-07'),
(22, 59051, 7, 11, 2019, 0, 0, '2019-11-07 10:01:54', '2019-11-07'),
(23, 59051, 2, 11, 2019, 0, 0, '2019-11-07 11:55:47', '2019-11-07'),
(24, 59051, 3, 11, 2019, 0, 0, '2019-11-07 11:55:47', '2019-11-07'),
(25, 59051, 5, 11, 2019, 0, 0, '2019-11-07 11:55:47', '2019-11-07'),
(26, 59051, 7, 11, 2019, 0, 0, '2019-11-07 11:55:47', '2019-11-07'),
(27, 59051, 2, 11, 2019, 0, 0, '2019-11-07 12:41:58', '2019-11-07'),
(28, 59051, 3, 11, 2019, 0, 0, '2019-11-07 12:41:58', '2019-11-07'),
(29, 59051, 5, 11, 2019, 0, 0, '2019-11-07 12:41:58', '2019-11-07'),
(30, 59051, 7, 11, 2019, 0, 0, '2019-11-07 12:41:58', '2019-11-07');

-- --------------------------------------------------------

--
-- Table structure for table `jnj_totalsalestarget`
--

CREATE TABLE `jnj_totalsalestarget` (
  `id` int(5) NOT NULL,
  `customerName` int(6) NOT NULL,
  `countryId` int(5) NOT NULL,
  `itemName` int(60) NOT NULL,
  `acumulatedMonth` int(3) NOT NULL,
  `year` int(4) NOT NULL,
  `ffTarget` int(10) NOT NULL,
  `createdDate` date NOT NULL,
  `modifiedDate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jnj_totalsalestarget`
--

INSERT INTO `jnj_totalsalestarget` (`id`, `customerName`, `countryId`, `itemName`, `acumulatedMonth`, `year`, `ffTarget`, `createdDate`, `modifiedDate`) VALUES
(1, 0, 0, 0, 0, 0, 0, '2019-09-25', '2019-09-25'),
(2, 54806, 5, 2, 12, 2019, 390, '2019-09-25', '2019-09-25'),
(3, 54806, 5, 7, 12, 2019, 63000, '2019-09-25', '2019-09-25'),
(4, 54806, 5, 8, 12, 2019, 165000, '2019-09-25', '2019-09-25'),
(5, 54806, 5, 9, 12, 2019, 55000, '2019-09-25', '2019-09-25'),
(6, 54847, 1, 85, 12, 2019, 46851, '2019-09-25', '2019-09-25'),
(7, 54847, 1, 50, 12, 2019, 23312, '2019-09-25', '2019-09-25'),
(8, 54847, 1, 51, 12, 2019, 22201, '2019-09-25', '2019-09-25'),
(9, 54847, 1, 52, 12, 2019, 80, '2019-09-25', '2019-09-25'),
(10, 54847, 1, 54, 12, 2019, 50100, '2019-09-25', '2019-09-25'),
(11, 54847, 1, 55, 12, 2019, 3290, '2019-09-25', '2019-09-25'),
(12, 59051, 1, 2, 12, 2019, 0, '2019-09-25', '2019-09-25'),
(13, 59051, 1, 3, 12, 2019, 27818, '2019-09-25', '2019-09-25'),
(14, 59051, 1, 5, 12, 2019, 9840, '2019-09-25', '2019-09-25'),
(15, 59051, 1, 7, 12, 2019, 304500, '2019-09-25', '2019-09-25'),
(16, 54817, 1, 2, 12, 2019, 50, '2019-09-25', '2019-09-25'),
(17, 54817, 1, 7, 12, 2019, 6100, '2019-09-25', '2019-09-25'),
(18, 54817, 1, 8, 12, 2019, 14400, '2019-09-25', '2019-09-25'),
(19, 54817, 1, 9, 12, 2019, 10200, '2019-09-25', '2019-09-25'),
(20, 54824, 1, 51, 12, 2019, 2629, '2019-09-25', '2019-09-25'),
(21, 54824, 1, 54, 12, 2019, 27000, '2019-09-25', '2019-09-25'),
(22, 54824, 1, 55, 12, 2019, 10000, '2019-09-25', '2019-09-25'),
(23, 54824, 1, 60, 12, 2019, 13500, '2019-09-25', '2019-09-25');

-- --------------------------------------------------------

--
-- Table structure for table `jnj_upside_downside_fcast`
--

CREATE TABLE `jnj_upside_downside_fcast` (
  `id` int(11) NOT NULL,
  `customerWWID` int(11) NOT NULL,
  `itemId` int(11) NOT NULL,
  `upSideValue` int(11) NOT NULL,
  `downSideValue` int(11) NOT NULL,
  `probabilityUpside` float NOT NULL,
  `commentsUpside` varchar(30) NOT NULL,
  `probabilityDownside` int(11) NOT NULL,
  `commentsDownside` varchar(30) NOT NULL,
  `monthValue` int(11) NOT NULL,
  `yearValue` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `createdDate` datetime NOT NULL,
  `modifiedDate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `jnj_upside_downside_fcast`
--

INSERT INTO `jnj_upside_downside_fcast` (`id`, `customerWWID`, `itemId`, `upSideValue`, `downSideValue`, `probabilityUpside`, `commentsUpside`, `probabilityDownside`, `commentsDownside`, `monthValue`, `yearValue`, `status`, `createdDate`, `modifiedDate`) VALUES
(1, 54817, 7, 102, 0, 1, 'OK', 0, 'null', 10, 2019, 1, '2019-11-07 16:47:35', '2019-11-07');

-- --------------------------------------------------------

--
-- Table structure for table `jnj_upside_downside_fcast_cvtl`
--

CREATE TABLE `jnj_upside_downside_fcast_cvtl` (
  `id` int(11) NOT NULL,
  `customerWWID` int(11) NOT NULL,
  `itemId` int(11) NOT NULL,
  `upSideValue` int(11) NOT NULL,
  `downSideValue` int(11) NOT NULL,
  `probabilityUpside` float NOT NULL,
  `commentsUpside` varchar(30) NOT NULL,
  `probabilityDownside` int(11) NOT NULL,
  `commentsDownside` varchar(30) NOT NULL,
  `monthValue` int(11) NOT NULL,
  `yearValue` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `createdDate` datetime NOT NULL,
  `modifiedDate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `jnj_upside_downside_focs`
--

CREATE TABLE `jnj_upside_downside_focs` (
  `id` int(11) NOT NULL,
  `customerWWID` int(11) NOT NULL,
  `itemId` int(11) NOT NULL,
  `upSideValue` int(11) NOT NULL,
  `downSideValue` int(11) NOT NULL,
  `probabilityUpside` float NOT NULL,
  `commentsUpside` varchar(30) NOT NULL,
  `probabilityDownside` int(11) NOT NULL,
  `commentsDownside` varchar(30) NOT NULL,
  `monthValue` int(11) NOT NULL,
  `yearValue` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `createdDate` datetime NOT NULL,
  `modifiedDate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `jnj_upside_downside_focs_cvtl`
--

CREATE TABLE `jnj_upside_downside_focs_cvtl` (
  `id` int(11) NOT NULL DEFAULT 0,
  `customerWWID` int(11) NOT NULL,
  `itemId` int(11) NOT NULL,
  `upSideValue` int(11) NOT NULL,
  `downSideValue` int(11) NOT NULL,
  `probabilityUpside` float NOT NULL,
  `commentsUpside` varchar(30) NOT NULL,
  `probabilityDownside` int(11) NOT NULL,
  `commentsDownside` varchar(30) NOT NULL,
  `monthValue` int(11) NOT NULL,
  `yearValue` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `createdDate` datetime NOT NULL,
  `modifiedDate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `jnj_upside_downside_focs_cvtl`
--

INSERT INTO `jnj_upside_downside_focs_cvtl` (`id`, `customerWWID`, `itemId`, `upSideValue`, `downSideValue`, `probabilityUpside`, `commentsUpside`, `probabilityDownside`, `commentsDownside`, `monthValue`, `yearValue`, `status`, `createdDate`, `modifiedDate`) VALUES
(1, 54817, 2, 102, 110, 10, 'Hello', 12, 'World', 1, 2019, 1, '2019-11-06 11:00:05', '2019-11-06'),
(2, 54817, 7, 11, 12, 2, 'ashgd', 4, 'sdfsdf', 1, 2019, 1, '2019-11-06 11:08:15', '2019-11-06'),
(3, 54817, 2, 45, 56, 4, 'ikjjkhh', 2, 'oiuoiuo', 3, 2019, 1, '2019-11-06 13:03:31', '2019-11-06');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `jnj_actualsalesvalue`
--
ALTER TABLE `jnj_actualsalesvalue`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jnj_brand`
--
ALTER TABLE `jnj_brand`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jnj_country`
--
ALTER TABLE `jnj_country`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jnj_customer`
--
ALTER TABLE `jnj_customer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jnj_dataentry`
--
ALTER TABLE `jnj_dataentry`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jnj_dummy_actualsalesvalue`
--
ALTER TABLE `jnj_dummy_actualsalesvalue`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jnj_fcast_focs_dataentry`
--
ALTER TABLE `jnj_fcast_focs_dataentry`
  ADD PRIMARY KEY (`talId`);

--
-- Indexes for table `jnj_item`
--
ALTER TABLE `jnj_item`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jnj_pricing_dataentry`
--
ALTER TABLE `jnj_pricing_dataentry`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jnj_registration`
--
ALTER TABLE `jnj_registration`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jnj_temp_cvtl_dataentry`
--
ALTER TABLE `jnj_temp_cvtl_dataentry`
  ADD PRIMARY KEY (`talId`);

--
-- Indexes for table `jnj_temp_dataentry`
--
ALTER TABLE `jnj_temp_dataentry`
  ADD PRIMARY KEY (`tempid`);

--
-- Indexes for table `jnj_temp_fcast_focs_dataentry`
--
ALTER TABLE `jnj_temp_fcast_focs_dataentry`
  ADD PRIMARY KEY (`talId`);

--
-- Indexes for table `jnj_temp_tal_dataentry`
--
ALTER TABLE `jnj_temp_tal_dataentry`
  ADD PRIMARY KEY (`talId`);

--
-- Indexes for table `jnj_temp_totalsalestarget`
--
ALTER TABLE `jnj_temp_totalsalestarget`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jnj_totalrollingforecast`
--
ALTER TABLE `jnj_totalrollingforecast`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jnj_totalrollingforecast_cvt`
--
ALTER TABLE `jnj_totalrollingforecast_cvt`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jnj_totalsalestarget`
--
ALTER TABLE `jnj_totalsalestarget`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jnj_upside_downside_fcast`
--
ALTER TABLE `jnj_upside_downside_fcast`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jnj_upside_downside_fcast_cvtl`
--
ALTER TABLE `jnj_upside_downside_fcast_cvtl`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jnj_upside_downside_focs`
--
ALTER TABLE `jnj_upside_downside_focs`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `jnj_actualsalesvalue`
--
ALTER TABLE `jnj_actualsalesvalue`
  MODIFY `id` int(7) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `jnj_brand`
--
ALTER TABLE `jnj_brand`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- AUTO_INCREMENT for table `jnj_country`
--
ALTER TABLE `jnj_country`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `jnj_customer`
--
ALTER TABLE `jnj_customer`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `jnj_dataentry`
--
ALTER TABLE `jnj_dataentry`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `jnj_dummy_actualsalesvalue`
--
ALTER TABLE `jnj_dummy_actualsalesvalue`
  MODIFY `id` int(7) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `jnj_fcast_focs_dataentry`
--
ALTER TABLE `jnj_fcast_focs_dataentry`
  MODIFY `talId` int(7) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `jnj_item`
--
ALTER TABLE `jnj_item`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=114;

--
-- AUTO_INCREMENT for table `jnj_pricing_dataentry`
--
ALTER TABLE `jnj_pricing_dataentry`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=829;

--
-- AUTO_INCREMENT for table `jnj_registration`
--
ALTER TABLE `jnj_registration`
  MODIFY `id` int(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `jnj_temp_cvtl_dataentry`
--
ALTER TABLE `jnj_temp_cvtl_dataentry`
  MODIFY `talId` int(5) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `jnj_temp_dataentry`
--
ALTER TABLE `jnj_temp_dataentry`
  MODIFY `tempid` int(4) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `jnj_temp_fcast_focs_dataentry`
--
ALTER TABLE `jnj_temp_fcast_focs_dataentry`
  MODIFY `talId` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `jnj_temp_tal_dataentry`
--
ALTER TABLE `jnj_temp_tal_dataentry`
  MODIFY `talId` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `jnj_temp_totalsalestarget`
--
ALTER TABLE `jnj_temp_totalsalestarget`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `jnj_totalrollingforecast`
--
ALTER TABLE `jnj_totalrollingforecast`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=90;

--
-- AUTO_INCREMENT for table `jnj_totalrollingforecast_cvt`
--
ALTER TABLE `jnj_totalrollingforecast_cvt`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `jnj_totalsalestarget`
--
ALTER TABLE `jnj_totalsalestarget`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `jnj_upside_downside_fcast`
--
ALTER TABLE `jnj_upside_downside_fcast`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `jnj_upside_downside_fcast_cvtl`
--
ALTER TABLE `jnj_upside_downside_fcast_cvtl`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `jnj_upside_downside_focs`
--
ALTER TABLE `jnj_upside_downside_focs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
