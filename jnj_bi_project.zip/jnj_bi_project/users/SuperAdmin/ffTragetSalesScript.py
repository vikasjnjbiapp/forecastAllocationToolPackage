import csv
import mysql.connector
from datetime import datetime
from datetime import date

mydb = mysql.connector.connect(
  host="localhost",
  user="root",
  passwd="",
  database="jnjbiapplication"
)
mycursor = mydb.cursor()
arrayA = []
with open('uploads/importTemplateTargetSales - Copy.csv', 'r') as csvfile:
    csv_reader = csv.reader(csvfile, delimiter=',')
    line_count = 0
    for row in csv_reader:
        if line_count == 0:
            print(f'Column names are {", ".join(row)}')
            line_count += 1
        else:
            line_count += 1
            valueToBeInserted = (row[1], row[2], row[4].replace(" ","").strip(), row[5].replace("?","").strip(), row[6], row[7], row[8],\
                                 row[10], row[11], row[13], row[14], row[15], row[16], row[17], datetime.now(), datetime.today())
            arrayA.append(valueToBeInserted)

    for abc in arrayA:
        mycursor.execute('INSERT INTO jnj_temp_totalSalesTarget (customerWWID, countryCode, custType, itemName, itemId,\
            brandName, brandId, ffSalesTarget, mMonth, yYear, type, status, sapCode, divested, createdDate, modifiedDate) VALUES (\
            %s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)', abc)
        
    mydb.commit()
print(mycursor.rowcount, "record inserted.")
print(f'Processed {line_count} lines.')
