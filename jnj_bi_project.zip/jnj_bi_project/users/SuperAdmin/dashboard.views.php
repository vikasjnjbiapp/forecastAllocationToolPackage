<?php
// print_r($_SESSION);
$commonMethod = new commonMethodFile();
$regist = $commonMethod->fetchMultipleRecords('jnj_registration', '*', 'customerName!=1');
$registCVTL = $commonMethod->fetchMultipleRecords('jnj_registration', '*', 'userRole=2');
$country = $commonMethod->fetchTableValue('jnj_country', '*');
// print_r($country);
$userRole = ['SuperAdmin', 'KAM Manger', 'CVTL', 'TAL', 'KAMs', 'Pricing Team', '9'=>'No Role'];
$userStatus = ['1'=>'Active', 'Deactive'];

$fieldItemName = ['id', 'biCode', 'itemName'];
$countryCode = ['SA'=>1];
$items = $commonMethod->fetchItemByItemIdCombination('jnj_item', $fieldItemName, $countryCode['SA']);
$productMasterDetails = $commonMethod->fetchProductMasterDetails(2019);
?>
<!-- Display the chart and report -->
<ul class="nav nav-tabs" id="myTab">
    <li class="nav-item">
        <a href="#activeUserDetail" class="nav-link" data-toggle="tab" id="activeUserDetails">User Details</a>
    </li>
    <li class="nav-item">
        <a href="#productMasterDetails" class="nav-link" data-toggle="tab" id="productMasterDetail">Product Master</a>
    </li>
    <li class="nav-item">
        <a href="#previousYear" class="nav-link" data-toggle="tab" id="year_18">Import Prvious Year Data</a>
    </li>
</ul>
<div class="tab-content">
    <div class="tab-pane fade" id="activeUserDetail">
        <h4 class="mt-2">User Details </h4>
        <div class="table-responsive">
           <form id="entryGridActiveUser" name="entryGridActiveUser" method="post">
              <table class="table table-striped" id="activeUserTable">
                <thead>
                    <tr class="table-dark">
                        <th colspan="7"><div id="errorMessage"></div></th>
                    </tr>
                    <tr class="table-primary">
                        <th><div class="small col-12" style='width: 150px;'>Customer Number</div></th>
                        <th><div class="small col-4" style='width: 100px;'>Email</div></th>
                        <th><div class="small col-8" style='width: 100px;'>User Role</div></th>
                        <th><div class="small col-4" style='width: 100px;'>Acive/Deactive</div></th>
                        <th>&nbsp;</th>
                        <th><div class="small col-4" style='width: 100px;'>Action</div></th>
                        <th>&nbsp;</th>
                    </tr>
                </thead>
                <tbody>
                  <?php 
                   $i = 1;
                   foreach($regist as $val) { ?>
                    <tr>
                        <td><div class="input-group input-group-sm mt-2">
                            <input type="text" class="form-control" placeholder="Customer Number" value="<?php echo $val['customerName'];?>" name="customerUserRole" id="customerUserRole" style='width: 60px;' readonly>
                        </div></td>
                        <td><div class="input-group input-group-sm mt-2">
                            <input type="text" class="form-control" placeholder="Email" value="<?php echo $val['email'];?>" name="userEmail" id="userEmail" style='width: 150px;' readonly>
                        </div></td>
                        <td><div class="input-group input-group-sm mt-2">
                          <?php if($val['userRole'] !== '') {?>
                            <input type="text" class="form-control" placeholder="User Role" value="<?php echo $userRole[$val['userRole']];?>" name="userRoleOne" id="userRoleOne" style='width: 150px;' readonly>
                          <?php } ?>
                          </div></td>                        
                        <td><div class="input-group input-group-sm mt-2">
                          <?php if($val['userStatus'] !== '') {?>
                            <input type="text" class="form-control" placeholder="User Status" value="<?php echo $userStatus[$val['userStatus']];?>" name="userStatus" id="userStatus" style='width: 150px;' readonly>
                          <?php } ?>
                        </div></td>
                        <td>&nbsp;</td>
                        <td><div class="input-group input-group-sm mt-2">             
                            <a href="#" class="btn btn-primary" name="entryGridActiveUserEdit_<?php echo $i?>" id="entryGridActiveUserEdit_<?php echo $i?>" data-toggle="modal" data-target="#exampleModal" rs="<?php echo $val['customerName'];?>">Edit</a>
                        </div><!--button type="button" class="btn btn-primary" name="entryGridActiveUserEdit" id="entryGridActiveUserEdit" >Edit</button-->
                       </td>
                        <td>&nbsp;</td>
                    </tr>
                  <?php 
                    $i = $i + 1;
                   } ?>
                </tbody>
             </table>
            <!--div style="text-align:center;"><button type="button" id="btnActiveUserDetail" name="btnActiveUserDetail" class="btn btn-primary">Submit</button></div-->
           </form>
        </div>
    </div>
    <div class="tab-pane fade" id="productMasterDetails">
        <h4 class="mt-2">Product Master</h4>
        <div class="table-responsive">
        <form id="entryGridItemUserMapping" name="entryGridItemUserMapping" method="post">
            <table class="table table-striped" id="sampleTbl">
                <thead>
                    <tr class="table-dark">
                        <th colspan="4"><div id="errorMessage"></div></th>
                        <th colspan="3"><div class="small col-12">Type</div></th>
                        <th colspan="2"><div class="small col-12">TDN/DPO</div></th>
                    </tr>
                    <tr class="table-primary">
                        <th><div class="small col-12" style='width: 190px;'>Country(Code - Name)</div></th>
                        <th><div class="small col-8" style='width: 100px;'>CustomerWWID</div></th>
                        <th><div class="small col-12" style='width: 150px;'>Brand(Code - Name)</div></th>
                        <th><div class="small col-12" style='width: 150px;'>Item(Code - Name)</div></th>
                        <th><div class="small col-4" style='width: 100px;'>Private</div></th>
                        <th><div class="small col-4" style='width: 100px;'>Institution</div></th>
                        <th><div class="small col-4" style='width: 100px;'>MOH</div></th>
                        <th><div class="small col-4" style='width: 100px;'>DPO</div></th>
                        <th><div class="small col-4" style='width: 100px;'>TDN</div></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($productMasterDetails as $key => $val) { ?>
                    <tr>
                        <td><div class="input-group small"><?php echo $val['countryName'];?></div></td>
                        <td><div class="input-group small"><?php echo $val['customerWWID'];?></div></td>
                        <td><div class="input-group small"><?php echo $val['brandId'];?></div></td>
                        <td><div class="input-group small"><?php echo $items[$val['itemId']];?></div></td>
                        <td><div class="input-group input-group-sm mt-2"><input type="checkbox" name="private_<?php echo $key;?>" id="private_<?php echo $key;?>" value="1" <?php echo (isset($val['typePrivate']) && $val['typePrivate'] === '1')?'checked':'';?>></div></td>
                        <td><div class="input-group input-group-sm mt-2"><input type="checkbox" name="Institution_<?php echo $key;?>" id="Institution_<?php echo $key;?>" value="1" <?php echo (isset($val['typeInstitution']) && $val['typeInstitution'] === '1')?'checked':'';?>></div></td>
                        <td><div class="input-group input-group-sm mt-2"><input type="checkbox" name="Moh_<?php echo $key;?>" id="Moh_<?php echo $key;?>" value="1" <?php echo (isset($val['typeMoh']) && $val['typeMoh'] === '1')?'checked':'';?>></div></td>
                        <td><div class="input-group input-group-sm mt-2"><input type="checkbox" name="DPO_<?php echo $key;?>" id="DPO_<?php echo $key;?>" value="1" <?php echo (isset($val['dpo']) && $val['dpo'] === '1')?'checked':'';?>></div></td>
                        <td><div class="input-group input-group-sm mt-2"><input type="checkbox" name="TDN_<?php echo $key;?>" id="TDN_<?php echo $key;?>" value="1" <?php echo (isset($val['tnd']) && $val['tnd'] === '1')?'checked':'';?>></div></td>
                    </tr>
                    <?php } ?>
                </tbody>
            </table>
            <div style="text-align:center;"><button type="button" id="btnEntryGridItemUserMapping" name="btnEntryGridItemUserMapping" class="btn btn-primary">Submit</button></div>
        </form>
        </div>
    </div>
    <div class="tab-pane fade" id="previousYear">
        <h4 class="mt-2">Import Actual Sales</h4>
        <div class="table-responsive">
            <form id="entryItemEntryImport" name="entryItemEntryImport" method="post" enctype="multipart/form-data">              
              <div class="input-group mb-3">                
                <div class="input-group-append">
                  <input type="file" name="file" id="file">
                 </div>
                 <div style="text-align:center;"><button class='btn btn-primary'id="submitbutton" type="submit">Upload CSV file!</button></div>  
              </div>
            </form>
        </div>
    </div>
</div>
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content" style="width:800px;">
      <form id="updateUserDetailForm" name="updateUserDetailForm" method="post">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">User Details:: </h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
          <table class="table table-striped" id="sampleTbl">
            <thead>
                <tr class="table-primary">
                    <th><div class="small col-12" style='width: 150px;'>Customer Number</div></th>
                    <th><div class="small col-4" style='width: 100px;'>Email</div></th>
                    <th><div class="small col-8" style='width: 100px;'>User Role</div></th>
                    <th><div class="small col-4" style='width: 100px;'>Acive/Deactive</div></th>
                </tr>
            </thead>
            <tbody>
              <tr>
                <td><div class="input-group input-group-sm mt-2">
                    <input type="text" class="form-control" placeholder="Customer Number" value="<?php echo $val['customerName'];?>" name="customerUserRoleEdit" id="customerUserRoleEdit" style='width: 60px;' readonly>
                </div></td>
                <td><div class="input-group input-group-sm mt-2">
                    <input type="text" class="form-control" placeholder="Email" value="<?php echo $val['email'];?>" name="userEmailEdit" id="userEmailEdit" style='width: 150px;'>
                </div></td>
                <td><div class="input-group input-group-sm mt-2">                          
                    <select name="userRoleOneEdit" id="userRoleOneEdit" class="form-control form-control-inline" style='width: 60px;'>
                        <option value='NA'>Select Role</option>
                        <option value='1'>KAM Manager</option>
                        <option value='2'>CVTL</option>
                        <option value='3' selected>TAL</option>
                        <option value='4'>KAM</option>
                        <option value='5'>Pricing Team</option>
                    </select>
                  </div></td>                        
                <td><div class="input-group input-group-sm mt-2">
                    <select name="userStatusEdit" id="userStatusEdit" class="form-control form-control-inline" style='width: 100px;'>
                        <option value='NA'>Select Active/Deactive</option>
                        <option value='1' selected>Active</option>
                        <option value='2'>Deactive</option>
                    </select>
                </div></td>
              </tr>
            </tbody>
        </table>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary" id="saveChanges" name="saveChanges">Save changes</button>
      </div>
      </form>
    </div>
  </div>
</div>
<script src="javascript/papaparse.min.js"></script>
<script>
    $(document).ready(function(){ 
        $("#myTab a:first").tab('show'); // show last tab on page load
        $('#mychartOne').hide();
        $('[data-toggle="tooltip"]').tooltip({
            title: "Searcch by customer number or country name or item. <br/> You can also use three criteria togather using colum saparator.",
            html: true
        });
    });
/*Start:: activeUserDetail*/
    $("a[name*='entryGridActiveUserEdit']").click(function() {
       let customerNumber = $(this).attr('rs');
       let domElementName = ['customerUserRoleEdit', 'userEmailEdit'];
       let responseField = ['customerName', 'email']
       getResponse('router.php', 'fetchUserDetails', customerNumber, domElementName, responseField);       
    });
    $('#saveChanges').click(function() {
       let tempData = $('#updateUserDetailForm').serializeArray();
       postRequest('router.php', 'updateUserDetails', tempData);       
    });
/*End:: activeUserDetail*/

/*Start:: entryGridItemUserMapping*/
    $('#btnEntryGridItemUserMapping').click(function() {
        let tempArrayData = $('#entryGridItemUserMapping').serializeArray();
        console.log(tempArrayData);     
    });
/*End*/
    
/*Start:: submitbutton*/
    $('#entryItemEntryImport').on('submit', function(e) {
       e.preventDefault();
        $.ajax({
            type: 'POST',
            url: 'test.php?pageImport=importDataFile',
            data: new FormData(this),
            dataType: 'json',
            contentType: false,
            cache: false,
            processData:false,
            beforeSend: function(){
               // $('#submitbutton').attr("disabled","disabled");
                // $('#entryItemEntryImport').css("opacity",".5");
            },
            success: function(response){
              console.log(response);
                /*if(response === 1){
                    // $('#entryItemEntryImport').reset();
                    $('.statusMsg').html('<p class="alert alert-success">'+response.message+'</p>');
                }else{
                    $('.statusMsg').html('<p class="alert alert-danger">'+response.message+'</p>');
                }*/
                $('#entryItemEntryImport').css("opacity","");
                $("#submitbutton").removeAttr("disabled");
            }
        }); 
    })
/*End::*/
/*$("#submitbutton").click(function(){
  var myfile = $("#file")[0].files[0];
  console.log(myfile);
  var json = Papa.parse(myfile, {
        header: true, 
        skipEmptyLines: true,
        complete: function(results) {
            console.log("Dataframe:", JSON.stringify(results.data));
            console.log("Column names:", results.meta.fields);
            console.log("Errors:", results.errors);
            var jsonString = JSON.stringify(results.data,undefined, 2);
            $.post('router.php', {page: 'importDataFile', arrayData: jsonString}, function(data) {
                console.log(data);
            });
        }
    });
});*/

    
/*----------- Common functions ----------------------*/
   var getResponse = function(argUrl, argPage, argArrayData, domElementName, responseField) {
      $.post(argUrl, {page: argPage, arrayData: argArrayData}, function(data) {
        let tempData = data.split(',');
        if(tempData.length > 1) { 
            $('#'+domElementName[0]).val(tempData[0]);
            $('#'+domElementName[1]).val(tempData[1]);
        }
      });
   };
   var postRequest = function(argUrl, argPage, argArrayData ){
      $.post(argUrl, {page: argPage, arrayData: argArrayData}, function(data) {
          if(data) {
             alert('Data update sucessfully.'+data);
          }
      });
   };
</script>