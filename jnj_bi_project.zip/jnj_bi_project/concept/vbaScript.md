Sub brandId_button()
    Range("F1").Select
    ActiveCell.FormulaR1C1 = "brandId"
    Range("F2").Select
    ActiveCell.FormulaR1C1 = "=MATCH(RC[-1],brand!R2C2:R59C2,0)"
    Range("F2").Select
    Selection.AutoFill Destination:=Range("F2:F633")
    Range("F2:F633").Select
    ActiveWindow.SmallScroll Down:=69
    ActiveWindow.ScrollRow = 199
    ActiveWindow.ScrollRow = 442
    ActiveWindow.ScrollRow = 596
    ActiveWindow.ScrollRow = 613
End Sub

Sub itemid_button()
    Columns("F:F").Select
    Selection.Insert Shift:=xlToRight, CopyOrigin:=xlFormatFromLeftOrAbove
    Range("F1").Select
    ActiveCell.FormulaR1C1 = "itemId"
    Range("F2").Select
    ActiveCell.FormulaR1C1 = "=MATCH(RC[-1],item!R2C4:R632C4,0)"
    Range("F2").Select
    Selection.AutoFill Destination:=Range("F2:F18015")
    Range("F2:F18015").Select
    ActiveWindow.SmallScroll Down:=69
    ActiveWindow.ScrollRow = 399
    ActiveWindow.ScrollRow = 542
    ActiveWindow.ScrollRow = 796
    ActiveWindow.ScrollRow = 10000
End Sub
Sub brandIdN_button()
    Columns("H:H").Select
    Selection.Insert Shift:=xlToRight, CopyOrigin:=xlFormatFromLeftOrAbove
    Range("H1").Select
    ActiveCell.FormulaR1C1 = "brandId"
    Range("H2").Select
    ActiveCell.FormulaR1C1 = "=MATCH(RC[-1],brand!R2C2:R59C2, 0)"
    Range("H2").Select
    Selection.AutoFill Destination:=Range("H2:H18015")
    Range("H2:H18015").Select
    ActiveWindow.SmallScroll Down:=69
    ActiveWindow.ScrollRow = 399
    ActiveWindow.ScrollRow = 542
    ActiveWindow.ScrollRow = 796
    ActiveWindow.ScrollRow = 10000
End Sub

---- 07/11/2019
Sub callTwoMethods()
  Call itemid_button
  Call brandIdN_button
End Sub

Sub itemid_button()
    Columns("G:G").Select
    Selection.Insert Shift:=xlToRight, CopyOrigin:=xlFormatFromLeftOrAbove
    Range("G1").Select
    ActiveCell.FormulaR1C1 = "itemId"
    Range("G2").Select
    ActiveCell.FormulaR1C1 = "=MATCH(RC[-1],item!R2C2:R632C2,0)"
    Range("G2").Select
    Selection.AutoFill Destination:=Range("G2:G46219")
    Range("G2:G46219").Select
    ActiveWindow.SmallScroll Down:=69
    ActiveWindow.ScrollRow = 399
    ActiveWindow.ScrollRow = 542
    ActiveWindow.ScrollRow = 796
    ActiveWindow.ScrollRow = 10000
End Sub
Sub brandIdN_button()
    Columns("I:I").Select
    Selection.Insert Shift:=xlToRight, CopyOrigin:=xlFormatFromLeftOrAbove
    Range("I1").Select
    ActiveCell.FormulaR1C1 = "brandId"
    Range("I2").Select
    ActiveCell.FormulaR1C1 = "=MATCH(RC[-1],brand!R2C2:R59C2, 0)"
    Range("I2").Select
    Selection.AutoFill Destination:=Range("I2:I46219")
    Range("I2:I46219").Select
    ActiveWindow.SmallScroll Down:=69
    ActiveWindow.ScrollRow = 399
    ActiveWindow.ScrollRow = 542
    ActiveWindow.ScrollRow = 796
    ActiveWindow.ScrollRow = 10000
End Sub

Sub Macro1()
'
' Macro1 Macro
'

'
    Columns("G:G").Select
    Selection.Insert Shift:=xlToRight, CopyOrigin:=xlFormatFromLeftOrAbove
    Range("G1").Select
End Sub
Sub Macro2()
'
' Macro2 Macro
'

'
    Columns("G:G").Select
    Selection.Insert Shift:=xlToRight, CopyOrigin:=xlFormatFromLeftOrAbove
    Range("G1").Select
    ActiveCell.FormulaR1C1 = "ItemId"
    Range("G2").Select
    ActiveCell.FormulaR1C1 = "=MATCH(RC[-1],item!RC[-6]:R[130]C[-5],0)"
    Range("G2").Select
    ActiveCell.FormulaR1C1 = "=MATCH(RC[-1],item!RC[-5]:R[130]C[-5],0)"
    Range("G3").Select
End Sub
Sub Macro3()
'
' Macro3 Macro
'

'
    ChDir "C:\Users\vibose\Desktop"
    ActiveWorkbook.SaveAs Filename:="C:\Users\vibose\Desktop\IMS_2019.csv", _
        FileFormat:=xlCSV, CreateBackup:=False
    ActiveWindow.ScrollColumn = 2
    ActiveWindow.ScrollColumn = 6
    ActiveWindow.ScrollColumn = 7
End Sub

